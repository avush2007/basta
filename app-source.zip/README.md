# Supermarket OS V3

אפליקציה כללית לניהול סופרים: Web + Android + iPhone על אותו קוד.

## מודל Multi-tenant
- לכל סופר קוד כניסה משלו (`store_code`).
- המשתמש מתחבר לסופר ואז נטענים רק הנתונים של אותו `business_id`.
- `business_memberships` מאפשר למשתמש להשתייך ליותר מסופר אחד.
- `Developer Console` זמין רק ל-Platform Admin ומאפשר ליצור/לערוך סופרים ולהפעיל מודולים.
- אחים דוד נשאר Tenant ראשון עם ה-business_id והנתונים הקיימים.

## לפני האפליקציה
הרץ פעם אחת ב-Supabase את `v3.0.0-multitenant-platform.sql` מה-Bundle שקיבלת.

## Builds בענן
- Android: Actions → Build Android APK → Run workflow → הורדת `app-debug.apk`.
- iOS: Actions → Build iOS Xcode Project → Run workflow → הורדת פרויקט Xcode מוכן לחתימה.

## עדכונים
אותו `www/` הוא מקור האמת ל-Web/Android/iOS. קובץ `.basta-update.json` עתידי יכול להיכנס ל-www באמצעות:
`node scripts/import-web-update.mjs <file>`
