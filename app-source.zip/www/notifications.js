(() => {
  'use strict';

  // Public VAPID key. The matching private key is stored only in Firebase Functions Secret Manager.
  const VAPID_PUBLIC_KEY = 'BIoCkS3DiV3Ob_UJ6Ov79swd78CKSN4tJ42_WSiV8gJ1ZruzF6BCXyI6NXkQSjA-B1K19MP12k4_hE6YSU8DhXA';
  const STORAGE_KEY = 'bastaReminderSettingsV1';
  const INTRO_SEEN_KEY = 'bastaNotificationsIntroSeenV1';
  const PRIOR_NOTIFICATION_CACHE_RE = /^basta-inventory-v(?:8|9|10)(?:$|[-_])/;
  const SCHEDULE_VERSION = 2;
  const DEFAULT_WEEKDAY_TIME = '17:50';
  const DEFAULT_FRIDAY_TIME = '13:30';

  const state = {
    enabled:false,
    weekdayTime:DEFAULT_WEEKDAY_TIME,
    fridayTime:DEFAULT_FRIDAY_TIME,
    scheduleVersion:SCHEDULE_VERSION
  };
  let ui = {};
  let migratedLegacyLocalState = false;

  function isValidTime(value){
    return /^([01]\d|2[0-3]):[0-5]\d$/.test(String(value || ''));
  }

  function loadState(){
    try{
      const raw = localStorage.getItem(STORAGE_KEY);
      if(!raw) return;
      const saved = JSON.parse(raw);
      state.enabled = !!saved?.enabled;

      if(Number(saved?.scheduleVersion) === SCHEDULE_VERSION){
        if(isValidTime(saved.weekdayTime)) state.weekdayTime = saved.weekdayTime;
        if(isValidTime(saved.fridayTime)) state.fridayTime = saved.fridayTime;
      }else{
        // v8 and earlier used one daily time. Existing enabled users are intentionally
        // migrated to the new Basta default schedule requested for v9.
        state.weekdayTime = DEFAULT_WEEKDAY_TIME;
        state.fridayTime = DEFAULT_FRIDAY_TIME;
        migratedLegacyLocalState = state.enabled;
      }
      state.scheduleVersion = SCHEDULE_VERSION;
    }catch(_e){}
  }

  function saveState(){
    try{ localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }catch(_e){}
  }

  function markIntroSeen(){
    try{ localStorage.setItem(INTRO_SEEN_KEY, '1'); }catch(_e){}
  }

  async function shouldShowIntro(){
    // Existing users of a notification-enabled version should not be interrupted.
    // We check the persistent reminder state, browser permission, old app caches and
    // any existing push subscription before the v11 service worker replaces old caches.
    try{
      if(localStorage.getItem(INTRO_SEEN_KEY)) return false;
      if(localStorage.getItem(STORAGE_KEY)){
        markIntroSeen();
        return false;
      }
    }catch(_e){}

    if('Notification' in window && Notification.permission !== 'default'){
      markIntroSeen();
      return false;
    }

    if('caches' in window){
      try{
        const keys = await caches.keys();
        if(keys.some(key => PRIOR_NOTIFICATION_CACHE_RE.test(key))){
          markIntroSeen();
          return false;
        }
      }catch(_e){}
    }

    if('serviceWorker' in navigator){
      try{
        const registration = await navigator.serviceWorker.getRegistration('/');
        const subscription = await registration?.pushManager?.getSubscription?.();
        if(subscription){
          markIntroSeen();
          return false;
        }
      }catch(_e){}
    }

    return true;
  }

  function supportsPush(){
    return 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
  }

  function isIOS(){
    return /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  }

  function isStandalone(){
    return window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
  }

  function urlBase64ToUint8Array(base64String){
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
    const rawData = atob(base64);
    return Uint8Array.from([...rawData].map(char => char.charCodeAt(0)));
  }

  async function ensureServiceWorker(){
    if(!('serviceWorker' in navigator)) throw new Error('הדפדפן הזה לא תומך בהתראות Web Push.');
    await navigator.serviceWorker.register('/sw.js', {scope:'/'});
    return navigator.serviceWorker.ready;
  }

  async function ensureSubscription(){
    if(!supportsPush()) throw new Error('המכשיר או הדפדפן הזה לא תומך בהתראות לאפליקציית ווב.');
    if(isIOS() && !isStandalone()) throw new Error('באייפון צריך לפתוח את האפליקציה מהאייקון במסך הבית כדי לאפשר התראות.');

    const permission = await Notification.requestPermission();
    if(permission !== 'granted') throw new Error('כדי לקבל תזכורת צריך לאשר התראות בהודעת המערכת.');

    const registration = await ensureServiceWorker();
    let subscription = await registration.pushManager.getSubscription();
    if(!subscription){
      subscription = await registration.pushManager.subscribe({
        userVisibleOnly:true,
        applicationServerKey:urlBase64ToUint8Array(VAPID_PUBLIC_KEY)
      });
    }
    return subscription;
  }

  async function api(action, payload={}){
    const response = await fetch('/api/reminder', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({action, ...payload})
    });
    let data = {};
    try{ data = await response.json(); }catch(_e){}
    if(!response.ok) throw new Error(data?.error || 'שרת ההתראות עדיין לא מוכן. יש להשלים את פריסת Firebase Functions.');
    return data;
  }

  function setStatus(message='', kind=''){
    if(!ui.status) return;
    ui.status.textContent = message;
    ui.status.className = 'reminder-status' + (kind ? ` ${kind}` : '');
  }

  function setBusy(busy){
    [ui.save, ui.test, ui.disable].forEach(btn => { if(btn) btn.disabled = !!busy; });
  }

  function scheduleText(){
    return `א׳–ה׳ ${state.weekdayTime} • ו׳ ${state.fridayTime}`;
  }

  function updateLaunch(){
    if(!ui.launch) return;
    ui.launch.classList.toggle('is-on', state.enabled);
    const small = ui.launch.querySelector('small');
    small.textContent = state.enabled ? `פעילה • ${scheduleText()}` : `ברירת מחדל • ${scheduleText()}`;
    if(ui.disable) ui.disable.hidden = !state.enabled;
  }

  function currentSchedulePayload(subscription){
    return {
      weekdayTime:state.weekdayTime,
      fridayTime:state.fridayTime,
      scheduleVersion:SCHEDULE_VERSION,
      timezone:'Asia/Jerusalem',
      subscription:subscription.toJSON()
    };
  }

  async function syncExistingSubscription(){
    // No permission prompt here. This only upgrades devices that already had push enabled.
    if(!supportsPush() || Notification.permission !== 'granted') return;
    try{
      const registration = await ensureServiceWorker();
      const subscription = await registration.pushManager.getSubscription();
      if(!subscription) return;

      state.enabled = true;
      await api('save', currentSchedulePayload(subscription));
      saveState();
      migratedLegacyLocalState = false;
      updateLaunch();
    }catch(_e){
      // Do not interrupt normal app use if a background schedule sync fails.
    }
  }

  async function saveReminder(){
    const weekdayTime = ui.weekdayTime.value;
    const fridayTime = ui.fridayTime.value;
    if(!isValidTime(weekdayTime) || !isValidTime(fridayTime)){
      setStatus('בחרו שעות תקינות.', 'error');
      return;
    }
    state.weekdayTime = weekdayTime;
    state.fridayTime = fridayTime;

    setBusy(true); setStatus('מחבר את המכשיר להתראות…');
    try{
      const subscription = await ensureSubscription();
      await api('save', currentSchedulePayload(subscription));
      state.enabled = true;
      saveState();
      migratedLegacyLocalState = false;
      updateLaunch();
      setStatus(`התזכורות פעילות: א׳–ה׳ בשעה ${weekdayTime}, וביום ו׳ בשעה ${fridayTime}.`, 'ok');
    }catch(err){ setStatus(err.message || 'לא הצלחתי להפעיל את התזכורות.', 'error'); }
    finally{ setBusy(false); }
  }

  async function testReminder(){
    setBusy(true); setStatus('שולח התראת בדיקה…');
    try{
      const subscription = await ensureSubscription();
      await api('test', {subscription:subscription.toJSON()});
      setStatus('נשלחה התראת בדיקה. היא אמורה להופיע בעוד רגע.', 'ok');
    }catch(err){ setStatus(err.message || 'לא הצלחתי לשלוח התראת בדיקה.', 'error'); }
    finally{ setBusy(false); }
  }

  async function disableReminder(){
    setBusy(true); setStatus('מכבה את התזכורות…');
    try{
      const registration = await ensureServiceWorker();
      const subscription = await registration.pushManager.getSubscription();
      if(subscription){
        await api('disable', {subscription:subscription.toJSON()});
        await subscription.unsubscribe().catch(()=>{});
      }
      state.enabled = false;
      saveState();
      updateLaunch();
      setStatus('התזכורות כובו.', 'ok');
    }catch(err){ setStatus(err.message || 'לא הצלחתי לכבות את התזכורות.', 'error'); }
    finally{ setBusy(false); }
  }

  function buildUI(){
    const tools = document.querySelector('.tools');
    if(!tools || document.getElementById('reminderLaunch')) return;

    const launch = document.createElement('button');
    launch.type = 'button'; launch.id = 'reminderLaunch'; launch.className = 'reminder-launch';
    launch.innerHTML = '<span class="reminder-main"><span class="reminder-icon">🔔</span><span><strong>תזכורות לרשימת ירקות</strong><small></small></span></span><span class="reminder-arrow">‹</span>';
    tools.insertAdjacentElement('afterend', launch);

    const backdrop = document.createElement('div');
    backdrop.className = 'reminder-backdrop'; backdrop.id = 'reminderBackdrop';
    backdrop.innerHTML = `
      <section class="reminder-sheet" role="dialog" aria-modal="true" aria-labelledby="reminderTitle">
        <div class="reminder-head">
          <div><h3 id="reminderTitle">🔔 הגדרות תזכורות</h3><p>ברירת המחדל: א׳–ה׳ ב־17:50, יום ו׳ ב־13:30. בשבת לא נשלחת התראה.</p></div>
          <button class="reminder-close" id="reminderClose" type="button" aria-label="סגירה">×</button>
        </div>
        <div class="reminder-body">
          <div class="reminder-time-grid">
            <label class="reminder-time-group" for="reminderWeekdayTime">
              <span class="reminder-time-label">ימים א׳–ה׳</span>
              <input class="reminder-time" id="reminderWeekdayTime" type="time" step="60" value="${state.weekdayTime}">
            </label>
            <label class="reminder-time-group" for="reminderFridayTime">
              <span class="reminder-time-label">יום ו׳</span>
              <input class="reminder-time" id="reminderFridayTime" type="time" step="60" value="${state.fridayTime}">
            </label>
          </div>
          <div class="reminder-info" id="reminderInfo">השעות הן לפי שעון ישראל. שבת נשארת ללא התראה. אפשר לשנות את שתי השעות בכל רגע.</div>
          <div class="reminder-status" id="reminderStatus" aria-live="polite"></div>
          <div class="reminder-actions">
            <button class="reminder-save" id="reminderSave" type="button">הפעל / שמור תזכורות</button>
            <button class="reminder-test" id="reminderTest" type="button">שלח בדיקה עכשיו</button>
            <button class="reminder-disable" id="reminderDisable" type="button">כבה תזכורות</button>
          </div>
        </div>
      </section>`;
    document.body.appendChild(backdrop);

    const introBackdrop = document.createElement('div');
    introBackdrop.className = 'reminder-intro-backdrop';
    introBackdrop.id = 'reminderIntroBackdrop';
    introBackdrop.innerHTML = `
      <section class="reminder-intro" role="dialog" aria-modal="true" aria-labelledby="reminderIntroTitle">
        <div class="reminder-intro-icon" aria-hidden="true">🔔</div>
        <h3 id="reminderIntroTitle">רוצים תזכורת לספירת המלאי?</h3>
        <p>אפשר לקבל התראה אוטומטית כדי לא לשכוח להכין את הרשימה: א׳–ה׳ ב־17:50 וביום ו׳ ב־13:30. את השעות אפשר לשנות בכל רגע.</p>
        <div class="reminder-intro-actions">
          <button class="reminder-intro-enable" id="reminderIntroEnable" type="button">הפעל תזכורות</button>
          <button class="reminder-intro-later" id="reminderIntroLater" type="button">לא עכשיו</button>
        </div>
      </section>`;
    document.body.appendChild(introBackdrop);

    ui = {
      launch, backdrop,
      close:document.getElementById('reminderClose'),
      weekdayTime:document.getElementById('reminderWeekdayTime'),
      fridayTime:document.getElementById('reminderFridayTime'),
      info:document.getElementById('reminderInfo'),
      status:document.getElementById('reminderStatus'),
      save:document.getElementById('reminderSave'),
      test:document.getElementById('reminderTest'),
      disable:document.getElementById('reminderDisable'),
      introBackdrop,
      introEnable:document.getElementById('reminderIntroEnable'),
      introLater:document.getElementById('reminderIntroLater')
    };

    if(!supportsPush()){
      ui.info.classList.add('warn');
      ui.info.textContent = 'במכשיר או בדפדפן הזה אין תמיכה ב-Web Push. אפשר להמשיך להשתמש באפליקציה כרגיל.';
    }else if(isIOS() && !isStandalone()){
      ui.info.classList.add('warn');
      ui.info.textContent = 'באייפון: יש להוסיף את האתר למסך הבית, לפתוח אותו מהאייקון ורק אז לאשר התראות.';
    }else if(Notification.permission !== 'granted'){
      ui.info.textContent = 'ברירת המחדל כבר מוכנה: א׳–ה׳ 17:50 ויום ו׳ 13:30. בפעם הראשונה יש ללחוץ על “הפעל / שמור תזכורות” ולאשר התראות במכשיר.';
    }

    launch.onclick = () => {
      ui.weekdayTime.value = state.weekdayTime;
      ui.fridayTime.value = state.fridayTime;
      setStatus('');
      backdrop.classList.add('show');
    };
    ui.close.onclick = () => backdrop.classList.remove('show');
    backdrop.addEventListener('click', e => { if(e.target === backdrop) backdrop.classList.remove('show'); });
    ui.save.onclick = saveReminder;
    ui.test.onclick = testReminder;
    ui.disable.onclick = disableReminder;
    ui.introEnable.onclick = () => {
      ui.introBackdrop.classList.remove('show');
      launch.click();
    };
    ui.introLater.onclick = () => ui.introBackdrop.classList.remove('show');
    ui.introBackdrop.addEventListener('click', e => {
      if(e.target === ui.introBackdrop) ui.introBackdrop.classList.remove('show');
    });
    updateLaunch();
  }

  function showIntro(){
    if(!ui.introBackdrop) return;
    // Mark immediately so this recommendation is truly one-time on this device/browser.
    markIntroSeen();
    ui.introBackdrop.classList.add('show');
  }

  async function init(){
    loadState();
    const showFirstTimeIntro = await shouldShowIntro();
    buildUI();
    if('serviceWorker' in navigator){
      try{ await ensureServiceWorker(); }catch(_e){}
    }
    if(migratedLegacyLocalState) saveState();
    await syncExistingSubscription();
    if(showFirstTimeIntro && !state.enabled){
      setTimeout(showIntro, 350);
    }
  }

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once:true});
  else init();
})();
