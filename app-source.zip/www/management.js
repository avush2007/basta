(() => {
  'use strict';

  const SUPABASE_URL = 'https://pmariemlrqgmvokxnuzi.supabase.co';
  const SUPABASE_KEY = 'sb_publishable_zeidDOVz7x1A19WcaxZcgg_GElmONEw';
  const LOCAL_STATE_BASE_KEY = 'bastaInventoryV5';
  const STORE_CODE_KEY = 'supermarketPlatformStoreCode';
  const PLATFORM_NAME = 'Supermarket OS';
  const BUSINESS_NAME = 'הסופר';
  const APP_NAME = 'ניהול סופר';
  let WHATSAPP_BUSINESS_NAME = 'הסופר';
  const APP_VERSION = '3.0.0';
  const VAPID_PUBLIC_KEY = 'BB0-WFAJvT47CC5k79cL23zMpYgSbv5ZfWe9NhM7ADKZNJ4MJP3ExhUoSmvcc3epiJkraaqWDYabUhBiqXkNAnQ';
  const UPDATE_BUCKET = 'app-updates';
  const LATEST_MANIFEST_URL = `${SUPABASE_URL}/storage/v1/object/public/${UPDATE_BUCKET}/latest.json`;

  const root = document.getElementById('managementRoot');
  if (!root) return;
  const syncManagementOverlay = () => document.documentElement.classList.toggle('mg-overlay-active', !root.classList.contains('hidden'));
  new MutationObserver(syncManagementOverlay).observe(root,{attributes:true,attributeFilter:['class']});
  syncManagementOverlay();

  let sb = null;
  let session = null;
  let profile = null;
  let business = null;
  let cloudReady = false;
  let syncTimer = null;
  let syncStatus = 'מתחבר לענן…';
  let cloudConfig = null;
  let cloudConfigSignature = '';
  let editingUserId = null;
  let notificationChannel = null;
  let supplierCart = new Map();
  let supplierCartSupplierId = null;
  let currentSupplier = null;
  let currentSupplierProducts = [];
  let currentCatalogProducts = [];
  let editingSourceOrderId = null;
  let supplierReminderTimer = null;
  let modulePermissions = new Map();
  let editingDraftOrderId = null;
  let shortageComposer = [];
  let signageSettings = new Map();
  let signageProduceCatalog = [];
  let isPlatformAdminFlag = false;
  let businessFeatures = new Map();

  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const roleLabel = r => r === 'super_admin' ? 'סופר אדמין' : r === 'manager' ? 'מנהל' : 'עובד';
  const deptLabel = d => d === 'cashier' ? 'קופות' : d === 'warehouse' ? 'מחסן' : '';
  const isManagement = () => ['super_admin','manager'].includes(profile?.role);
  const isSuperAdmin = () => isPlatformAdminFlag || profile?.role === 'super_admin';
  const MODULE_DEFS = [
    {key:'inventory',icon:'🥦',label:'ספירת ירקות ומלאי'},
    {key:'calculator',icon:'🧮',label:'מחשבון מחיר לצרכן'},
    {key:'history',icon:'🗓️',label:'היסטוריית ספירות'},
    {key:'suppliers',icon:'📦',label:'הזמנות מספקים'},
    {key:'tasks',icon:'✅',label:'משימות לעובדים'},
    {key:'signage',icon:'🖨️',label:'שילוט להדפסה'},
    {key:'shortages',icon:'📋',label:'רשימות חוסרים'}
  ];
  const AUDIENCE_DEFS = [
    {key:'manager',label:'מנהלים'},
    {key:'employee_cashier',label:'עובדי קופות'},
    {key:'employee_warehouse',label:'עובדי מחסן'}
  ];
  const DEFAULT_MODULE_ACCESS = {
    manager:{inventory:true,calculator:true,history:true,suppliers:true,tasks:true,signage:true,shortages:true},
    employee_cashier:{inventory:true,calculator:true,history:false,suppliers:true,tasks:true,signage:true,shortages:true},
    employee_warehouse:{inventory:true,calculator:true,history:false,suppliers:true,tasks:true,signage:true,shortages:true}
  };
  const myAudienceKey = () => profile?.role==='manager' ? 'manager' : profile?.role==='employee' ? `employee_${profile?.department||'warehouse'}` : 'super_admin';
  const canUseModule = key => {
    if(businessFeatures.has(key) && businessFeatures.get(key)===false)return false;
    if(isSuperAdmin())return true;
    const audience=myAudienceKey(), stored=modulePermissions.get(`${audience}|${key}`);
    return stored===undefined ? !!DEFAULT_MODULE_ACCESS[audience]?.[key] : !!stored;
  };
  const requireModule = (key, fallback=renderDashboard) => { if(canUseModule(key))return true; alert('אין לך הרשאה למודול הזה.'); fallback?.(); return false; };
  const initials = v => { const p=String(v||'').trim().split(/\s+/).filter(Boolean); return (p[0]?.[0]||'ב')+(p[1]?.[0]||''); };
  const localStateKey = () => business?.id ? `${LOCAL_STATE_BASE_KEY}:${business.id}` : LOCAL_STATE_BASE_KEY;
  const localRaw = () => { try { return localStorage.getItem(localStateKey()) || ''; } catch(_e){ return ''; } };
  const setLocalRaw = v => { try { localStorage.setItem(localStateKey(), v); } catch(_e){} };
  const todayISO = () => { const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
  const formatDate = iso => { const p=String(iso||'').split('-'); return p.length===3 ? `${p[2]}/${p[1]}/${p[0]}` : String(iso||''); };
  const formatDateTime = iso => { try { return new Intl.DateTimeFormat('he-IL',{dateStyle:'short',timeStyle:'short'}).format(new Date(iso)); } catch(_e){ return String(iso||''); } };
  const parseState = raw => { try { const s=typeof raw==='string'?JSON.parse(raw):raw; return s && typeof s==='object' ? s : {}; } catch(_e){ return {}; } };
  const normalizeRows = rows => Array.isArray(rows) ? rows.slice(0,40).map(r=>({name:String(r?.name??''),preset:!!r?.preset})) : [];

  function setSync(t){
    syncStatus=t;
    document.querySelectorAll('[data-sync-status]').forEach(e=>e.textContent=t);
  }

  function extractConfig(state){
    if (!state || typeof state !== 'object') return {};
    return {
      columns: state.columns || {},
      itemCats: state.itemCats || {},
      apples: normalizeRows(state.apples),
      yokneam: normalizeRows(state.yokneam),
      poultry: normalizeRows(state.poultry),
      sectionTitles: state.sectionTitles || {}
    };
  }

  function applyConfig(raw, config){
    if (!config || typeof config !== 'object' || !Object.keys(config).length) return raw || '';
    const s = parseState(raw || '{}');
    const oldBackup = {...(s.backupQty||{})}, oldShop = {...(s.shopQty||{})}, oldQty = {...(s.qty||{})};
    const oldRows = kind => new Map((Array.isArray(s[kind])?s[kind]:[]).map(r=>[String(r?.name||'').trim(),String(r?.qty??'')]));
    const appleQty=oldRows('apples'), yokQty=oldRows('yokneam'), poultryQty=oldRows('poultry');

    if (config.columns && typeof config.columns==='object') s.columns=JSON.parse(JSON.stringify(config.columns));
    if (config.itemCats && typeof config.itemCats==='object') s.itemCats={...config.itemCats};
    if (config.sectionTitles && typeof config.sectionTitles==='object') s.sectionTitles={...config.sectionTitles};
    const fixed = ['right','middle','leftTop','leftHerbs'].flatMap(k=>Array.isArray(s.columns?.[k])?s.columns[k]:[]).map(String);
    s.backupQty = Object.fromEntries(fixed.map(n=>[n,String(oldBackup[n]??'')]));
    s.shopQty = Object.fromEntries(fixed.map(n=>[n,String(oldShop[n]??'')]));
    s.qty = Object.fromEntries(fixed.map(n=>[n,String(oldQty[n]??'')]));
    const rebuild = (cfgRows, map) => normalizeRows(cfgRows).map(r=>({name:r.name,qty:map.get(r.name)||'',preset:r.preset}));
    if (Array.isArray(config.apples)) s.apples=rebuild(config.apples,appleQty);
    if (Array.isArray(config.yokneam)) s.yokneam=rebuild(config.yokneam,yokQty);
    if (Array.isArray(config.poultry)) s.poultry=rebuild(config.poultry,poultryQty);
    return JSON.stringify(s);
  }

  function renderLogin(message=''){
    removeAppNav();
    root.classList.remove('hidden');
    const remembered=(()=>{try{return localStorage.getItem(STORE_CODE_KEY)||'';}catch(_e){return '';}})();
    root.innerHTML=`<div class="mg-login mg-platform-login"><div class="mg-login-card mg-platform-login-card"><div class="mg-platform-wordmark"><span>◫</span><div><b>${esc(PLATFORM_NAME)}</b><small>ניהול חכם לסופר</small></div></div><div class="mg-login-logo">🏪</div><h1>כניסה לסופר</h1><p>הזינו את קוד הסופר שקיבלתם מהמנהל ואז התחברו עם המשתמש שלכם.</p><form id="mgLogin"><div class="mg-field"><label>קוד סופר</label><input id="mgStoreCode" value="${esc(remembered)}" autocomplete="organization" autocapitalize="characters" placeholder="לדוגמה: AHIMDAVID" required></div><div class="mg-field"><label>אימייל</label><input id="mgEmail" type="email" autocomplete="username" required></div><div class="mg-field"><label>סיסמה</label><input id="mgPass" type="password" autocomplete="current-password" required></div><button id="mgLoginBtn" class="mg-primary">כניסה למערכת</button><div id="mgLoginErr" class="mg-error ${message?'show':''}">${esc(message)}</div></form><div class="mg-help">כל סופר מופרד מהסופרים האחרים. הנתונים וההרשאות נטענים לפי קוד הסופר.</div></div></div>`;
    document.getElementById('mgLogin').onsubmit=login;
  }

  async function login(e){
    e.preventDefault();
    const btn=document.getElementById('mgLoginBtn'), err=document.getElementById('mgLoginErr');
    const storeCode=document.getElementById('mgStoreCode').value.trim().toUpperCase();
    btn.disabled=true; btn.textContent='מתחבר…'; err.classList.remove('show');
    const {data,error}=await sb.auth.signInWithPassword({email:document.getElementById('mgEmail').value.trim(),password:document.getElementById('mgPass').value});
    if(error){ err.textContent='לא הצלחתי להתחבר. בדוק את האימייל והסיסמה.'; err.classList.add('show'); btn.disabled=false; btn.textContent='כניסה למערכת'; return; }
    session=data.session;
    const pick=await sb.rpc('select_business_by_code',{p_store_code:storeCode});
    if(pick.error){ await sb.auth.signOut(); session=null; err.textContent=pick.error.message?.includes('NO_STORE_ACCESS')?'המשתמש אינו משויך לסופר הזה.':pick.error.message?.includes('STORE_NOT_FOUND')?'קוד הסופר לא נמצא.':'לא ניתן להיכנס לסופר הזה.';err.classList.add('show');btn.disabled=false;btn.textContent='כניסה למערכת';return; }
    try{localStorage.setItem(STORE_CODE_KEY,storeCode);}catch(_e){}
    await afterLogin(true);
  }

  async function loadModulePermissions(){
    modulePermissions=new Map();
    const {data,error}=await sb.from('module_permissions').select('audience_key,module_key,allowed').eq('business_id',profile.business_id);
    if(error)return;
    (data||[]).forEach(r=>modulePermissions.set(`${r.audience_key}|${r.module_key}`,!!r.allowed));
  }

  async function loadBusinessFeatures(featuresObject=null){
    businessFeatures=new Map();
    if(featuresObject&&typeof featuresObject==='object')Object.entries(featuresObject).forEach(([k,v])=>businessFeatures.set(k,!!v));
    if(businessFeatures.size)return;
    const {data}=await sb.from('business_features').select('feature_key,enabled').eq('business_id',profile.business_id);
    (data||[]).forEach(x=>businessFeatures.set(x.feature_key,!!x.enabled));
  }

  async function chooseBusinessForSession(){
    const remembered=(()=>{try{return localStorage.getItem(STORE_CODE_KEY)||'';}catch(_e){return '';}})();
    if(remembered){const r=await sb.rpc('select_business_by_code',{p_store_code:remembered});if(!r.error)return true;}
    const {data,error}=await sb.rpc('list_my_businesses');
    if(error)throw error;
    if(!data?.length)return false;
    if(data.length===1){const r=await sb.rpc('select_business',{p_business_id:data[0].business_id});if(!r.error){try{localStorage.setItem(STORE_CODE_KEY,data[0].store_code||'');}catch(_e){}return true;}}
    renderStoreChooser(data);return null;
  }

  function renderStoreChooser(stores){
    removeAppNav();root.classList.remove('hidden');
    root.innerHTML=`<div class="mg-login mg-platform-login"><div class="mg-login-card mg-store-chooser"><div class="mg-platform-wordmark"><span>◫</span><div><b>${esc(PLATFORM_NAME)}</b><small>בחירת סופר</small></div></div><h1>לאיזה סופר נכנסים?</h1><p>החשבון שלך משויך ליותר מסופר אחד.</p><div class="mg-store-choice-list">${stores.map(s=>`<button data-store-pick="${esc(s.business_id)}" data-store-code="${esc(s.store_code||'')}"><span class="mg-store-choice-logo">${s.logo_url?`<img src="${esc(s.logo_url)}" alt="">`:'🏪'}</span><span><b>${esc(s.name)}</b><small>${esc(s.store_code)} • ${esc(roleLabel(s.member_role))}</small></span><i>←</i></button>`).join('')}</div><button id="mgStoreChooserLogout" class="mg-secondary">יציאה</button></div></div>`;
    document.querySelectorAll('[data-store-pick]').forEach(b=>b.onclick=async()=>{b.disabled=true;const r=await sb.rpc('select_business',{p_business_id:b.dataset.storePick});if(r.error){alert(r.error.message);b.disabled=false;return;}try{localStorage.setItem(STORE_CODE_KEY,b.dataset.storeCode||'');}catch(_e){}await afterLogin(true);});
    document.getElementById('mgStoreChooserLogout').onclick=logout;
  }

  async function afterLogin(businessAlreadySelected=false){
    cloudReady=false; setSync('מתחבר לענן…');
    try{
      if(!businessAlreadySelected){const picked=await chooseBusinessForSession();if(picked===null)return;if(!picked)return renderUnassigned();}
    }catch(err){return renderSetup(err.message||'');}
    const {data:ctx,error}=await sb.rpc('get_current_business_context');
    if(error){
      if(String(error.message||'').includes('NO_BUSINESS_MEMBERSHIP')) return renderUnassigned();
      if(String(error.message||'').includes('USER_DISABLED')) return renderDisabled();
      return renderSetup(error.message||'');
    }
    profile=ctx?.profile; business=ctx?.business; isPlatformAdminFlag=!!ctx?.is_platform_admin;
    if(!profile||!business)return renderUnassigned();
    WHATSAPP_BUSINESS_NAME=business?.name||'הסופר';
    try{localStorage.setItem(STORE_CODE_KEY,business?.store_code||'');}catch(_e){}
    document.documentElement.style.setProperty('--tenant-accent',business?.accent_color||'#16a34a');
    await loadBusinessFeatures(ctx?.features);
    await loadModulePermissions();
    if(canUseModule('inventory')){
      await loadCloudConfig();
      const reloaded=await syncFromCloud();
      if(reloaded) return;
    }else{ cloudReady=true; setSync('מחובר לענן ✓'); }
    applyRoleToInventory();startNotificationRealtime();renderDashboard();
    const openTarget=new URLSearchParams(location.search).get('open');
    if(openTarget&&canOpenAppTarget(openTarget)){history.replaceState({},'',location.pathname);setTimeout(()=>openAppTarget(openTarget),0);}
  }

  function renderSetup(detail){
    removeAppNav();root.classList.remove('hidden');
    root.innerHTML=`<div class="mg-login"><div class="mg-login-card"><div class="mg-login-logo">🛠️</div><h1>נדרש עדכון למסד הנתונים</h1><p>ההתחברות הצליחה, אבל תשתית ה‑Multi‑tenant עדיין לא הוגדרה.</p><div class="mg-setup"><b>Supabase → SQL Editor</b><br>הרץ פעם אחת את <b>v3.0.0-multitenant-platform.sql</b>.</div><div class="mg-help">${esc(detail)}</div><button id="mgRetry" class="mg-primary" style="margin-top:14px">בדיקה מחדש</button></div></div>`;
    document.getElementById('mgRetry').onclick=()=>afterLogin(false);
  }
  function renderUnassigned(){ root.classList.remove('hidden'); root.innerHTML=`<div class="mg-login"><div class="mg-login-card"><div class="mg-login-logo">👤</div><h1>המשתמש לא משויך לסופר</h1><p>פנה למנהל הסופר או למנהל הפלטפורמה.</p><button id="mgOut2" class="mg-primary">יציאה</button></div></div>`; document.getElementById('mgOut2').onclick=logout; }
  function renderDisabled(){ root.classList.remove('hidden'); root.innerHTML=`<div class="mg-login"><div class="mg-login-card"><div class="mg-login-logo">⛔</div><h1>הגישה מושבתת</h1><p>הגישה לסופר הזה הושבתה.</p><button id="mgOut3" class="mg-primary">יציאה</button></div></div>`; document.getElementById('mgOut3').onclick=logout; }

  async function loadCloudConfig(){
    const {data,error}=await sb.from('inventory_configuration').select('config_json,updated_at').eq('business_id',profile.business_id).maybeSingle();
    if(!error && data?.config_json){ cloudConfig=data.config_json; cloudConfigSignature=JSON.stringify(cloudConfig); }
  }

  async function saveCloudConfigFromState(state){
    if(!isManagement()) return;
    const config=extractConfig(state), sig=JSON.stringify(config);
    if(sig===cloudConfigSignature) return;
    const {error}=await sb.from('inventory_configuration').upsert({business_id:profile.business_id,config_json:config,updated_by:session.user.id,updated_at:new Date().toISOString()},{onConflict:'business_id'});
    if(!error){ cloudConfig=config; cloudConfigSignature=sig; }
  }

  async function syncFromCloud(){
    const {data,error}=await sb.from('inventory_app_state').select('state_json,updated_at').eq('business_id',profile.business_id).maybeSingle();
    if(error){ setSync('שגיאת סנכרון'); return false; }
    const local=localRaw();
    const localState=parseState(local||'{}'), cloudState=parseState(data?.state_json||'{}');
    // At the first login after midnight, never resurrect yesterday's quantities from the shared snapshot.
    let chosen=(local && localState.date===todayISO() && cloudState.date && cloudState.date!==todayISO()) ? local : (data?.state_json || local || '');
    if(cloudConfig) chosen=applyConfig(chosen,cloudConfig);
    else if(chosen && isManagement()) await saveCloudConfigFromState(parseState(chosen));

    if(chosen && chosen!==local){ setLocalRaw(chosen); location.reload(); return true; }
    if(!data?.state_json && chosen) await pushState(chosen);
    if(chosen) await upsertDailyHistory(chosen).catch(()=>{});
    cloudReady=true; setSync('מסונכרן לענן ✓');
    return false;
  }

  async function pushState(raw){
    const {error}=await sb.from('inventory_app_state').upsert({business_id:profile.business_id,state_json:raw,updated_by:session.user.id,updated_at:new Date().toISOString()},{onConflict:'business_id'});
    if(error){ setSync('לא סונכרן'); throw error; }
    await upsertDailyHistory(raw).catch(()=>{});
    setSync('מסונכרן לענן ✓');
  }

  async function upsertDailyHistory(raw){
    const s=parseState(raw), inventoryDate=/^\d{4}-\d{2}-\d{2}$/.test(String(s.date||''))?s.date:todayISO();
    const {error}=await sb.from('inventory_daily_history').upsert({business_id:profile.business_id,inventory_date:inventoryDate,state_json:raw,updated_by:session.user.id,updated_at:new Date().toISOString()},{onConflict:'business_id,inventory_date'});
    if(error) throw error;
  }

  function queueState(raw,state){
    if(!cloudReady||!raw||!canUseModule('inventory'))return;
    clearTimeout(syncTimer); setSync('שומר…');
    syncTimer=setTimeout(async()=>{
      try { await pushState(raw); await saveCloudConfigFromState(state); }
      catch(_e){}
    },500);
  }

  window.addEventListener('basta:state-saved',e=>{
    try { const state=e.detail?.state||{}; queueState(JSON.stringify(state),state); } catch(_e){}
  });

  function applyRoleToInventory(){
    if(!canUseModule('inventory'))return;
    const edit=document.getElementById('listEditButton'), reset=document.getElementById('resetListButton');
    if(edit) edit.style.display=isManagement()?'':'none';
    if(reset) reset.style.display=isManagement()?'':'none';
  }

  function dashboardCard(id,icon,badge,title,desc,active=true){
    const tag=active?'button':'div';
    return `<${tag}${id?` id="${id}"`:''} data-module-card data-title="${esc(title)} ${esc(desc)}" class="mg-card${active?' mg-clickable':''}"><div class="mg-card-leading"><div class="mg-icon">${icon}</div><div class="mg-card-copy"><div class="mg-card-title-row"><h3>${title}</h3><span class="mg-badge${active?'':' soon'}">${badge}</span></div><p>${desc}</p></div></div>${active?'<div class="mg-card-chevron">‹</div>':''}</${tag}>`;
  }
  function dashboardSection(title,subtitle,cards){
    const html=(cards||[]).filter(Boolean).join('');
    if(!html)return '';
    return `<section class="mg-dashboard-section" data-dashboard-section><div class="mg-section-head"><div><h2>${esc(title)}</h2><p>${esc(subtitle)}</p></div></div><div class="mg-grid">${html}</div></section>`;
  }
  const moduleLabelMap=()=>new Map([
    ...MODULE_DEFS.map(m=>[m.key,{label:m.label,icon:m.icon}]),
    ['users',{label:'משתמשים',icon:'👥'}],['permissions',{label:'הרשאות מודולים',icon:'🔐'}],['updates',{label:'עדכוני מערכת',icon:'⬆️'}],
    ['catalog',{label:'קטלוג הזמנות ללקוחות',icon:'🛒'}],['developer',{label:'Developer Console',icon:'🧩'}],['home',{label:'בית',icon:'⌂'}],['notifications',{label:'התראות',icon:'🔔'}],['profile',{label:'הפרופיל שלי',icon:'👤'}]
  ]);
  function featureEnabled(key){return isPlatformAdminFlag || !businessFeatures.has(key) || businessFeatures.get(key)!==false;}
  function canOpenAppTarget(key){
    if(key==='developer')return isPlatformAdminFlag;
    if(!featureEnabled(key))return false;
    if(MODULE_DEFS.some(m=>m.key===key))return canUseModule(key);
    if(key==='users'||key==='updates')return isSuperAdmin();
    if(key==='permissions'||key==='catalog')return isManagement();
    return ['home','notifications','profile'].includes(key);
  }
  function openAppTarget(key){
    document.getElementById('mgMobileMoreSheet')?.remove();
    const map={home:renderDashboard,notifications:renderNotifications,profile:renderMyProfile,inventory:openInventory,calculator:renderCalculator,history:renderHistory,suppliers:renderSuppliers,tasks:renderTasks,signage:renderSignage,shortages:renderShortages,catalog:renderOrderCatalogAdmin,users:renderUsers,permissions:renderModulePermissions,updates:renderUpdates,developer:renderDeveloperConsole};
    if(!canOpenAppTarget(key))return alert('אין לך הרשאה למסך הזה.');
    map[key]?.();
  }
  function removeAppNav(){
    document.getElementById('mgGlobalBottomNav')?.remove();
    document.getElementById('mgDesktopSidebar')?.remove();
    document.getElementById('mgMobileMoreSheet')?.remove();
  }
  function mobileMoreSheet(active=''){
    const labels=moduleLabelMap();
    const keys=['shortages','suppliers','inventory','signage','calculator','tasks','history','catalog','users','permissions','updates','developer','notifications','profile'].filter(canOpenAppTarget);
    document.getElementById('mgMobileMoreSheet')?.remove();
    document.body.insertAdjacentHTML('beforeend',`<div id="mgMobileMoreSheet" class="mg-mobile-more-overlay"><button class="mg-more-scrim" data-close-more aria-label="סגור"></button><section class="mg-mobile-more"><div class="mg-more-handle"></div><div class="mg-more-head"><div><b>כל הכלים</b><small>גישה מהירה לכל מה שמותר לך</small></div><button data-close-more class="mg-more-close">×</button></div><div class="mg-more-grid">${keys.map(k=>{const x=labels.get(k)||{label:k,icon:'•'};return `<button data-more-target="${k}" class="${active===k?'active':''}"><span>${x.icon}</span><b>${esc(x.label)}</b></button>`}).join('')}</div><button class="mg-more-logout" data-more-logout>יציאה מהמערכת</button></section></div>`);
    const sheet=document.getElementById('mgMobileMoreSheet');
    sheet.querySelectorAll('[data-close-more]').forEach(b=>b.onclick=()=>sheet.remove());
    sheet.querySelectorAll('[data-more-target]').forEach(b=>b.onclick=()=>openAppTarget(b.dataset.moreTarget));
    sheet.querySelector('[data-more-logout]').onclick=logout;
  }
  function desktopSidebarHtml(active=''){
    const labels=moduleLabelMap();
    const section=(title,keys)=>{const ok=keys.filter(canOpenAppTarget);if(!ok.length)return '';return `<div class="mg-side-section"><small>${esc(title)}</small>${ok.map(k=>{const x=labels.get(k);return `<button data-side-target="${k}" class="${active===k?'active':''}"><span>${x.icon}</span><b>${esc(x.label)}</b></button>`}).join('')}</div>`};
    const name=profile?.full_name||profile?.email||'משתמש';
    return `<aside id="mgDesktopSidebar" class="mg-desktop-sidebar"><div class="mg-side-brand"><div class="mg-side-logo">🏪</div><div><b>${esc(business?.name||BUSINESS_NAME)}</b><small>${esc(PLATFORM_NAME)}</small></div></div><nav>${section('ראשי',['home'])}${section('עבודה שוטפת',['shortages','suppliers','inventory','signage','calculator'])}${section('צוות ומעקב',['tasks','history'])}${section('ניהול',['catalog','users','permissions','updates'])}${isPlatformAdminFlag?section('פלטפורמה',['developer']):''}</nav><div class="mg-side-user"><button data-side-target="profile"><span class="mg-side-avatar">${esc(initials(name))}</span><span><b>${esc(name)}</b><small>${esc(roleLabel(profile?.role)+(profile?.department?' • '+deptLabel(profile.department):''))}</small></span></button><button data-side-logout title="יציאה">↪</button></div></aside>`;
  }
  function mountAppNav(active=''){
    removeAppNav();
    if(root.classList.contains('hidden')||!session||!profile)return;
    active=active||root.dataset.activeModule||'';
    document.body.insertAdjacentHTML('beforeend',desktopSidebarHtml(active));
    const side=document.getElementById('mgDesktopSidebar');
    side?.querySelectorAll('[data-side-target]').forEach(b=>b.onclick=()=>openAppTarget(b.dataset.sideTarget));
    const out=side?.querySelector('[data-side-logout]');if(out)out.onclick=logout;
    const quick=['shortages','suppliers','signage'].filter(canOpenAppTarget);
    for(const k of ['inventory','tasks','calculator'])if(quick.length<3&&canOpenAppTarget(k)&&!quick.includes(k))quick.push(k);
    const labels=moduleLabelMap();
    const bottom=[{key:'home',label:'בית',icon:'⌂'},...quick.map(k=>({key:k,...labels.get(k)})),{key:'more',label:'עוד',icon:'•••'}];
    document.body.insertAdjacentHTML('beforeend',`<nav id="mgGlobalBottomNav" class="mg-bottom-nav mg-bottom-nav-v24" style="--mg-nav-count:${bottom.length}" aria-label="ניווט ראשי">${bottom.map(x=>`<button data-app-target="${x.key}" class="${active===x.key||((x.key==='more')&&!['home',...quick].includes(active))?'active':''}"><span>${x.icon}</span><b>${esc(x.label)}</b>${x.key==='more'?'<i data-notification-badge hidden>0</i>':''}</button>`).join('')}</nav>`);
    const nav=document.getElementById('mgGlobalBottomNav');
    nav.querySelectorAll('[data-app-target]').forEach(b=>b.onclick=()=>b.dataset.appTarget==='more'?mobileMoreSheet(active):openAppTarget(b.dataset.appTarget));
    refreshUnreadCount().catch(()=>{});
    syncMobileNavWithViewport();
  }

  let mobileViewportBound=false;
  function syncMobileNavWithViewport(){
    const vv=window.visualViewport;
    const isFormField=el=>!!el&&['INPUT','TEXTAREA','SELECT'].includes(el.tagName);
    const apply=()=>{
      const nav=document.getElementById('mgGlobalBottomNav');
      if(!nav)return;
      const viewportHeight=vv?.height||window.innerHeight;
      const viewportKeyboard=(window.innerHeight-viewportHeight)>120;
      const fieldFocused=isFormField(document.activeElement);
      nav.classList.toggle('mg-keyboard-open',window.innerWidth<620&&(viewportKeyboard||fieldFocused));
    };
    apply();
    if(mobileViewportBound)return;
    mobileViewportBound=true;
    vv?.addEventListener('resize',apply,{passive:true});
    vv?.addEventListener('scroll',apply,{passive:true});
    window.addEventListener('resize',apply,{passive:true});
    document.addEventListener('focusin',apply,true);
    document.addEventListener('focusout',()=>setTimeout(apply,80),true);
  }

  function renderDashboard(){
    root.classList.remove('hidden');
    root.dataset.activeModule='home';
    const name=profile?.full_name||profile?.email||session?.user?.email||'משתמש';
    const firstName=String(name).trim().split(/\s+/)[0]||name;
    const dept=profile?.role==='employee'&&profile?.department?` • ${deptLabel(profile.department)}`:'';
    const daily=[
      canUseModule('shortages')?dashboardCard('mgShortages','📋','שוטף','רשימות חוסרים','מילוי חנות, עבודה מול המחסן ומעקב חוסרים.'):'' ,
      canUseModule('suppliers')?dashboardCard('mgSuppliers','📦','שוטף','הזמנות מספקים','טיוטות, קטלוגים, היסטוריה ושליחה לסוכן.'):'' ,
      canUseModule('inventory')?dashboardCard('mgInventory','🥦','שוטף','ספירת ירקות ומלאי','ספירה יומית, חדר גיבוי, חנות והפקת PDF.'):'' ,
      canUseModule('signage')?dashboardCard('mgSignage','🖨️','כלי','שילוט להדפסה','יצירת שילוט מחיר ומבצע לפי סוג התצוגה.'):'' ,
      canUseModule('calculator')?dashboardCard('mgCalculator','🧮','כלי','מחשבון מחיר לצרכן','עלות, רווח ומע״מ בחישוב מהיר.'):''
    ];
    const team=[
      canUseModule('tasks')?dashboardCard('mgTasks','✅','צוות','משימות לעובדים','חלוקת עבודה, דדליין, דחיפות ומעקב ביצוע.'):'' ,
      canUseModule('history')?dashboardCard('mgHistory','🗓️','מידע','היסטוריית ספירות','חזרה לספירות שנשמרו לפי יום.'):''
    ];
    const admin=[
      isPlatformAdminFlag?dashboardCard('mgDeveloper','🧩','פלטפורמה','Developer Console','יצירת סופרים, מיתוג, סטטוס ומודולים.'):'' ,
      isSuperAdmin()?dashboardCard('mgUsers','👥','ניהול','משתמשים','יצירת עובדים ומנהלים ושיוך למחלקות.'):'' ,
      isManagement()?dashboardCard('mgCustomerCatalog','🛒','לקוחות','קטלוג הזמנות ללקוחות','מוצרים, מבצעים, מחלקות והזמנות מהאתר.'):'' ,
      isManagement()?dashboardCard('mgModulePermissions','🔐','ניהול','הרשאות מודולים','קביעה מה כל סוג משתמש רשאי לראות ולעשות.'):'' ,
      isSuperAdmin()?dashboardCard('mgUpdates','⬆️','מערכת','עדכוני מערכת','פרסום גרסאות חדשות ישירות מהמערכת.'):''
    ];
    const todayLabel=new Intl.DateTimeFormat('he-IL',{weekday:'long',day:'numeric',month:'long'}).format(new Date());
    const quick=[
      canUseModule('shortages')?['shortages','📋','חוסרים']:null,
      canUseModule('suppliers')?['suppliers','📦','ספקים']:null,
      isManagement()?['catalog','🛒','הזמנות לקוחות']:null,
      canUseModule('signage')?['signage','🖨️','שילוט']:null
    ].filter(Boolean).slice(0,4);
    root.innerHTML=`<div class="mg-shell mg-shell-v210"><header class="mg-top"><div class="mg-top-in"><div class="mg-brand"><div class="mg-brand-mark">🏪</div><div><strong>${esc(APP_NAME)}</strong><span>${esc(business?.name||BUSINESS_NAME)}</span></div></div><div class="mg-user"><button class="mg-notify-btn" data-notifications type="button" aria-label="התראות">🔔<span data-notification-badge hidden>0</span></button><button id="mgProfileTop" class="mg-avatar mg-avatar-button" title="הפרופיל שלי">${esc(initials(name))}</button><div class="mg-user-meta"><b>${esc(name)}</b><small>${esc(roleLabel(profile?.role)+dept)}</small></div><button id="mgLogout" class="mg-logout">יציאה</button></div></div></header><main class="mg-main mg-dashboard mg-dashboard-v210"><section class="mg-command-hero"><div class="mg-command-grid"></div><div class="mg-command-copy"><span class="mg-command-eyebrow"><i></i>${esc(todayLabel)}</span><h1>בוקר טוב, ${esc(firstName)}.</h1><p>זה חדר הבקרה של הסופר — הזמנות, מלאי, צוות ולקוחות במסך אחד.</p><div class="mg-command-status"><span>${esc(syncStatus)}</span><span>V${APP_VERSION}</span></div></div><div class="mg-command-mark"><b>🏪</b><small>CONTROL</small></div></section><section class="mg-pulse-strip" id="mgDashboardPulse"><div class="mg-pulse-card loading"><span>●</span><b>טוען נתוני יום…</b></div></section>${quick.length?`<section class="mg-quick-launch mg-quick-v210"><div class="mg-quick-launch-head"><div><span>קיצורי דרך</span><b>מה עושים עכשיו?</b></div><small>פעולה אחת ואתם בפנים</small></div><div class="mg-quick-launch-grid">${quick.map((x,i)=>`<button data-quick-target="${x[0]}" style="--i:${i}"><span>${x[1]}</span><b>${esc(x[2])}</b><i>←</i></button>`).join('')}</div></section>`:''}<label class="mg-dashboard-search mg-dashboard-search-v210"><span>⌕</span><input id="mgDashboardSearch" type="search" placeholder="חיפוש פעולה במערכת…" autocomplete="off"><kbd>⌘ K</kbd></label>
      ${dashboardSection('עבודה שוטפת','הדברים שקורים לאורך היום.',daily)}
      ${dashboardSection('צוות ומעקב','משימות, היסטוריה ובקרה.',team)}
      ${dashboardSection('ניהול מערכת','לקוחות, משתמשים והגדרות.',admin)}
    </main></div>`;
    document.querySelectorAll('[data-quick-target]').forEach(b=>b.onclick=()=>openAppTarget(b.dataset.quickTarget));
    document.getElementById('mgLogout').onclick=logout;
    document.getElementById('mgProfileTop').onclick=renderMyProfile;
    document.getElementById('mgInventory')?.addEventListener('click',openInventory);
    document.getElementById('mgCalculator')?.addEventListener('click',renderCalculator);
    document.getElementById('mgHistory')?.addEventListener('click',renderHistory);
    document.getElementById('mgUsers')?.addEventListener('click',renderUsers);
    document.getElementById('mgCustomerCatalog')?.addEventListener('click',renderOrderCatalogAdmin);
    document.getElementById('mgModulePermissions')?.addEventListener('click',renderModulePermissions);
    document.getElementById('mgUpdates')?.addEventListener('click',renderUpdates);
    document.getElementById('mgDeveloper')?.addEventListener('click',renderDeveloperConsole);
    document.getElementById('mgTasks')?.addEventListener('click',renderTasks);
    document.getElementById('mgSuppliers')?.addEventListener('click',renderSuppliers);
    document.getElementById('mgSignage')?.addEventListener('click',renderSignage);
    document.getElementById('mgShortages')?.addEventListener('click',renderShortages);
    bindNotificationBell();mountAppNav('home');hydrateDashboardPulse();
    document.getElementById('mgDashboardSearch')?.addEventListener('input',e=>{
      const q=String(e.target.value||'').trim().toLocaleLowerCase('he');
      document.querySelectorAll('[data-module-card]').forEach(card=>{card.hidden=!!q&&!String(card.dataset.title||'').toLocaleLowerCase('he').includes(q);});
      document.querySelectorAll('[data-dashboard-section]').forEach(section=>{section.hidden=!section.querySelector('[data-module-card]:not([hidden])');});
    });
    if(canUseModule('suppliers'))scheduleSupplierReminderCheck();else{clearInterval(supplierReminderTimer);supplierReminderTimer=null;}
  }

  async function hydrateDashboardPulse(){
    const box=document.getElementById('mgDashboardPulse');if(!box||!profile?.business_id)return;
    const start=new Date();start.setHours(0,0,0,0);const iso=start.toISOString();
    const safe=async(p)=>{try{return await p;}catch(_){return {count:0,data:[]};}};
    const [orders,tasks,products,promos]=await Promise.all([
      safe(sb.from('customer_orders').select('id',{count:'exact',head:true}).eq('business_id',profile.business_id).gte('created_at',iso)),
      safe(sb.from('tasks').select('id',{count:'exact',head:true}).eq('business_id',profile.business_id).eq('is_active',true)),
      safe(sb.from('customer_catalog_products').select('id',{count:'exact',head:true}).eq('business_id',profile.business_id).eq('active',true)),
      safe(sb.from('customer_catalog_promotions').select('id',{count:'exact',head:true}).eq('business_id',profile.business_id).eq('active',true))
    ]);
    const cards=[
      ['🛍️',Number(orders.count||0),'הזמנות לקוחות היום','catalog'],
      ['✅',Number(tasks.count||0),'משימות פעילות','tasks'],
      ['🧺',Number(products.count||0),'מוצרים באתר','catalog'],
      ['🔥',Number(promos.count||0),'מבצעים מוגדרים','catalog']
    ];
    box.innerHTML=cards.map((c,i)=>`<button class="mg-pulse-card" data-pulse-target="${c[3]}" style="--i:${i}"><span>${c[0]}</span><div><b>${c[1].toLocaleString('he-IL')}</b><small>${c[2]}</small></div><i>←</i></button>`).join('');
    box.querySelectorAll('[data-pulse-target]').forEach(b=>b.onclick=()=>openAppTarget(b.dataset.pulseTarget));
  }

  function activeModuleFromTitle(title=''){
    const t=String(title);
    if(t.includes('התראות'))return 'notifications';
    if(t.includes('הפרופיל'))return 'profile';
    if(t.includes('משימות'))return 'tasks';
    if(t.includes('מחשבון'))return 'calculator';
    if(t.includes('היסטוריית ספירות'))return 'history';
    if(t.includes('הרשאות'))return 'permissions';
    if(t.includes('קטלוג הזמנות ללקוחות'))return 'catalog';
    if(t.includes('משתמשים'))return 'users';
    if(t.includes('הזמנה')||t.includes('הזמנות')||t.includes('קטלוג'))return 'suppliers';
    if(t.includes('שילוט'))return 'signage';
    if(t.includes('חוסרים'))return 'shortages';
    if(t.includes('עדכוני'))return 'updates';
    return '';
  }
  function shellHeader(title,icon='🥬'){
    root.dataset.activeModule=activeModuleFromTitle(title);
    return `<div class="mg-shell"><header class="mg-top mg-top-page"><div class="mg-top-in"><div class="mg-brand"><div class="mg-brand-mark">🏪</div><div><strong>${esc(APP_NAME)}</strong><span>${esc(business?.name||BUSINESS_NAME)}</span></div></div><div class="mg-page-top-actions"><button class="mg-notify-btn" data-notifications type="button" aria-label="התראות">🔔<span data-notification-badge hidden>0</span></button></div></div></header><main class="mg-main mg-page-main"><div class="mg-panel-head"><button id="mgPageBack" class="mg-back" aria-label="חזרה"><span>→</span><b>חזרה</b></button><div class="mg-page-title"><span>${icon}</span><div><small>אחים דוד יקנעם</small><h2>${esc(title)}</h2></div></div></div>`;
  }
  function bindBack(){ const b=document.getElementById('mgPageBack'); if(b)b.onclick=renderDashboard; bindNotificationBell(); mountAppNav(root.dataset.activeModule||''); }


  const localDateFromISO = value => {
    if(!value) return '';
    const d=new Date(value); if(Number.isNaN(d.getTime()))return '';
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  };
  const formatDue = value => value ? formatDateTime(value) : 'ללא דדליין';
  const assignmentLabel = t => t.assignment_type==='user' ? 'עובד ספציפי' : t.assignment_type==='department' ? deptLabel(t.assigned_department) : 'כל העובדים';
  const recurrenceLabel = t => t.recurrence==='daily' ? 'כל יום' : t.recurrence==='weekly' ? 'שבועי' : 'חד־פעמית';
  const occurrenceDateForTask = t => t.recurrence==='none' ? (localDateFromISO(t.due_at)||localDateFromISO(t.created_at)||todayISO()) : todayISO();
  const occursToday = t => {
    if(!t?.is_active)return false;
    if(t.recurrence==='daily')return true;
    if(t.recurrence==='weekly')return Array.isArray(t.recurrence_days)&&t.recurrence_days.map(Number).includes(new Date().getDay());
    return true;
  };

  async function refreshUnreadCount(){
    if(!sb||!session)return;
    const {count}=await sb.from('notifications').select('id',{count:'exact',head:true}).eq('business_id',profile.business_id).eq('user_id',session.user.id).is('read_at',null);
    document.querySelectorAll('[data-notification-badge]').forEach(el=>{const n=Number(count||0);el.textContent=String(n);el.hidden=!n;});
  }

  function bindNotificationBell(){
    document.querySelectorAll('[data-notifications]').forEach(btn=>btn.onclick=renderNotifications);
    refreshUnreadCount().catch(()=>{});
  }

  function startNotificationRealtime(){
    try{ if(notificationChannel)sb.removeChannel(notificationChannel); }catch(_e){}
    notificationChannel=sb.channel(`notifications-${session.user.id}`)
      .on('postgres_changes',{event:'INSERT',schema:'public',table:'notifications',filter:`user_id=eq.${session.user.id}`},payload=>{
        refreshUnreadCount().catch(()=>{});
        const row=payload.new||{};
        const toast=document.createElement('button'); toast.type='button'; toast.className='mg-live-notification'; toast.innerHTML=`<b>${esc(row.title||'התראה חדשה')}</b><span>${esc(row.body||'')}</span>`; toast.onclick=renderNotifications; document.body.appendChild(toast); setTimeout(()=>toast.remove(),5000);
      }).subscribe();
  }

  function supportsPush(){ return 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window; }
  function isIOS(){ return /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1); }
  function isStandalone(){ return window.matchMedia('(display-mode: standalone)').matches || navigator.standalone===true; }
  function urlBase64ToUint8Array(base64String){ const padding='='.repeat((4-base64String.length%4)%4);const base64=(base64String+padding).replace(/-/g,'+').replace(/_/g,'/');const raw=atob(base64);return Uint8Array.from([...raw].map(c=>c.charCodeAt(0))); }

  async function enablePushNotifications(){
    const status=document.getElementById('mgPushStatus'); if(status)status.textContent='מחבר את המכשיר…';
    try{
      if(!supportsPush())throw new Error('המכשיר או הדפדפן הזה לא תומך ב-Web Push.');
      if(isIOS()&&!isStandalone())throw new Error('באייפון יש להוסיף את האפליקציה למסך הבית ולפתוח אותה מהאייקון.');
      const permission=await Notification.requestPermission(); if(permission!=='granted')throw new Error('לא ניתן אישור להתראות במכשיר.');
      await navigator.serviceWorker.register('/sw.js',{scope:'/'}); const reg=await navigator.serviceWorker.ready;
      const existing=await reg.pushManager.getSubscription(); if(existing)await existing.unsubscribe().catch(()=>{});
      const sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:urlBase64ToUint8Array(VAPID_PUBLIC_KEY)});
      const j=sub.toJSON(); const keys=j.keys||{};
      const {error}=await sb.from('push_subscriptions').upsert({business_id:profile.business_id,user_id:session.user.id,endpoint:j.endpoint,p256dh:keys.p256dh,auth:keys.auth,user_agent:navigator.userAgent,updated_at:new Date().toISOString()},{onConflict:'endpoint'});
      if(error)throw error;
      if(status)status.textContent='התראות Push פעילות במכשיר הזה ✓';
    }catch(err){ if(status)status.textContent=err.message||'לא הצלחתי להפעיל התראות.'; }
  }

  async function testPush(){
    const status=document.getElementById('mgPushStatus'); if(status)status.textContent='שולח התראת בדיקה…';
    const {data,error}=await sb.functions.invoke('task-push',{body:{action:'test'}});
    if(status)status.textContent=error?`בדיקה נכשלה: ${error.message}`:`נשלחה בדיקה (${Number(data?.delivered||0)} מכשירים).`;
  }

  async function renderNotifications(){
    root.classList.remove('hidden');
    root.innerHTML=`${shellHeader('התראות','🔔')}<div class="mg-form-card"><h3>התראות למכשיר</h3><p>משימות ותזכורות יופיעו כאן תמיד. אפשר להפעיל גם Push להתראות שנתמכות במכשיר.</p><div class="mg-inline-buttons"><button id="mgEnablePush" class="mg-secondary">הפעל Push במכשיר הזה</button><button id="mgTestPush" class="mg-mini-btn">שלח בדיקה</button></div><div id="mgPushStatus" class="mg-progress-text"></div></div><div class="mg-form-card"><div class="mg-detail-head"><div><h3>מרכז התראות</h3><p>ההתראות האישיות שלך</p></div><button id="mgMarkAllRead" class="mg-mini-btn">סמן הכול כנקרא</button></div><div id="mgNotificationsList" class="mg-notification-list"><div class="mg-loading">טוען…</div></div></div></main></div>`;
    bindBack(); mountAppNav('notifications'); document.getElementById('mgEnablePush').onclick=enablePushNotifications; document.getElementById('mgTestPush').onclick=testPush;
    document.getElementById('mgMarkAllRead').onclick=async()=>{await sb.from('notifications').update({read_at:new Date().toISOString()}).eq('business_id',profile.business_id).eq('user_id',session.user.id).is('read_at',null);renderNotifications();};
    const {data,error}=await sb.from('notifications').select('id,title,body,url,read_at,created_at').eq('business_id',profile.business_id).eq('user_id',session.user.id).order('created_at',{ascending:false}).limit(60);
    const list=document.getElementById('mgNotificationsList');
    if(error){list.innerHTML=`<div class="mg-error show">${esc(error.message)}</div>`;return;}
    list.innerHTML=(data||[]).length?(data||[]).map(n=>`<button class="mg-notification-row${n.read_at?'':' unread'}" data-note="${n.id}"><span><b>${esc(n.title)}</b><small>${esc(n.body)}</small></span><time>${esc(formatDateTime(n.created_at))}</time></button>`).join(''):'<div class="mg-empty">אין התראות עדיין.</div>';
    document.querySelectorAll('[data-note]').forEach(btn=>btn.onclick=async()=>{const n=(data||[]).find(x=>String(x.id)===String(btn.dataset.note));if(n&&!n.read_at)await sb.from('notifications').update({read_at:new Date().toISOString()}).eq('id',n.id); if(n?.url?.includes('tasks'))renderTasks();else if(n?.url?.includes('suppliers'))renderSuppliers();else if(n?.url?.includes('shortages'))renderShortages();else if(n?.url?.includes('signage'))renderSignage();else renderNotifications();});
    refreshUnreadCount().catch(()=>{});
  }

  function taskTargetOptions(members){
    const people=(members||[]).filter(m=>m.is_active&&m.role!=='super_admin').map(m=>`<option value="user:${esc(m.user_id)}">${esc(m.full_name||m.email)} — ${esc(roleLabel(m.role)+(m.department?' / '+deptLabel(m.department):''))}</option>`).join('');
    return `<option value="all">כל העובדים</option><option value="department:cashier">כל עובדי הקופות</option><option value="department:warehouse">כל עובדי המחסן</option><optgroup label="עובד ספציפי">${people}</optgroup>`;
  }

  function taskCard(t,completion,memberMap,management){
    const urgent=t.priority==='urgent'; const occ=occurrenceDateForTask(t); const completed=completion?.status==='completed'; const inProgress=completion?.status==='in_progress';
    const assigned=t.assignment_type==='user'?(memberMap.get(t.assigned_user_id)||'עובד ספציפי'):assignmentLabel(t);
    const overdue=!!t.due_at&&new Date(t.due_at).getTime()<Date.now()&&!completed&&(management?Number(completion?.completed||0)<Number(completion?.targets||1):true);
    const statusBadge=management?(completion?.summary?`<span class="mg-task-done${overdue?' overdue':''}">${esc(completion.summary)}</span>`:''):(completed?'<span class="mg-task-done">הושלמה ✓</span>':inProgress?'<span class="mg-task-done working">בטיפול</span>':overdue?'<span class="mg-task-done overdue">באיחור</span>':'');
    return `<div class="mg-task${urgent?' urgent':''}${completed?' completed':''}${overdue?' overdue':''}"><div class="mg-task-top"><div><span class="mg-task-priority">${urgent?'דחופה':'רגילה'}</span><h3>${esc(t.title)}</h3></div>${statusBadge}</div>${t.description?`<p>${esc(t.description)}</p>`:''}<div class="mg-task-meta"><span>👤 ${esc(assigned)}</span><span>🕒 ${esc(formatDue(t.due_at))}</span><span>🔁 ${esc(recurrenceLabel(t))}</span></div>${management?`<div class="mg-task-actions"><button class="mg-mini-btn danger" data-delete-task="${t.id}">מחק משימה</button></div>`:`<div class="mg-task-actions"><button class="mg-secondary" data-task-status="in_progress" data-task-id="${t.id}" data-occ="${occ}">בטיפול</button><button class="mg-primary" data-task-status="completed" data-task-id="${t.id}" data-occ="${occ}">${completed?'הושלמה ✓':'סמן כהושלם'}</button></div>`}</div>`;
  }

  async function renderTasks(){
    if(!requireModule('tasks'))return;
    root.classList.remove('hidden');
    root.innerHTML=`${shellHeader('משימות לעובדים','✅')}<div class="mg-form-card"><div class="mg-loading">טוען משימות…</div></div></main></div>`; bindBack();
    const management=isManagement();
    const [{data:tasks,error:taskError},{data:members}]=await Promise.all([
      sb.from('tasks').select('*').eq('business_id',profile.business_id).eq('is_active',true).order('created_at',{ascending:false}).limit(200),
      sb.from('profiles').select('user_id,full_name,email,role,department,is_active').eq('business_id',profile.business_id)
    ]);
    if(taskError){root.querySelector('.mg-main').innerHTML+=`<div class="mg-error show">${esc(taskError.message)}</div>`;return;}
    const memberMap=new Map((members||[]).map(m=>[m.user_id,m.full_name||m.email]));
    const visible=(tasks||[]).filter(t=>management||occursToday(t));
    const taskIds=visible.map(t=>t.id);
    let compQuery=sb.from('task_completions').select('task_id,occurrence_date,user_id,status,completed_at').eq('business_id',profile.business_id);
    if(!management)compQuery=compQuery.eq('user_id',session.user.id);
    if(taskIds.length)compQuery=compQuery.in('task_id',taskIds); else compQuery=compQuery.limit(1);
    const {data:completions}=await compQuery;
    const completionMap=new Map((completions||[]).map(c=>[`${c.task_id}|${c.occurrence_date}|${c.user_id}`,c]));
    const ownCompletion=t=>completionMap.get(`${t.id}|${occurrenceDateForTask(t)}|${session.user.id}`);
    const managementCompletion=t=>{
      const occ=occurrenceDateForTask(t); const rows=(completions||[]).filter(c=>c.task_id===t.id&&c.occurrence_date===occ);
      const targets=(members||[]).filter(m=>m.is_active&&(
        (t.assignment_type==='all'&&m.role==='employee')||
        (t.assignment_type==='department'&&m.role==='employee'&&m.department===t.assigned_department)||
        (t.assignment_type==='user'&&m.user_id===t.assigned_user_id)
      )).length;
      const completed=rows.filter(r=>r.status==='completed').length, progress=rows.filter(r=>r.status==='in_progress').length;
      const summary=targets?`${completed}/${targets} הושלמו${progress?` • ${progress} בטיפול`:''}`:(completed?'הושלמה ✓':'ללא יעד פעיל');
      return {targets,completed,progress,summary};
    };
    const main=root.querySelector('.mg-main');
    const form=management?`<div class="mg-form-card"><h3>משימה חדשה</h3><p>אפשר לשייך לעובד, לקופות, למחסן או לכל העובדים.</p><form id="mgTaskForm"><div class="mg-field"><label>כותרת המשימה</label><input id="taskTitle" maxlength="160" required placeholder="לדוגמה: לבדוק תוקפים במקרר חלב"></div><div class="mg-field"><label>פירוט</label><textarea id="taskDescription" rows="3" placeholder="פרטים נוספים, אם צריך"></textarea></div><div class="mg-two"><div class="mg-field"><label>שיוך</label><select id="taskTarget">${taskTargetOptions(members)}</select></div><div class="mg-field"><label>עדיפות</label><select id="taskPriority"><option value="normal">רגילה</option><option value="urgent">דחופה</option></select></div></div><div class="mg-two"><div class="mg-field"><label>דדליין</label><input id="taskDue" type="datetime-local"></div><div class="mg-field"><label>חזרה</label><select id="taskRecurrence"><option value="none">חד־פעמית</option><option value="daily">כל יום</option><option value="weekly">שבועית</option></select></div></div><div id="taskWeekdays" class="mg-weekdays" hidden>${[['א',0],['ב',1],['ג',2],['ד',3],['ה',4],['ו',5],['ש',6]].map(([l,v])=>`<label><input type="checkbox" value="${v}"><span>${l}</span></label>`).join('')}</div><button id="taskCreateBtn" class="mg-primary">צור משימה ושלח התראה</button><div id="taskFormMsg" class="mg-error"></div></form></div>`:'';
    const listHtml=visible.length?visible.map(t=>taskCard(t,management?managementCompletion(t):ownCompletion(t),memberMap,management)).join(''):'<div class="mg-empty">אין משימות פעילות כרגע.</div>';
    main.querySelector('.mg-form-card').outerHTML=`${form}<div class="mg-form-card"><div class="mg-detail-head"><div><h3>${management?'כל המשימות הפעילות':'המשימות שלי'}</h3><p>${visible.length} משימות</p></div></div><div class="mg-tasks-list">${listHtml}</div></div>`;
    if(management){
      document.getElementById('taskRecurrence').onchange=e=>document.getElementById('taskWeekdays').hidden=e.target.value!=='weekly';
      document.getElementById('mgTaskForm').onsubmit=createTask;
      document.querySelectorAll('[data-delete-task]').forEach(b=>b.onclick=()=>deleteTask(b.dataset.deleteTask));
    }else{
      document.querySelectorAll('[data-task-status]').forEach(b=>b.onclick=()=>setTaskStatus(b.dataset.taskId,b.dataset.occ,b.dataset.taskStatus));
    }
  }

  async function createTask(e){
    e.preventDefault(); const btn=document.getElementById('taskCreateBtn'), msg=document.getElementById('taskFormMsg'); btn.disabled=true;btn.textContent='יוצר משימה…';msg.classList.remove('show');
    try{
      const target=document.getElementById('taskTarget').value; let assignment_type='all',assigned_user_id=null,assigned_department=null;
      if(target.startsWith('user:')){assignment_type='user';assigned_user_id=target.slice(5);} else if(target.startsWith('department:')){assignment_type='department';assigned_department=target.slice(11);}
      const recurrence=document.getElementById('taskRecurrence').value; const recurrence_days=recurrence==='weekly'?[...document.querySelectorAll('#taskWeekdays input:checked')].map(i=>Number(i.value)):[];
      if(recurrence==='weekly'&&!recurrence_days.length)throw new Error('במשימה שבועית צריך לבחור לפחות יום אחד.');
      const dueLocal=document.getElementById('taskDue').value;
      const row={business_id:profile.business_id,title:document.getElementById('taskTitle').value.trim(),description:document.getElementById('taskDescription').value.trim(),priority:document.getElementById('taskPriority').value,assignment_type,assigned_user_id,assigned_department,due_at:dueLocal?new Date(dueLocal).toISOString():null,recurrence,recurrence_days,created_by:session.user.id};
      const {data,error}=await sb.from('tasks').insert(row).select('id').single(); if(error)throw error;
      const {error:pushError}=await sb.functions.invoke('task-push',{body:{action:'task',task_id:data.id}});
      if(pushError)console.warn('Push failed',pushError);
      await renderTasks();
    }catch(err){msg.textContent=err.message||'לא הצלחתי ליצור את המשימה.';msg.classList.add('show');btn.disabled=false;btn.textContent='צור משימה ושלח התראה';}
  }

  async function setTaskStatus(taskId,occurrenceDate,status){
    const row={task_id:taskId,business_id:profile.business_id,occurrence_date:occurrenceDate,user_id:session.user.id,status,completed_at:status==='completed'?new Date().toISOString():null,updated_at:new Date().toISOString()};
    const {error}=await sb.from('task_completions').upsert(row,{onConflict:'task_id,occurrence_date,user_id'}); if(error){alert('לא הצלחתי לעדכן את המשימה: '+error.message);return;} renderTasks();
  }

  async function deleteTask(taskId){
    if(!confirm('למחוק את המשימה?'))return; const {error}=await sb.from('tasks').delete().eq('id',taskId).eq('business_id',profile.business_id); if(error)alert(error.message); else renderTasks();
  }

  function renderCalculator(){
    if(!requireModule('calculator'))return;
    root.classList.remove('hidden');
    root.innerHTML=`${shellHeader('מחשבון מחיר לצרכן','🧮')}<div class="mg-form-card mg-calculator"><p>ברירת המחדל: 30% רווח ולאחר מכן 18% מע״מ.</p><div class="mg-field"><label>מחיר עלות (₪)</label><input id="calcCost" type="number" min="0" step="0.01" inputmode="decimal" placeholder="לדוגמה 100"></div><div class="mg-two"><div class="mg-field"><label>רווח (%)</label><input id="calcProfit" type="number" step="0.1" value="30"></div><div class="mg-field"><label>מע״מ (%)</label><input id="calcVat" type="number" step="0.1" value="18"></div></div><label class="mg-check"><input id="calcVatOn" type="checkbox" checked> להוסיף מע״מ</label><div class="mg-calc-result"><small>מחיר לצרכן</small><strong id="calcFinal">₪0.00</strong><div id="calcBreakdown">הזן מחיר עלות</div></div></div></main></div>`;
    bindBack();
    ['calcCost','calcProfit','calcVat','calcVatOn'].forEach(id=>document.getElementById(id).addEventListener('input',updateCalculator));
    updateCalculator();
  }

  function updateCalculator(){
    const cost=Math.max(0,Number(document.getElementById('calcCost')?.value||0));
    const profit=Number(document.getElementById('calcProfit')?.value||0);
    const vat=Number(document.getElementById('calcVat')?.value||0);
    const vatOn=!!document.getElementById('calcVatOn')?.checked;
    const afterProfit=cost*(1+profit/100), final=afterProfit*(vatOn?(1+vat/100):1);
    const finalEl=document.getElementById('calcFinal'), breakdown=document.getElementById('calcBreakdown');
    if(finalEl) finalEl.textContent=`₪${final.toFixed(2)}`;
    if(breakdown) breakdown.textContent=cost?`עלות ₪${cost.toFixed(2)} → אחרי רווח ₪${afterProfit.toFixed(2)}${vatOn?` → אחרי מע״מ ₪${final.toFixed(2)}`:''}`:'הזן מחיר עלות';
  }

  async function renderHistory(){
    if(!requireModule('history'))return;
    root.classList.remove('hidden');
    root.innerHTML=`${shellHeader('היסטוריית ספירות','🗓️')}<div class="mg-form-card"><div class="mg-loading">טוען היסטוריה…</div></div></main></div>`;
    bindBack();
    const {data,error}=await sb.from('inventory_daily_history').select('inventory_date,state_json,updated_at,updated_by').eq('business_id',profile.business_id).order('inventory_date',{ascending:false}).limit(120);
    const main=root.querySelector('.mg-main');
    if(error){ main.insertAdjacentHTML('beforeend',`<div class="mg-error show">לא הצלחתי לטעון היסטוריה: ${esc(error.message)}</div>`); return; }
    main.querySelector('.mg-form-card').outerHTML=`<div class="mg-form-card"><h3>רשימות לפי יום</h3><p>כל יום נשמר אוטומטית בענן גם לאחר שהרשימה מתאפסת ביום הבא.</p><div class="mg-history-list">${(data||[]).length?(data||[]).map((r,i)=>`<button class="mg-history-row" data-history="${i}"><span><b>${esc(formatDate(r.inventory_date))}</b><small>עדכון אחרון: ${esc(formatDateTime(r.updated_at))}</small></span><strong>צפייה ←</strong></button>`).join(''):'<div class="mg-empty">עדיין אין ימים שמורים.</div>'}</div></div><div id="mgHistoryDetail"></div>`;
    document.querySelectorAll('[data-history]').forEach(btn=>btn.onclick=()=>renderHistoryDetail((data||[])[Number(btn.dataset.history)]));
  }

  function historyItems(state){
    const out=[];
    const fixed=['right','middle','leftTop','leftHerbs'].flatMap(k=>Array.isArray(state.columns?.[k])?state.columns[k]:[]);
    fixed.forEach(name=>{ const q=state.qty?.[name]; if(String(q??'').trim()!=='') out.push({name,qty:q}); });
    const addRows=(title,rows)=>{ const filled=(Array.isArray(rows)?rows:[]).filter(r=>String(r?.qty??'').trim()!==''); if(filled.length){out.push({section:title}); filled.forEach(r=>out.push({name:r.name,qty:r.qty}));} };
    addRows(state.sectionTitles?.apple||'תפוחים',state.apples);
    addRows(state.sectionTitles?.yok||'ירק ליקנעם',state.yokneam);
    addRows(state.sectionTitles?.poultry||'עופות',state.poultry);
    addRows(state.sectionTitles?.extra||'נוספים',state.extras);
    return out;
  }

  function renderHistoryDetail(row){
    const s=parseState(row?.state_json||'{}'), items=historyItems(s), target=document.getElementById('mgHistoryDetail');
    if(!target)return;
    target.innerHTML=`<div class="mg-form-card mg-history-detail"><div class="mg-detail-head"><div><h3>${esc(formatDate(row.inventory_date))}</h3><p>${esc(items.filter(x=>!x.section).length)} פריטים עם ערך</p></div><button id="mgCloseHistory" class="mg-back">סגור</button></div><div class="mg-history-items">${items.map(x=>x.section?`<div class="mg-history-section">${esc(x.section)}</div>`:`<div class="mg-history-item"><span>${esc(x.name)}</span><b>${esc(x.qty)}</b></div>`).join('')||'<div class="mg-empty">אין ערכים ברשימה.</div>'}</div>${s.notes?`<div class="mg-history-notes"><b>הערות:</b> ${esc(s.notes)}</div>`:''}</div>`;
    document.getElementById('mgCloseHistory').onclick=()=>target.innerHTML='';
    target.scrollIntoView({behavior:'smooth',block:'start'});
  }

  async function renderMyProfile(){
    root.classList.remove('hidden');
    const currentEmail=session?.user?.email||profile?.email||'';
    root.innerHTML=`${shellHeader('הפרופיל שלי','👤')}<div class="mg-form-card"><h3>פרטים אישיים</h3><p>השינויים נשמרים בחשבון שלך ויופיעו בכל מכשיר.</p><form id="mgMyProfileForm"><div class="mg-two"><div class="mg-field"><label>שם מלא</label><input id="mgMyName" value="${esc(profile?.full_name||'')}" required></div><div class="mg-field"><label>אימייל</label><input id="mgMyEmail" type="email" value="${esc(currentEmail)}" required></div></div><div class="mg-field"><label>סיסמה חדשה</label><input id="mgMyPassword" type="password" minlength="6" placeholder="השאר ריק אם אין שינוי"></div><button id="mgSaveMyProfile" class="mg-primary">שמור פרטים</button><div id="mgMyProfileMsg" class="mg-progress-text"></div></form></div></main></div>`;
    bindBack(); mountAppNav('profile');
    document.getElementById('mgMyProfileForm').onsubmit=saveMyProfile;
  }

  async function saveMyProfile(e){
    e.preventDefault();
    const btn=document.getElementById('mgSaveMyProfile'),msg=document.getElementById('mgMyProfileMsg');
    const fullName=document.getElementById('mgMyName').value.trim(), email=document.getElementById('mgMyEmail').value.trim(), password=document.getElementById('mgMyPassword').value;
    btn.disabled=true;msg.textContent='שומר…';
    try{
      const changes={data:{full_name:fullName}};
      if(email && email!==session?.user?.email)changes.email=email;
      if(password)changes.password=password;
      const {data,error}=await sb.auth.updateUser(changes);if(error)throw error;
      const effectiveEmail=data?.user?.email||session?.user?.email||email;
      const {data:updated,error:profileError}=await sb.rpc('update_my_profile',{p_full_name:fullName,p_email:effectiveEmail});if(profileError)throw profileError;
      profile={...profile,...(updated||{}),full_name:fullName,email:effectiveEmail};
      const sess=await sb.auth.getSession();session=sess.data.session||session;
      msg.textContent=email!==effectiveEmail?'השם/סיסמה נשמרו. שינוי האימייל ממתין לאישור לפי הגדרות החשבון.':'הפרטים נשמרו ✓';
      btn.disabled=false;btn.textContent='שמור פרטים';
    }catch(err){msg.textContent='לא הצלחתי לשמור: '+(err.message||err);btn.disabled=false;}
  }

  async function renderModulePermissions(){
    if(!isManagement())return renderDashboard();
    await loadModulePermissions();
    const cell=(aud,key)=>{const stored=modulePermissions.get(`${aud}|${key}`),val=stored===undefined?!!DEFAULT_MODULE_ACCESS[aud]?.[key]:stored;return `<label class="mg-permission-toggle"><input type="checkbox" data-module-permission="${esc(aud)}|${esc(key)}" ${val?'checked':''}><span>${val?'פתוח':'סגור'}</span></label>`;};
    root.classList.remove('hidden');
    root.innerHTML=`${shellHeader('הרשאות מודולים','🔐')}<div class="mg-form-card"><div class="mg-detail-head"><div><h3>גישה לפי סיווג משתמש</h3><p>השינוי משפיע על כל המשתמשים מאותו סיווג. סופר אדמין תמיד מקבל גישה מלאה.</p></div></div><div class="mg-permissions-table"><div class="mg-permissions-row head"><b>מודול</b>${AUDIENCE_DEFS.map(a=>`<b>${esc(a.label)}</b>`).join('')}</div>${MODULE_DEFS.map(m=>`<div class="mg-permissions-row"><strong>${m.icon} ${esc(m.label)}</strong>${AUDIENCE_DEFS.map(a=>cell(a.key,m.key)).join('')}</div>`).join('')}</div><button id="mgSaveModulePermissions" class="mg-primary">שמור הרשאות</button><div id="mgModulePermissionsMsg" class="mg-progress-text"></div></div><div class="mg-form-card mg-info-card"><b>מודולים מערכתיים</b><p>יצירת משתמשים ועדכוני מערכת נשארים לסופר אדמין בלבד ולא ניתנים לפתיחה לעובדים.</p></div></main></div>`;
    bindBack();
    document.querySelectorAll('[data-module-permission]').forEach(i=>i.onchange=()=>{const span=i.nextElementSibling;if(span)span.textContent=i.checked?'פתוח':'סגור';});
    document.getElementById('mgSaveModulePermissions').onclick=saveModulePermissions;
  }

  async function saveModulePermissions(){
    const btn=document.getElementById('mgSaveModulePermissions'),msg=document.getElementById('mgModulePermissionsMsg');btn.disabled=true;msg.textContent='שומר…';
    const rows=[...document.querySelectorAll('[data-module-permission]')].map(i=>{const [audience_key,module_key]=i.dataset.modulePermission.split('|');return {business_id:profile.business_id,audience_key,module_key,allowed:i.checked,updated_by:session.user.id,updated_at:new Date().toISOString()};});
    const {error}=await sb.from('module_permissions').upsert(rows,{onConflict:'business_id,audience_key,module_key'});
    if(error){msg.textContent='לא הצלחתי לשמור: '+error.message;btn.disabled=false;return;}
    await loadModulePermissions();msg.textContent='ההרשאות נשמרו ✓';btn.disabled=false;
  }

  async function renderUsers(){
    if(!isSuperAdmin()) return renderDashboard();
    const {data:members,error}=await sb.rpc('get_current_business_members');
    root.classList.remove('hidden');
    root.innerHTML=`${shellHeader('משתמשים והרשאות','👥')}<div class="mg-form-card"><h3>יצירת משתמש חדש</h3><p>החשבון נוצר כאן ומוכן מיד להתחברות — אין צורך להיכנס יותר ל-Supabase.</p><form id="mgCreateUser"><div class="mg-two"><div class="mg-field"><label>שם מלא</label><input id="mgNewName" required></div><div class="mg-field"><label>אימייל</label><input id="mgNewEmail" type="email" required></div></div><div class="mg-two"><div class="mg-field"><label>סיסמה זמנית</label><input id="mgNewPassword" type="password" minlength="6" required></div><div class="mg-field"><label>תפקיד</label><select id="mgNewRole"><option value="employee">עובד</option><option value="manager">מנהל</option></select></div></div><div id="mgNewDepartmentWrap" class="mg-field"><label>מחלקה</label><select id="mgNewDepartment"><option value="cashier">קופות</option><option value="warehouse">מחסן</option></select></div><button id="mgCreateBtn" class="mg-secondary">צור משתמש</button><div id="mgCreateMsg" class="mg-error"></div></form></div><div class="mg-form-card"><h3>משתמשים בעסק</h3>${error?'<div class="mg-error show">לא הצלחתי לטעון משתמשים.</div>':`<div class="mg-users-list">${(members||[]).map(m=>memberHtml(m)).join('')}</div>`}</div></main></div>`;
    bindBack();
    const role=document.getElementById('mgNewRole'); role.onchange=()=>document.getElementById('mgNewDepartmentWrap').style.display=role.value==='employee'?'':'none';
    document.getElementById('mgCreateUser').onsubmit=createUser;
    document.querySelectorAll('[data-user-edit]').forEach(b=>b.onclick=()=>{editingUserId=b.dataset.userEdit;renderUsers();});
    document.querySelectorAll('[data-user-active]').forEach(b=>b.onclick=()=>setUserActive(b.dataset.userActive,b.dataset.active!=='true'));
    const editForm=document.getElementById('mgEditUser'); if(editForm) editForm.onsubmit=updateUser;
    const cancelEdit=document.getElementById('mgCancelEdit'); if(cancelEdit) cancelEdit.onclick=()=>{editingUserId=null;renderUsers();};
    const editRole=document.getElementById('mgEditRole'); if(editRole){ const dep=document.getElementById('mgEditDepartment')?.closest('.mg-field'); const sync=()=>{if(dep)dep.style.visibility=editRole.value==='employee'?'visible':'hidden';}; editRole.onchange=sync; sync(); }
  }

  function memberHtml(m){
    const isMe=m.user_id===profile.user_id;
    const dept=m.role==='employee'&&m.department?` • ${deptLabel(m.department)}`:'';
    const editing=editingUserId===m.user_id && m.role!=='super_admin';
    return `<div class="mg-member-wrap"><div class="mg-member"><div class="mg-member-main"><b>${esc(m.full_name||m.email||'משתמש')}${isMe?' (אתה)':''}</b><small>${esc(m.email||'')}</small></div><div class="mg-member-actions"><span class="mg-role">${esc(roleLabel(m.role)+dept)}${m.is_active===false?' • מושבת':''}</span>${m.role!=='super_admin'?`<button class="mg-mini-btn" data-user-edit="${esc(m.user_id)}">עריכה</button><button class="mg-mini-btn ${m.is_active===false?'':'danger'}" data-user-active="${esc(m.user_id)}" data-active="${m.is_active!==false}">${m.is_active===false?'הפעל':'השבת'}</button>`:''}</div></div>${editing?editUserHtml(m):''}</div>`;
  }

  function editUserHtml(m){
    return `<form id="mgEditUser" class="mg-inline-edit" data-user-id="${esc(m.user_id)}"><div class="mg-two"><div class="mg-field"><label>שם</label><input id="mgEditName" value="${esc(m.full_name||'')}"></div><div class="mg-field"><label>תפקיד</label><select id="mgEditRole"><option value="employee" ${m.role==='employee'?'selected':''}>עובד</option><option value="manager" ${m.role==='manager'?'selected':''}>מנהל</option></select></div></div><div class="mg-two"><div class="mg-field"><label>מחלקה (לעובד)</label><select id="mgEditDepartment"><option value="cashier" ${m.department==='cashier'?'selected':''}>קופות</option><option value="warehouse" ${m.department==='warehouse'?'selected':''}>מחסן</option></select></div><div class="mg-field"><label>סיסמה חדשה (אופציונלי)</label><input id="mgEditPassword" type="password" minlength="6" placeholder="השאר ריק ללא שינוי"></div></div><div class="mg-inline-buttons"><button class="mg-secondary">שמור שינויים</button><button type="button" id="mgCancelEdit" class="mg-back">ביטול</button></div><div id="mgEditMsg" class="mg-error"></div></form>`;
  }

  async function invokeManageUser(body){
    const {data,error}=await sb.functions.invoke('manage-user',{body});
    if(error) throw new Error(error.message||'שגיאה בפונקציית המשתמשים');
    if(data?.error) throw new Error(data.error);
    return data;
  }

  async function createUser(e){
    e.preventDefault(); const btn=document.getElementById('mgCreateBtn'), msg=document.getElementById('mgCreateMsg');
    btn.disabled=true; btn.textContent='יוצר משתמש…'; msg.classList.remove('show');
    try{
      await invokeManageUser({action:'create',full_name:document.getElementById('mgNewName').value.trim(),email:document.getElementById('mgNewEmail').value.trim(),password:document.getElementById('mgNewPassword').value,role:document.getElementById('mgNewRole').value,department:document.getElementById('mgNewDepartment').value});
      await renderUsers();
    }catch(err){ msg.textContent=userErrorMessage(err.message); msg.classList.add('show'); btn.disabled=false; btn.textContent='צור משתמש'; }
  }

  async function updateUser(e){
    e.preventDefault(); const form=e.currentTarget, msg=document.getElementById('mgEditMsg'); msg.classList.remove('show');
    try{
      await invokeManageUser({action:'update',user_id:form.dataset.userId,full_name:document.getElementById('mgEditName').value.trim(),role:document.getElementById('mgEditRole').value,department:document.getElementById('mgEditDepartment').value,password:document.getElementById('mgEditPassword').value});
      editingUserId=null; await renderUsers();
    }catch(err){ msg.textContent=userErrorMessage(err.message); msg.classList.add('show'); }
  }

  async function setUserActive(userId,active){
    if(!window.confirm(active?'להפעיל מחדש את המשתמש?':'להשבית את המשתמש? הוא לא יוכל להיכנס למערכת.'))return;
    try{ await invokeManageUser({action:'set_active',user_id:userId,is_active:active}); await renderUsers(); }
    catch(err){ alert(userErrorMessage(err.message)); }
  }

  function userErrorMessage(m){
    const s=String(m||'');
    if(/already|registered|exists/i.test(s))return 'כבר קיים משתמש עם האימייל הזה.';
    if(s.includes('PASSWORD_TOO_SHORT'))return 'הסיסמה חייבת להכיל לפחות 6 תווים.';
    if(s.includes('INVALID_DEPARTMENT'))return 'יש לבחור קופות או מחסן לעובד.';
    if(s.includes('SUPER_ADMIN_ONLY'))return 'רק סופר אדמין יכול לבצע את הפעולה.';
    if(/Failed to send|Function not found|non-2xx/i.test(s))return 'פונקציית יצירת המשתמשים עדיין לא הותקנה ב-Supabase. התקן את manage-user לפי ההוראות שקיבלת.';
    return 'לא הצלחתי לבצע את הפעולה: '+s;
  }


  // V2.2.1 — Suppliers, reminders & order history
  const supplierSortLabel = mode => mode==='custom' ? 'סדר ידני' : 'א׳–ב׳';
  const supplierDayLabels = ['ראשון','שני','שלישי','רביעי','חמישי','שישי','שבת'];
  const cleanPhone = value => {
    let digits=String(value||'').replace(/\D/g,'');
    if(digits.startsWith('00'))digits=digits.slice(2);
    if(digits.startsWith('0'))digits='972'+digits.slice(1);
    return digits;
  };
  const sortedSupplierProducts = (rows,supplier=currentSupplier) => {
    const arr=[...(rows||[])];
    if(supplier?.sort_mode==='custom') return arr.sort((a,b)=>(Number(a.display_order)||0)-(Number(b.display_order)||0)||String(a.name||'').localeCompare(String(b.name||''),'he'));
    return arr.sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),'he',{sensitivity:'base'}));
  };
  const reminderLabel = r => `${supplierDayLabels[Number(r.day_of_week)||0]} • ${String(r.reminder_time||'').slice(0,5)}`;

  async function claimSupplierReminders(){
    if(!sb||!session||!profile)return;
    try{
      const {data,error}=await sb.rpc('claim_supplier_reminders_for_me');
      if(!error && Number(data||0)>0){
        await refreshNotificationBadge();
        try{
          if(typeof Notification!=='undefined' && Notification.permission==='granted' && navigator.serviceWorker){
            const reg=await navigator.serviceWorker.ready;
            await reg.showNotification('📦 תזכורת להזמנה',{body:'יש הזמנת ספק שצריך להכין.',icon:'/icon.png',badge:'/icon.png',tag:'supplier-reminder',data:{url:'/?open=suppliers'}});
          }
        }catch(_e){}
      }
    }catch(_e){}
  }

  function scheduleSupplierReminderCheck(){
    clearInterval(supplierReminderTimer);
    claimSupplierReminders();
    supplierReminderTimer=setInterval(claimSupplierReminders,60000);
  }

  async function renderSuppliers(){
    if(!requireModule('suppliers'))return;
    let q=sb.from('suppliers').select('id,name,whatsapp_phone,sort_mode,is_active,created_at').eq('business_id',profile.business_id).order('name',{ascending:true});
    if(!isManagement())q=q.eq('is_active',true);
    const [{data,error},{data:reminders}]=await Promise.all([
      q,
      sb.from('supplier_order_reminders').select('supplier_id,day_of_week,reminder_time,title,is_active').eq('business_id',profile.business_id).eq('is_active',true)
    ]);
    root.classList.remove('hidden');
    if(error){root.innerHTML=`${shellHeader('הזמנות מספקים','📦')}<div class="mg-error show">${esc(error.message)}</div></main></div>`;bindBack();return;}
    const suppliers=data||[], remBySupplier=new Map();
    (reminders||[]).forEach(r=>{if(!remBySupplier.has(r.supplier_id))remBySupplier.set(r.supplier_id,[]);remBySupplier.get(r.supplier_id).push(r);});
    const addForm=isManagement()?`<div class="mg-form-card mg-supplier-admin"><div class="mg-detail-head"><div><h3>הוספת ספק</h3><p>התשתית משותפת לכל הספקים. בהמשך אפשר להוסיף לכל ספק חוקים ופיצ׳רים משלו.</p></div></div><form id="mgAddSupplier"><div class="mg-two"><div class="mg-field"><label>שם הספק</label><input id="mgSupplierName" required placeholder="לדוגמה: גד"></div><div class="mg-field"><label>WhatsApp של הסוכן</label><input id="mgSupplierPhone" inputmode="tel" placeholder="0501234567 או 972..."></div></div><button class="mg-secondary">הוסף ספק</button><div id="mgSupplierAddMsg" class="mg-error"></div></form></div>`:'';
    root.innerHTML=`${shellHeader('הזמנות מספקים','📦')}${addForm}<div class="mg-form-card"><h3>בחירת ספק</h3><p>בחר ספק כדי להתחיל הזמנה. לכל ספק אפשר לנהל קטלוג, תזכורות והיסטוריית הזמנות.</p><div class="mg-supplier-grid">${suppliers.length?suppliers.map(s=>{const rs=remBySupplier.get(s.id)||[];const rem=rs.length?` • תזכורת ${esc(reminderLabel(rs[0]))}`:'';return `<button class="mg-supplier-card${s.is_active===false?' inactive':''}" data-supplier="${esc(s.id)}"><div><span class="mg-supplier-icon">📦</span><b>${esc(s.name)}</b><small>${esc(supplierSortLabel(s.sort_mode))}${s.is_active===false?' • לא פעיל':''}${rem}</small></div><strong>פתיחה ←</strong></button>`}).join(''):'<div class="mg-empty">עדיין אין ספקים.</div>'}</div></div></main></div>`;
    bindBack();
    document.querySelectorAll('[data-supplier]').forEach(b=>b.onclick=()=>renderSupplierOrder(b.dataset.supplier));
    document.getElementById('mgAddSupplier')?.addEventListener('submit',addSupplier);
    claimSupplierReminders();
  }

  async function addSupplier(e){
    e.preventDefault(); if(!isManagement())return;
    const msg=document.getElementById('mgSupplierAddMsg');msg.classList.remove('show');
    const row={business_id:profile.business_id,name:document.getElementById('mgSupplierName').value.trim(),whatsapp_phone:document.getElementById('mgSupplierPhone').value.trim(),sort_mode:'alphabetical',created_by:session.user.id};
    const {error}=await sb.from('suppliers').insert(row);
    if(error){msg.textContent='לא הצלחתי להוסיף ספק: '+error.message;msg.classList.add('show');return;}
    renderSuppliers();
  }

  async function renderSupplierOrder(supplierId){
    if(!requireModule('suppliers'))return;
    const [{data:supplier,error:supplierError},{data:products,error:productError},{count:draftCount}]=await Promise.all([
      sb.from('suppliers').select('*').eq('business_id',profile.business_id).eq('id',supplierId).single(),
      sb.from('supplier_products').select('*').eq('business_id',profile.business_id).eq('supplier_id',supplierId).eq('is_active',true),
      sb.from('supplier_orders').select('id',{count:'exact',head:true}).eq('business_id',profile.business_id).eq('supplier_id',supplierId).eq('status','draft')
    ]);
    if(supplierError||productError){alert((supplierError||productError).message);return renderSuppliers();}
    currentSupplier=supplier; currentSupplierProducts=sortedSupplierProducts(products||[],supplier);
    if(supplierCartSupplierId!==supplierId){supplierCart=new Map();supplierCartSupplierId=supplierId;editingSourceOrderId=null;editingDraftOrderId=null;}
    root.classList.remove('hidden');
    const editingBanner=editingDraftOrderId?`<div class="mg-form-card mg-order-edit-banner"><b>📝 עריכת הזמנה שטרם נשלחה</b><span>השינויים יישמרו באותה טיוטה עד שתשלח אותה לסוכן.</span><button id="mgCancelHistoryEdit" class="mg-mini-btn">התחל הזמנה חדשה</button></div>`:editingSourceOrderId?`<div class="mg-form-card mg-order-edit-banner"><b>✏️ הזמנה חדשה על בסיס היסטוריה</b><span>הכמויות מההזמנה הישנה נטענו. ההזמנה המקורית תישאר בהיסטוריה.</span><button id="mgCancelHistoryEdit" class="mg-mini-btn">התחל הזמנה חדשה</button></div>`:'';
    root.innerHTML=`${shellHeader(`הזמנה • ${supplier.name}`,'🛒')}<div class="mg-order-toolbar"><div class="mg-search-wrap">🔎<input id="mgProductSearch" type="search" placeholder="חיפוש מוצר..."></div><button id="mgSupplierDrafts" class="mg-secondary">הזמנות שלא נשלחו${Number(draftCount||0)?` (${Number(draftCount)})`:''}</button><button id="mgSupplierHistory" class="mg-secondary">היסטוריה</button>${isManagement()?`<button id="mgManageCatalog" class="mg-secondary">ניהול קטלוג</button>`:''}</div>${editingBanner}<div class="mg-form-card mg-order-help"><b>איך מזמינים?</b><span>כל לחיצה על מוצר מוסיפה יחידה. אפשר לשמור באמצע כטיוטה ולהמשיך לעדכן אותה במהלך השבוע.</span></div><div id="mgProductGrid" class="mg-product-grid">${currentSupplierProducts.length?currentSupplierProducts.map(productOrderCard).join(''):'<div class="mg-empty">אין מוצרים פעילים בקטלוג של הספק.</div>'}</div><div id="mgOrderDock" class="mg-order-dock" hidden><div><b id="mgOrderUnits">0 יחידות</b><small id="mgOrderLines">0 מוצרים</small></div><button id="mgPreviewOrder" class="mg-primary">לסיכום ההזמנה ←</button></div></main></div>`;
    bindBack();
    document.getElementById('mgPageBack').onclick=renderSuppliers;
    document.getElementById('mgManageCatalog')?.addEventListener('click',()=>renderSupplierCatalog(supplierId));
    document.getElementById('mgSupplierHistory').onclick=()=>renderSupplierHistory(supplierId);
    document.getElementById('mgSupplierDrafts').onclick=()=>renderSupplierDrafts(supplierId);
    document.getElementById('mgCancelHistoryEdit')?.addEventListener('click',()=>{supplierCart=new Map();editingSourceOrderId=null;editingDraftOrderId=null;renderSupplierOrder(supplierId);});
    document.querySelectorAll('[data-product-add]').forEach(b=>b.onclick=()=>changeSupplierQuantity(b.dataset.productAdd,1));
    document.querySelectorAll('[data-product-minus]').forEach(b=>b.onclick=e=>{e.stopPropagation();changeSupplierQuantity(b.dataset.productMinus,-1);});
    document.getElementById('mgProductSearch').oninput=e=>filterSupplierProducts(e.target.value);
    document.getElementById('mgPreviewOrder').onclick=renderSupplierOrderPreview;
    updateSupplierCartUI();
  }

  function productOrderCard(p){
    return `<div class="mg-product-card" data-product-row="${esc(p.id)}" data-search="${esc(String(p.name||'').toLowerCase())}"><button class="mg-product-add" data-product-add="${esc(p.id)}"><span>${esc(p.name)}</span><b data-product-qty="${esc(p.id)}" hidden>0</b></button><button class="mg-product-minus" data-product-minus="${esc(p.id)}" hidden aria-label="הפחת כמות">−</button></div>`;
  }

  function changeSupplierQuantity(productId,delta){
    const old=Number(supplierCart.get(productId)||0), next=Math.max(0,old+delta);
    if(next)supplierCart.set(productId,next);else supplierCart.delete(productId);
    updateSupplierCartUI();
  }

  function updateSupplierCartUI(){
    let units=0;
    currentSupplierProducts.forEach(p=>{
      const q=Number(supplierCart.get(p.id)||0);units+=q;
      const badge=document.querySelector(`[data-product-qty="${p.id}"]`), minus=document.querySelector(`[data-product-minus="${p.id}"]`), row=document.querySelector(`[data-product-row="${p.id}"]`);
      if(badge){badge.textContent=String(q);badge.hidden=!q;} if(minus)minus.hidden=!q; if(row)row.classList.toggle('selected',q>0);
    });
    const dock=document.getElementById('mgOrderDock');if(!dock)return;
    dock.hidden=!units;document.getElementById('mgOrderUnits').textContent=`${units} יחידות`;document.getElementById('mgOrderLines').textContent=`${supplierCart.size} מוצרים`;
  }

  function filterSupplierProducts(term){
    const q=String(term||'').trim().toLowerCase();
    document.querySelectorAll('[data-product-row]').forEach(row=>row.hidden=!!q&&!String(row.dataset.search||'').includes(q));
  }

  function selectedSupplierItems(){
    return currentSupplierProducts.filter(p=>supplierCart.has(p.id)).map(p=>({...p,quantity:Number(supplierCart.get(p.id)||0)}));
  }

  function buildSupplierMessage(items){
    const lines=[`הזמנה ל${currentSupplier?.name||'ספק'} - ${WHATSAPP_BUSINESS_NAME}`,''];
    items.forEach(p=>lines.push(`${p.name} - ${p.sku} × ${p.quantity}`));
    return lines.join('\n');
  }

  function renderSupplierOrderPreview(){
    const items=selectedSupplierItems(); if(!items.length)return;
    const message=buildSupplierMessage(items);
    root.classList.remove('hidden');
    root.innerHTML=`${shellHeader(`סיכום הזמנה • ${currentSupplier.name}`,'🧾')}<div class="mg-form-card"><div class="mg-detail-head"><div><h3>הרשימה לסוכן</h3><p>${items.length} מוצרים • ${items.reduce((s,p)=>s+p.quantity,0)} יחידות${editingDraftOrderId?' • טיוטה קיימת':editingSourceOrderId?' • מבוססת על הזמנה קודמת':''}</p></div><button id="mgEditOrder" class="mg-back">עריכה</button></div><div class="mg-final-order">${items.map(p=>`<div><span>${esc(p.name)} <small>מק״ט ${esc(p.sku)}</small></span><b>× ${p.quantity}</b></div>`).join('')}</div><div class="mg-whatsapp-preview"><b>כך תישלח ההודעה:</b><pre>${esc(message)}</pre></div><div class="mg-order-final-actions"><button id="mgSaveDraft" class="mg-secondary">💾 שמור בהזמנות שעוד לא נשלחו</button><button id="mgSendWhatsApp" class="mg-whatsapp-btn">שלח לסוכן ב-WhatsApp</button></div><div id="mgOrderSendStatus" class="mg-progress-text"></div></div></main></div>`;
    bindBack();document.getElementById('mgPageBack').onclick=()=>renderSupplierOrder(currentSupplier.id);document.getElementById('mgEditOrder').onclick=()=>renderSupplierOrder(currentSupplier.id);document.getElementById('mgSaveDraft').onclick=saveSupplierDraft;document.getElementById('mgSendWhatsApp').onclick=sendSupplierOrder;
  }

  async function replaceSupplierOrderItems(orderId,items){
    const del=await sb.from('supplier_order_items').delete().eq('order_id',orderId).eq('business_id',profile.business_id);if(del.error)throw del.error;
    const rows=items.map((p,i)=>({order_id:orderId,business_id:profile.business_id,product_id:p.id,product_name:p.name,sku:p.sku,barcode:p.barcode||'',quantity:p.quantity,display_order:i}));
    if(rows.length){const ins=await sb.from('supplier_order_items').insert(rows);if(ins.error)throw ins.error;}
  }

  async function saveSupplierDraft(){
    const items=selectedSupplierItems();if(!items.length)return;
    const btn=document.getElementById('mgSaveDraft'),status=document.getElementById('mgOrderSendStatus');btn.disabled=true;status.textContent='שומר טיוטה…';
    try{
      const message=buildSupplierMessage(items);let orderId=editingDraftOrderId;
      if(orderId){
        const {error}=await sb.from('supplier_orders').update({status:'draft',whatsapp_phone_snapshot:currentSupplier.whatsapp_phone||'',message_text:message,updated_at:new Date().toISOString()}).eq('id',orderId).eq('business_id',profile.business_id);if(error)throw error;
      }else{
        const {data,error}=await sb.from('supplier_orders').insert({business_id:profile.business_id,supplier_id:currentSupplier.id,created_by:session.user.id,status:'draft',whatsapp_phone_snapshot:currentSupplier.whatsapp_phone||'',message_text:message,source_order_id:editingSourceOrderId||null}).select('id').single();if(error)throw error;orderId=data.id;
      }
      await replaceSupplierOrderItems(orderId,items);
      status.textContent='הטיוטה נשמרה ✓ אפשר לחזור אליה ולהמשיך לעדכן בהמשך.';
      supplierCart=new Map();editingDraftOrderId=null;editingSourceOrderId=null;
      setTimeout(()=>renderSupplierDrafts(currentSupplier.id),650);
    }catch(err){status.textContent='לא הצלחתי לשמור טיוטה: '+(err.message||err);btn.disabled=false;}
  }

  async function sendSupplierOrder(){
    const items=selectedSupplierItems();if(!items.length)return;
    const btn=document.getElementById('mgSendWhatsApp'),status=document.getElementById('mgOrderSendStatus');
    btn.disabled=true;status.textContent='שומר את ההזמנה…';
    const popup=window.open('about:blank','_blank');
    try{
      const message=buildSupplierMessage(items);let orderId=editingDraftOrderId;
      if(orderId){
        await replaceSupplierOrderItems(orderId,items);
        const {error}=await sb.from('supplier_orders').update({status:'sent',whatsapp_phone_snapshot:currentSupplier.whatsapp_phone||'',message_text:message,sent_at:new Date().toISOString(),updated_at:new Date().toISOString()}).eq('id',orderId).eq('business_id',profile.business_id);if(error)throw error;
      }else{
        const {data,error}=await sb.from('supplier_orders').insert({business_id:profile.business_id,supplier_id:currentSupplier.id,created_by:session.user.id,status:'sent',whatsapp_phone_snapshot:currentSupplier.whatsapp_phone||'',message_text:message,sent_at:new Date().toISOString(),source_order_id:editingSourceOrderId||null}).select('id').single();if(error)throw error;orderId=data.id;
        const rows=items.map((p,i)=>({order_id:orderId,business_id:profile.business_id,product_id:p.id,product_name:p.name,sku:p.sku,barcode:p.barcode||'',quantity:p.quantity,display_order:i}));
        const {error:itemError}=await sb.from('supplier_order_items').insert(rows);if(itemError)throw itemError;
      }
      const phone=cleanPhone(currentSupplier.whatsapp_phone);const url=`https://wa.me/${phone?phone:''}?text=${encodeURIComponent(message)}`;
      status.textContent='ההזמנה נשמרה בהיסטוריה. פותח WhatsApp…';supplierCart=new Map();editingSourceOrderId=null;editingDraftOrderId=null;
      if(popup){popup.location.href=url;}else{location.href=url;}
      setTimeout(()=>{btn.disabled=false;},1000);
    }catch(err){if(popup)popup.close();status.textContent='לא הצלחתי לשמור את ההזמנה: '+(err.message||err);btn.disabled=false;}
  }

  async function fetchSupplierOrdersWithItems(supplierId,status){
    const {data:orders,error}=await sb.from('supplier_orders').select('id,created_by,status,message_text,sent_at,created_at,updated_at,source_order_id').eq('business_id',profile.business_id).eq('supplier_id',supplierId).eq('status',status).order(status==='draft'?'updated_at':'created_at',{ascending:false}).limit(100);
    if(error)throw error;
    const ids=(orders||[]).map(o=>o.id);let items=[];
    if(ids.length){const r=await sb.from('supplier_order_items').select('order_id,product_id,product_name,sku,quantity,display_order').in('order_id',ids).order('display_order',{ascending:true});if(r.error)throw r.error;items=r.data||[];}
    const creators=[...new Set((orders||[]).map(o=>o.created_by).filter(Boolean))];let people=[];
    if(creators.length){const r=await sb.from('profiles').select('user_id,full_name,email').in('user_id',creators);people=r.data||[];}
    const person=new Map(people.map(p=>[p.user_id,p.full_name||p.email||'משתמש'])),byOrder=new Map();items.forEach(i=>{if(!byOrder.has(i.order_id))byOrder.set(i.order_id,[]);byOrder.get(i.order_id).push(i);});
    return {orders:orders||[],person,byOrder};
  }

  async function renderSupplierDrafts(supplierId){
    const {data:supplier,error}=await sb.from('suppliers').select('id,name').eq('business_id',profile.business_id).eq('id',supplierId).single();if(error){alert(error.message);return;}
    let bundle;try{bundle=await fetchSupplierOrdersWithItems(supplierId,'draft');}catch(err){alert(err.message);return;}
    const {orders,person,byOrder}=bundle;root.classList.remove('hidden');
    root.innerHTML=`${shellHeader(`הזמנות שעוד לא נשלחו • ${supplier.name}`,'📝')}<div class="mg-form-card"><h3>טיוטות פעילות</h3><p>אפשר לשמור הזמנה במהלך השבוע, לפתוח אותה שוב ולהוסיף או להוריד מוצרים עד השליחה הסופית.</p><div class="mg-supplier-history">${orders.length?orders.map(o=>{const oi=byOrder.get(o.id)||[],units=oi.reduce((a,i)=>a+Number(i.quantity||0),0);return `<div class="mg-order-history-row draft"><div class="mg-order-history-head"><span><b>עודכן ${esc(formatDateTime(o.updated_at||o.created_at))}</b><small>${esc(person.get(o.created_by)||'משתמש')} • ${oi.length} מוצרים • ${units} יחידות</small></span></div><div class="mg-order-history-items">${oi.map(i=>`<div><span>${esc(i.product_name)} <small>מק״ט ${esc(i.sku)}</small></span><b>× ${Number(i.quantity||0)}</b></div>`).join('')}</div><div class="mg-inline-buttons"><button class="mg-primary" data-open-draft="${esc(o.id)}">המשך עריכה</button><button class="mg-mini-btn danger" data-delete-draft="${esc(o.id)}">מחק טיוטה</button></div></div>`}).join(''):'<div class="mg-empty">אין כרגע הזמנות שממתינות לשליחה.</div>'}</div></div></main></div>`;
    bindBack();document.getElementById('mgPageBack').onclick=()=>renderSupplierOrder(supplierId);
    document.querySelectorAll('[data-open-draft]').forEach(b=>b.onclick=()=>editDraftOrder(b.dataset.openDraft,supplierId));
    document.querySelectorAll('[data-delete-draft]').forEach(b=>b.onclick=()=>deleteSupplierDraft(b.dataset.deleteDraft,supplierId));
  }

  async function editDraftOrder(orderId,supplierId){
    const [{data:order,error:orderError},{data:oldItems,error:itemError},{data:products,error:productError}]=await Promise.all([
      sb.from('supplier_orders').select('id,source_order_id,status').eq('business_id',profile.business_id).eq('id',orderId).single(),
      sb.from('supplier_order_items').select('product_id,quantity').eq('order_id',orderId).order('display_order',{ascending:true}),
      sb.from('supplier_products').select('id,is_active').eq('business_id',profile.business_id).eq('supplier_id',supplierId)
    ]);if(orderError||itemError||productError){alert((orderError||itemError||productError).message);return;}
    const available=new Set((products||[]).filter(p=>p.is_active!==false).map(p=>p.id));supplierCart=new Map();supplierCartSupplierId=supplierId;editingDraftOrderId=orderId;editingSourceOrderId=order.source_order_id||null;let unavailable=0;
    (oldItems||[]).forEach(i=>{if(i.product_id&&available.has(i.product_id))supplierCart.set(i.product_id,Number(i.quantity)||1);else unavailable++;});await renderSupplierOrder(supplierId);if(unavailable)alert(`${unavailable} מוצרים בטיוטה כבר אינם פעילים בקטלוג ולכן לא נטענו.`);
  }

  async function deleteSupplierDraft(orderId,supplierId){
    if(!confirm('למחוק את הטיוטה?'))return;const {error}=await sb.from('supplier_orders').delete().eq('id',orderId).eq('business_id',profile.business_id).eq('status','draft');if(error)alert(error.message);else renderSupplierDrafts(supplierId);
  }

  async function renderSupplierHistory(supplierId){
    const {data:supplier,error}=await sb.from('suppliers').select('id,name').eq('business_id',profile.business_id).eq('id',supplierId).single();if(error){alert(error.message);return;}
    let bundle;try{bundle=await fetchSupplierOrdersWithItems(supplierId,'sent');}catch(err){alert(err.message);return;}
    const {orders,person,byOrder}=bundle;root.classList.remove('hidden');
    root.innerHTML=`${shellHeader(`היסטוריית הזמנות • ${supplier.name}`,'🕘')}<div class="mg-form-card"><h3>הזמנות שנשלחו</h3><p>הזמנות שנשלחו נשמרות כתיעוד. מנהל יכול למחוק רשומות ישנות במידת הצורך.</p><div class="mg-supplier-history">${orders.length?orders.map(o=>{const oi=byOrder.get(o.id)||[],units=oi.reduce((a,i)=>a+Number(i.quantity||0),0);return `<div class="mg-order-history-row"><div class="mg-order-history-head"><span><b>${esc(formatDateTime(o.sent_at||o.created_at))}</b><small>${esc(person.get(o.created_by)||'משתמש')} • ${oi.length} מוצרים • ${units} יחידות${o.source_order_id?' • מבוססת על הזמנה קודמת':''}</small></span></div><div class="mg-order-history-items">${oi.map(i=>`<div><span>${esc(i.product_name)} <small>מק״ט ${esc(i.sku)}</small></span><b>× ${Number(i.quantity||0)}</b></div>`).join('')}</div><div class="mg-inline-buttons"><button class="mg-secondary" data-edit-old-order="${esc(o.id)}">ערוך והזמן שוב</button>${isManagement()?`<button class="mg-mini-btn danger" data-delete-old-order="${esc(o.id)}">מחק מההיסטוריה</button>`:''}</div></div>`}).join(''):'<div class="mg-empty">עדיין אין הזמנות שנשלחו.</div>'}</div></div></main></div>`;
    bindBack();document.getElementById('mgPageBack').onclick=()=>renderSupplierOrder(supplierId);document.querySelectorAll('[data-edit-old-order]').forEach(b=>b.onclick=()=>editHistoricalOrder(b.dataset.editOldOrder,supplierId));document.querySelectorAll('[data-delete-old-order]').forEach(b=>b.onclick=()=>deleteHistoricalOrder(b.dataset.deleteOldOrder,supplierId));
  }

  async function deleteHistoricalOrder(orderId,supplierId){
    if(!isManagement()||!confirm('למחוק את ההזמנה מההיסטוריה? הפעולה אינה ניתנת לביטול.'))return;const {error}=await sb.from('supplier_orders').delete().eq('id',orderId).eq('business_id',profile.business_id).eq('status','sent');if(error)alert(error.message);else renderSupplierHistory(supplierId);
  }

  async function editHistoricalOrder(orderId,supplierId){
    const [{data:oldItems,error:itemError},{data:products,error:productError}]=await Promise.all([
      sb.from('supplier_order_items').select('product_id,product_name,sku,quantity').eq('order_id',orderId).order('display_order',{ascending:true}),
      sb.from('supplier_products').select('id,name,sku,is_active').eq('business_id',profile.business_id).eq('supplier_id',supplierId)
    ]);
    if(itemError||productError){alert((itemError||productError).message);return;}
    const available=new Map((products||[]).filter(p=>p.is_active!==false).map(p=>[p.id,p]));
    supplierCart=new Map(); supplierCartSupplierId=supplierId; editingSourceOrderId=orderId;editingDraftOrderId=null;
    let unavailable=0;(oldItems||[]).forEach(i=>{if(i.product_id&&available.has(i.product_id))supplierCart.set(i.product_id,Number(i.quantity)||1);else unavailable++;});
    await renderSupplierOrder(supplierId);if(unavailable)alert(`${unavailable} מוצרים מההזמנה הישנה כבר אינם פעילים בקטלוג ולכן לא נטענו. אפשר לבחור מוצרים חלופיים מהרשימה.`);
  }

  async function renderSupplierCatalog(supplierId){
    if(!isManagement())return renderSupplierOrder(supplierId);
    const [{data:supplier,error:supplierError},{data:products,error:productError},{data:reminders,error:reminderError}]=await Promise.all([
      sb.from('suppliers').select('*').eq('business_id',profile.business_id).eq('id',supplierId).single(),
      sb.from('supplier_products').select('*').eq('business_id',profile.business_id).eq('supplier_id',supplierId).order('display_order',{ascending:true}).order('name',{ascending:true}),
      sb.from('supplier_order_reminders').select('*').eq('business_id',profile.business_id).eq('supplier_id',supplierId).order('day_of_week',{ascending:true}).order('reminder_time',{ascending:true})
    ]);
    if(supplierError||productError||reminderError){alert((supplierError||productError||reminderError).message);return;}
    currentSupplier=supplier;currentCatalogProducts=products||[];
    root.classList.remove('hidden');
    root.innerHTML=`${shellHeader(`ניהול קטלוג • ${supplier.name}`,'⚙️')}<div class="mg-form-card"><h3>הגדרות ספק</h3><div class="mg-two"><div class="mg-field"><label>WhatsApp של הסוכן</label><input id="mgCatalogPhone" inputmode="tel" value="${esc(supplier.whatsapp_phone||'')}" placeholder="0501234567"></div><div class="mg-field"><label>סדר לעובד</label><select id="mgCatalogSort"><option value="alphabetical" ${supplier.sort_mode!=='custom'?'selected':''}>א׳–ב׳ (ברירת מחדל)</option><option value="custom" ${supplier.sort_mode==='custom'?'selected':''}>סדר ידני</option></select></div></div><label class="mg-check"><input id="mgSupplierActive" type="checkbox" ${supplier.is_active!==false?'checked':''}> ספק פעיל</label><button id="mgSaveSupplierSettings" class="mg-secondary">שמור הגדרות</button><div id="mgCatalogSettingsMsg" class="mg-progress-text"></div></div><div class="mg-form-card"><div class="mg-detail-head"><div><h3>תזכורות להכנת הזמנה</h3><p>המערכת תזכיר למשתמשים שנכנסים למערכת ביום ובשעה שנבחרו.</p></div></div><form id="mgAddSupplierReminder"><div class="mg-two"><div class="mg-field"><label>יום</label><select id="mgReminderDay">${supplierDayLabels.map((d,i)=>`<option value="${i}">${d}</option>`).join('')}</select></div><div class="mg-field"><label>שעה</label><input id="mgReminderTime" type="time" required value="10:00"></div></div><div class="mg-field"><label>כותרת התזכורת</label><input id="mgReminderTitle" placeholder="להכין הזמנה ל${esc(supplier.name)}" value="להכין הזמנה ל${esc(supplier.name)}"></div><button class="mg-secondary">הוסף תזכורת</button></form><div class="mg-reminder-list">${(reminders||[]).length?(reminders||[]).map(r=>`<div class="mg-reminder-row${r.is_active===false?' inactive':''}"><span><b>${esc(r.title||`להכין הזמנה ל${supplier.name}`)}</b><small>${esc(reminderLabel(r))}</small></span><div><button class="mg-mini-btn" data-toggle-reminder="${esc(r.id)}" data-active="${r.is_active!==false}">${r.is_active===false?'הפעל':'כבה'}</button><button class="mg-mini-btn danger" data-delete-reminder="${esc(r.id)}">מחק</button></div></div>`).join(''):'<div class="mg-empty">לא הוגדרו תזכורות עדיין.</div>'}</div></div><div class="mg-form-card"><h3>הוספת מוצר</h3><form id="mgAddProduct"><div class="mg-field"><label>שם המוצר</label><input id="mgProductName" required placeholder="בולגרית 5%"></div><div class="mg-two"><div class="mg-field"><label>מק״ט החברה</label><input id="mgProductSku" required inputmode="numeric" placeholder="90108"></div><div class="mg-field"><label>ברקוד</label><input id="mgProductBarcode" inputmode="numeric" placeholder="729..."></div></div><button class="mg-primary">הוסף לקטלוג</button><div id="mgProductAddMsg" class="mg-error"></div></form></div><div class="mg-form-card"><div class="mg-detail-head"><div><h3>מוצרי ${esc(supplier.name)}</h3><p>${currentCatalogProducts.length} מוצרים • ${esc(supplierSortLabel(supplier.sort_mode))}</p></div></div><div class="mg-catalog-list">${currentCatalogProducts.length?currentCatalogProducts.map((p,i)=>catalogProductRow(p,i,supplier.sort_mode)).join(''):'<div class="mg-empty">הקטלוג עדיין ריק.</div>'}</div></div></main></div>`;
    bindBack();document.getElementById('mgPageBack').onclick=()=>renderSupplierOrder(supplierId);
    document.getElementById('mgSaveSupplierSettings').onclick=()=>saveSupplierSettings(supplierId);
    document.getElementById('mgAddSupplierReminder').onsubmit=e=>addSupplierReminder(e,supplierId);
    document.querySelectorAll('[data-toggle-reminder]').forEach(b=>b.onclick=()=>toggleSupplierReminder(b.dataset.toggleReminder,b.dataset.active!=='true',supplierId));
    document.querySelectorAll('[data-delete-reminder]').forEach(b=>b.onclick=()=>deleteSupplierReminder(b.dataset.deleteReminder,supplierId));
    document.getElementById('mgAddProduct').onsubmit=e=>addSupplierProduct(e,supplierId);
    document.querySelectorAll('[data-save-product]').forEach(b=>b.onclick=()=>saveSupplierProduct(b.dataset.saveProduct));
    document.querySelectorAll('[data-toggle-product]').forEach(b=>b.onclick=()=>toggleSupplierProduct(b.dataset.toggleProduct,b.dataset.active!=='true'));
    document.querySelectorAll('[data-move-product]').forEach(b=>b.onclick=()=>moveSupplierProduct(b.dataset.moveProduct,Number(b.dataset.direction)));
  }

  async function addSupplierReminder(e,supplierId){
    e.preventDefault();
    const row={business_id:profile.business_id,supplier_id:supplierId,title:document.getElementById('mgReminderTitle').value.trim()||`להכין הזמנה ל${currentSupplier?.name||'ספק'}`,day_of_week:Number(document.getElementById('mgReminderDay').value),reminder_time:document.getElementById('mgReminderTime').value,is_active:true,created_by:session.user.id};
    const {error}=await sb.from('supplier_order_reminders').insert(row);if(error)alert(error.message);else renderSupplierCatalog(supplierId);
  }

  async function toggleSupplierReminder(id,active,supplierId){
    const {error}=await sb.from('supplier_order_reminders').update({is_active:active,updated_by:session.user.id,updated_at:new Date().toISOString()}).eq('id',id).eq('business_id',profile.business_id);if(error)alert(error.message);else renderSupplierCatalog(supplierId);
  }

  async function deleteSupplierReminder(id,supplierId){
    if(!confirm('למחוק את התזכורת?'))return;
    const {error}=await sb.from('supplier_order_reminders').delete().eq('id',id).eq('business_id',profile.business_id);if(error)alert(error.message);else renderSupplierCatalog(supplierId);
  }

  function catalogProductRow(p,index,sortMode){
    const custom=sortMode==='custom';
    return `<div class="mg-catalog-row" data-catalog-row="${esc(p.id)}"><div class="mg-catalog-number">${index+1}</div><div class="mg-catalog-fields"><input data-field="name" value="${esc(p.name)}" aria-label="שם מוצר"><div><input data-field="sku" value="${esc(p.sku)}" placeholder="מק״ט"><input data-field="barcode" value="${esc(p.barcode||'')}" placeholder="ברקוד"></div></div><div class="mg-catalog-actions"><button class="mg-mini-btn" data-save-product="${esc(p.id)}">שמור</button><button class="mg-mini-btn ${p.is_active===false?'':'danger'}" data-toggle-product="${esc(p.id)}" data-active="${p.is_active!==false}">${p.is_active===false?'הפעל':'השבת'}</button>${custom?`<button class="mg-order-move" data-move-product="${esc(p.id)}" data-direction="-1" ${index===0?'disabled':''}>↑</button><button class="mg-order-move" data-move-product="${esc(p.id)}" data-direction="1" ${index===currentCatalogProducts.length-1?'disabled':''}>↓</button>`:''}</div></div>`;
  }

  async function saveSupplierSettings(supplierId){
    const row={whatsapp_phone:document.getElementById('mgCatalogPhone').value.trim(),sort_mode:document.getElementById('mgCatalogSort').value,is_active:document.getElementById('mgSupplierActive').checked,updated_by:session.user.id,updated_at:new Date().toISOString()};
    const {error}=await sb.from('suppliers').update(row).eq('id',supplierId).eq('business_id',profile.business_id);
    const msg=document.getElementById('mgCatalogSettingsMsg');msg.textContent=error?'שגיאה: '+error.message:'ההגדרות נשמרו ✓';if(!error)setTimeout(()=>renderSupplierCatalog(supplierId),450);
  }

  async function addSupplierProduct(e,supplierId){
    e.preventDefault();const msg=document.getElementById('mgProductAddMsg');msg.classList.remove('show');
    const maxOrder=currentCatalogProducts.reduce((m,p)=>Math.max(m,Number(p.display_order)||0),0);
    const row={business_id:profile.business_id,supplier_id:supplierId,name:document.getElementById('mgProductName').value.trim(),sku:document.getElementById('mgProductSku').value.trim(),barcode:document.getElementById('mgProductBarcode').value.trim(),display_order:maxOrder+10,created_by:session.user.id};
    const {error}=await sb.from('supplier_products').insert(row);if(error){msg.textContent='לא הצלחתי להוסיף מוצר: '+error.message;msg.classList.add('show');return;}renderSupplierCatalog(supplierId);
  }

  async function saveSupplierProduct(productId){
    const row=document.querySelector(`[data-catalog-row="${productId}"]`);if(!row)return;
    const value=f=>row.querySelector(`[data-field="${f}"]`)?.value.trim()||'';
    const {error}=await sb.from('supplier_products').update({name:value('name'),sku:value('sku'),barcode:value('barcode'),updated_by:session.user.id,updated_at:new Date().toISOString()}).eq('id',productId).eq('business_id',profile.business_id);
    if(error)alert(error.message);else renderSupplierCatalog(currentSupplier.id);
  }

  async function toggleSupplierProduct(productId,active){
    const {error}=await sb.from('supplier_products').update({is_active:active,updated_by:session.user.id,updated_at:new Date().toISOString()}).eq('id',productId).eq('business_id',profile.business_id);
    if(error)alert(error.message);else renderSupplierCatalog(currentSupplier.id);
  }

  async function moveSupplierProduct(productId,direction){
    const rows=[...currentCatalogProducts].sort((a,b)=>(Number(a.display_order)||0)-(Number(b.display_order)||0)||String(a.name||'').localeCompare(String(b.name||''),'he'));
    const index=rows.findIndex(p=>p.id===productId),other=rows[index+direction];if(index<0||!other)return;
    const a=rows[index],aOrder=Number(a.display_order)||index*10,bOrder=Number(other.display_order)||(index+direction)*10;
    const [ra,rb]=await Promise.all([
      sb.from('supplier_products').update({display_order:bOrder,updated_by:session.user.id,updated_at:new Date().toISOString()}).eq('id',a.id).eq('business_id',profile.business_id),
      sb.from('supplier_products').update({display_order:aOrder,updated_by:session.user.id,updated_at:new Date().toISOString()}).eq('id',other.id).eq('business_id',profile.business_id)
    ]);
    if(ra.error||rb.error)alert((ra.error||rb.error).message);else renderSupplierCatalog(currentSupplier.id);
  }

  // V2.3 — Signage printing + store shortage lists
  const SIGNAGE_TYPES = [
    {key:'small_regular',label:'מחיר רגיל קטן',group:'שילוט קטן',kind:'regular'},
    {key:'small_sale',label:'מבצע קטן',group:'שילוט קטן',kind:'sale'},
    {key:'small_qty',label:'מבצע כמות קטן',group:'שילוט קטן',kind:'qty'},
    {key:'large_regular',label:'מחיר רגיל גדול',group:'שילוט גדול',kind:'regular'},
    {key:'large_sale',label:'מבצע גדול',group:'שילוט גדול',kind:'sale'},
    {key:'large_qty',label:'מבצע כמות גדול',group:'שילוט גדול',kind:'qty'},
    {key:'basta',label:'בסטה',group:'תצוגה',kind:'basta'}
  ];
  const signageType = key => SIGNAGE_TYPES.find(t=>t.key===key)||SIGNAGE_TYPES[0];
  const moneyParts = value => { const n=Math.max(0,Number(value||0));const fixed=n.toFixed(2).split('.');return {major:String(Number(fixed[0])),minor:fixed[1]}; };
  const signageValue = id => document.getElementById(id)?.value?.trim?.()||'';

  const SIGNAGE_ELEMENT_LABELS = {
    company:'שם חברה',product:'שם מוצר',price:'מחיר',price_side:'אגורות + ₪',qty:'כמות / יח׳ ב־',
    before:'מחיר רגיל / מחיר יח׳',notes:'הערות / התניות',barcode:'ברקוד',origin:'תוצרת'
  };
  const SIGNAGE_DEFAULT_X = 20;
  const finiteOr = (v,fallback=0) => { const n=Number(v); return Number.isFinite(n)?n:fallback; };
  const cleanSignageLayout = raw => {
    const out={};
    if(!raw || typeof raw!=='object')return out;
    Object.entries(raw).forEach(([key,val])=>{
      if(!val || typeof val!=='object')return;
      out[key]={x:finiteOr(val.x,0),y:finiteOr(val.y,0),scale:Math.min(1.6,Math.max(.5,finiteOr(val.scale,1)))};
    });
    return out;
  };
  const signageEditableElements = type => type.kind==='basta'
    ? ['product','origin','price','price_side']
    : type.kind==='regular'
      ? ['company','product','price','price_side','notes','barcode']
      : type.kind==='sale'
        ? ['company','product','price','price_side','before','notes','barcode']
        : ['company','product','price','price_side','qty','before','notes','barcode'];
  function signageConfig(type){
    let cfg=signageSettings.get(type.key);
    if(!cfg){cfg={x:SIGNAGE_DEFAULT_X,y:0,layout:{}};signageSettings.set(type.key,cfg);}
    if(!cfg.layout)cfg.layout={};
    return cfg;
  }
  function signageElementConfig(type,key){
    const cfg=signageConfig(type), cur=cfg.layout[key]||{};
    return {x:finiteOr(cur.x,0),y:finiteOr(cur.y,0),scale:Math.min(1.6,Math.max(.5,finiteOr(cur.scale,1)))};
  }
  function signageElementStyle(type,key){
    const a=signageElementConfig(type,key);
    return `--el-x:${a.x}mm;--el-y:${a.y}mm;--el-scale:${a.scale}`;
  }
  function setSignageElementConfig(type,key,next){
    const cfg=signageConfig(type), cur=signageElementConfig(type,key);
    cfg.layout[key]={x:finiteOr(next.x,cur.x),y:finiteOr(next.y,cur.y),scale:Math.min(1.6,Math.max(.5,finiteOr(next.scale,cur.scale)))};
  }

  function produceCatalogFromConfig(config){
    const names=[];
    const push=v=>{const n=String(v||'').trim();if(n)names.push(n);};
    const cols=config?.columns||{};
    ['right','middle','leftTop','leftHerbs'].forEach(k=>(Array.isArray(cols[k])?cols[k]:[]).forEach(push));
    (Array.isArray(config?.apples)?config.apples:[]).forEach(r=>push(r?.name));
    (Array.isArray(config?.yokneam)?config.yokneam:[]).forEach(r=>push(r?.name));
    return [...new Set(names)].sort((a,b)=>a.localeCompare(b,'he'));
  }
  async function loadInventoryProduceCatalog(){
    let cfg=cloudConfig;
    if(!cfg){
      try{
        const {data}=await sb.from('inventory_configuration').select('config_json').eq('business_id',profile.business_id).maybeSingle();
        if(data?.config_json)cfg=data.config_json;
      }catch(_e){}
    }
    if(!cfg)cfg=extractConfig(parseState(localRaw()||'{}'));
    return produceCatalogFromConfig(cfg);
  }
  async function loadSignageProduceCatalog(){
    try{
      const {data,error}=await sb.from('customer_catalog_products')
        .select('display_name,is_basta_item,active,department_id,customer_catalog_departments!inner(slug)')
        .eq('business_id',profile.business_id).eq('active',true).eq('is_basta_item',true)
        .eq('customer_catalog_departments.slug','produce')
        .order('popularity_score',{ascending:false});
      if(!error && data?.length){
        signageProduceCatalog=[...new Set(data.map(x=>String(x.display_name||'').trim()).filter(Boolean))];
        return;
      }
    }catch(_e){}
    signageProduceCatalog=await loadInventoryProduceCatalog();
  }
  const normalizedBarcode = value => String(value||'').replace(/\D/g,'').trim();
  async function lookupProductByBarcode(value){
    const barcode=normalizedBarcode(value);
    if(barcode.length<7)throw new Error('ברקוד קצר מדי');
    const {data,error}=await sb.functions.invoke('product-lookup',{body:{barcode,allow_cheapersal:false}});
    if(error)throw new Error(error.message||'שגיאה בזיהוי המוצר');
    if(!data?.found)throw new Error(data?.message||'המוצר לא נמצא בקובצי שקיפות המחירים');
    return data.product||data;
  }
  let activeBarcodeScanner = null;
  async function removeBarcodeScanner(){
    const modal=document.getElementById('mgBarcodeScannerModal');
    const scanner=activeBarcodeScanner;activeBarcodeScanner=null;
    if(scanner){try{await scanner.stop();}catch(_e){}try{scanner.clear?.();}catch(_e){}}
    modal?.remove();
  }
  async function scanBarcodeLive(onDetected,statusEl){
    await removeBarcodeScanner();
    const modal=document.createElement('div');modal.id='mgBarcodeScannerModal';modal.className='mg-scanner-modal';
    modal.innerHTML=`<div class="mg-scanner-sheet" dir="rtl"><div class="mg-scanner-head"><div><b>סריקת ברקוד</b><small>כוון את המצלמה לברקוד שעל המוצר.</small></div><button type="button" class="mg-scanner-close" aria-label="סגור">✕</button></div><div id="mgBarcodeReader" class="mg-barcode-reader"></div><div id="mgScannerStatus" class="mg-progress-text">פותח סורק…</div><div class="mg-scanner-photo"><input id="mgScannerPhotoInput" type="file" accept="image/*" capture="environment" hidden><button id="mgScannerPhotoButton" type="button" class="mg-secondary">📸 צלם ברקוד</button><small>באייפון אפשר גם לצלם את הברקוד אם הסריקה החיה מתקשה.</small></div><div class="mg-scanner-manual"><label>או הקלד ברקוד</label><div><input id="mgScannerManualInput" inputmode="numeric" placeholder="729..."><button id="mgScannerManualUse" type="button" class="mg-primary">השתמש</button></div></div></div>`;
    document.body.appendChild(modal);
    const status=modal.querySelector('#mgScannerStatus');
    const finish=async value=>{const code=normalizedBarcode(value);if(!code)return;statusEl&&(statusEl.textContent=`זוהה ${code} — מחפש מוצר…`);await removeBarcodeScanner();await onDetected(code);};
    modal.querySelector('.mg-scanner-close').onclick=()=>removeBarcodeScanner();
    modal.addEventListener('click',e=>{if(e.target===modal)removeBarcodeScanner();});
    modal.querySelector('#mgScannerManualUse').onclick=()=>finish(modal.querySelector('#mgScannerManualInput').value);
    modal.querySelector('#mgScannerManualInput').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();finish(e.currentTarget.value);}};
    const photoInput=modal.querySelector('#mgScannerPhotoInput');modal.querySelector('#mgScannerPhotoButton').onclick=()=>photoInput.click();
    photoInput.onchange=async()=>{const file=photoInput.files?.[0];if(!file)return;if(typeof window.Html5Qrcode!=='function'){status.textContent='מנוע הזיהוי לא נטען. אפשר להקליד ידנית.';return;}status.textContent='קורא את הברקוד מהתמונה…';try{let scanner=activeBarcodeScanner;if(scanner){try{await scanner.stop();}catch(_e){}}if(!scanner)scanner=new window.Html5Qrcode('mgBarcodeReader');activeBarcodeScanner=scanner;const decoded=await scanner.scanFile(file,true);await finish(decoded);}catch(err){status.textContent='לא זוהה ברקוד בתמונה. נסה לצלם קרוב וישר יותר.';console.warn(err);}};
    if(typeof window.Html5Qrcode!=='function'){status.textContent='מנוע הסריקה לא נטען. אפשר לצלם או להקליד את הברקוד.';return;}
    try{
      const scanner=new window.Html5Qrcode('mgBarcodeReader');activeBarcodeScanner=scanner;
      const cfg={fps:10,qrbox:{width:280,height:125},aspectRatio:1.777};
      if(window.Html5QrcodeSupportedFormats)cfg.formatsToSupport=[window.Html5QrcodeSupportedFormats.EAN_13,window.Html5QrcodeSupportedFormats.EAN_8,window.Html5QrcodeSupportedFormats.UPC_A,window.Html5QrcodeSupportedFormats.UPC_E].filter(v=>v!==undefined);
      status.textContent='מבקש גישה למצלמה…';
      await scanner.start({facingMode:'environment'},cfg,decoded=>finish(decoded),()=>{});
      status.textContent='מוכן לסריקה';
    }catch(err){status.textContent='לא ניתן לפתוח סריקה חיה. אפשר ללחוץ “צלם ברקוד” או להקליד ידנית.';console.warn('barcode camera',err);}
  }
  function barcodeLookupHtml(){
    return `<div class="mg-barcode-lookup"><div class="mg-field"><label>ברקוד</label><div class="mg-barcode-row"><input id="signBarcode" inputmode="numeric" autocomplete="off" placeholder="729..."><button id="mgLookupSignBarcode" class="mg-secondary" type="button">זהה מוצר</button><button id="mgScanSignBarcode" class="mg-secondary" type="button">📷 סרוק</button></div><small id="mgSignBarcodeStatus">זיהוי אוטומטי ממאגרי שקיפות המחירים בישראל. המחיר לא מתמלא אוטומטית.</small></div></div>`;
  }
  function bindSignageBarcodeLookup(){
    const input=document.getElementById('signBarcode'),lookup=document.getElementById('mgLookupSignBarcode'),scan=document.getElementById('mgScanSignBarcode'),status=document.getElementById('mgSignBarcodeStatus');
    if(!input||!lookup)return;
    const run=async raw=>{const barcode=normalizedBarcode(raw||input.value);if(!barcode)return;input.value=barcode;lookup.disabled=true;if(status)status.textContent='מזהה מוצר לפי הברקוד…';try{const p=await lookupProductByBarcode(barcode);const product=document.getElementById('signProduct'),company=document.getElementById('signCompany');if(product)product.value=p.name||p.description||'';if(company&&p.manufacturer)company.value=p.manufacturer;if(status)status.textContent=`נמצא ✓ ${p.source_label||'שקיפות מחירים'}${p.unit_qty?' • '+p.unit_qty:''}`;}catch(e){if(status)status.textContent=e.message||String(e);}finally{lookup.disabled=false;}};
    lookup.onclick=()=>run(input.value);input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();run(input.value);}});
    if(scan)scan.onclick=async()=>{try{await scanBarcodeLive(run,status);}catch(e){if(status)status.textContent=e.message||String(e);}};
  }

  async function loadSignageSettings(){
    signageSettings=new Map();
    const {data,error}=await sb.from('signage_settings').select('template_key,offset_x_mm,offset_y_mm,layout_json').eq('business_id',profile.business_id);
    if(error){ console.warn('signage settings',error); return; }
    (data||[]).forEach(r=>signageSettings.set(r.template_key,{x:finiteOr(r.offset_x_mm,SIGNAGE_DEFAULT_X),y:finiteOr(r.offset_y_mm,0),layout:cleanSignageLayout(r.layout_json)}));
  }

  function bastaPopularProducts(){
    const preferred=['עגבניה','עגבנייה','מלפפון','פלפל','בצל','תפוח אדמה','בננה','תפוח','אבוקדו','לימון','תפוז','חציל','קישוא','גזר'];
    const norm=v=>String(v||'').trim().replace(/[׳'"״]/g,'').replace(/\s+/g,' ').toLowerCase();
    const out=[];
    preferred.forEach(w=>{const nw=norm(w);const hit=signageProduceCatalog.find(x=>norm(x)===nw||norm(x).includes(nw)||nw.includes(norm(x)));if(hit&&!out.includes(hit))out.push(hit);});
    signageProduceCatalog.forEach(x=>{if(out.length<10&&!out.includes(x))out.push(x);});
    return out.slice(0,10);
  }
  function bindBastaProductPicker(){
    const input=document.getElementById('signProduct'),results=document.querySelector('[data-basta-results]');if(!input)return;
    const choose=value=>{input.value=value||'';if(results){results.innerHTML='';results.hidden=true;}input.dispatchEvent(new Event('change',{bubbles:true}));input.focus();};
    const render=()=>{if(!results)return;const q=String(input.value||'').trim().toLowerCase();if(!q){results.innerHTML='';results.hidden=true;return;}const matches=signageProduceCatalog.filter(x=>x.toLowerCase().includes(q)).slice(0,8);if(!matches.length){results.innerHTML='<small>לא נמצא ברשימה — אפשר להשאיר את השם שהקלדת ולהמשיך.</small>';results.hidden=false;return;}results.innerHTML=matches.map(n=>`<button type="button" data-basta-result="${esc(n)}">${esc(n)}</button>`).join('');results.hidden=false;results.querySelectorAll('[data-basta-result]').forEach(btn=>btn.onclick=()=>choose(btn.dataset.bastaResult));};
    document.querySelectorAll('[data-basta-product]').forEach(btn=>btn.addEventListener('click',()=>choose(btn.dataset.bastaProduct)));
    input.addEventListener('input',render);input.addEventListener('focus',render);
  }
  function signageFieldsHtml(type){
    if(type.kind==='basta'){
      const options=signageProduceCatalog.map(n=>`<option value="${esc(n)}"></option>`).join('');
      const popular=bastaPopularProducts();
      return `<div class="mg-basta-product-picker"><div class="mg-field"><label>פרי / ירק</label><input id="signProduct" list="mgBastaProduceList" required autocomplete="off" placeholder="חפש ברשימה או הקלד ידנית…"><datalist id="mgBastaProduceList">${options}</datalist><small>אפשר לבחור מהרשימה, לחפש לפי שם או להקליד מוצר שלא קיים בקטלוג.</small><div class="mg-basta-search-results" data-basta-results hidden></div></div>${popular.length?`<div class="mg-basta-popular"><b>פופולריים</b><div class="mg-basta-popular-list">${popular.map(n=>`<button type="button" class="mg-basta-popular-chip" data-basta-product="${esc(n)}">${esc(n)}</button>`).join('')}</div></div>`:''}</div><div class="mg-basta-quick"><div class="mg-field mg-basta-price"><label>מחיר</label><input id="signPrice" type="number" min="0" step="0.01" inputmode="decimal" required placeholder="7.90"></div></div><details class="mg-basta-options"><summary>אפשרויות נוספות</summary><div class="mg-two"><div class="mg-field"><label>תוצרת</label><input id="signOrigin" value="ישראל" placeholder="ישראל"></div><div class="mg-field"><label>יחידת מכירה</label><select id="signUnit"><option value="kg" selected>לק״ג</option><option value="unit">ליח׳</option></select></div></div></details>`;
    }
    const lookup=barcodeLookupHtml();
    const common=`<div class="mg-two"><div class="mg-field"><label>שם חברה</label><input id="signCompany" placeholder="לדוגמה: גד"></div><div class="mg-field"><label>שם מוצר</label><input id="signProduct" required placeholder="שם המוצר"></div></div>`;
    const notes=`<div class="mg-field"><label>התניות / הערות</label><textarea id="signNotes" rows="3" placeholder="לדוגמה: בקנייה מעל 100 ₪&#10;מוגבל ל-2 מימושים"></textarea></div>`;
    if(type.kind==='regular')return lookup+common+`<div class="mg-field"><label>מחיר</label><input id="signPrice" type="number" min="0" step="0.01" inputmode="decimal" required placeholder="15.90"></div><label class="mg-check"><input id="signNoPromo" type="checkbox"> לא משתתף במבצע</label>${notes}`;
    if(type.kind==='sale')return lookup+common+`<div class="mg-two"><div class="mg-field"><label>מחיר מבצע</label><input id="signPrice" type="number" min="0" step="0.01" inputmode="decimal" required placeholder="12.90"></div><div class="mg-field"><label>מחיר רגיל לפני מבצע</label><input id="signRegularPrice" type="number" min="0" step="0.01" inputmode="decimal" required placeholder="19.90"></div></div>${notes}`;
    return lookup+common+`<div class="mg-two"><div class="mg-field"><label>כמות במבצע</label><input id="signQuantity" type="number" min="2" step="1" inputmode="numeric" required placeholder="2"></div><div class="mg-field"><label>מחיר מבצע</label><input id="signPrice" type="number" min="0" step="0.01" inputmode="decimal" required placeholder="24.00"></div></div><div class="mg-field"><label>מחיר ליחידה לפני מבצע</label><input id="signRegularPrice" type="number" min="0" step="0.01" inputmode="decimal" required placeholder="17.90"></div>${notes}`;
  }

  function signageData(type){
    return {type:type.key,company:signageValue('signCompany'),product:signageValue('signProduct'),price:signageValue('signPrice'),regularPrice:signageValue('signRegularPrice'),quantity:signageValue('signQuantity'),notes:signageValue('signNotes'),barcode:signageValue('signBarcode'),origin:signageValue('signOrigin')||'ישראל',unit:signageValue('signUnit')||'kg',noPromo:!!document.getElementById('signNoPromo')?.checked};
  }

  function eanBits(raw){
    let digits=String(raw||'').replace(/\D/g,'');
    const L={'0':'0001101','1':'0011001','2':'0010011','3':'0111101','4':'0100011','5':'0110001','6':'0101111','7':'0111011','8':'0110111','9':'0001011'};
    const G={'0':'0100111','1':'0110011','2':'0011011','3':'0100001','4':'0011101','5':'0111001','6':'0000101','7':'0010001','8':'0001001','9':'0010111'};
    const R={'0':'1110010','1':'1100110','2':'1101100','3':'1000010','4':'1011100','5':'1001110','6':'1010000','7':'1000100','8':'1001000','9':'1110100'};
    const parity=['LLLLLL','LLGLGG','LLGGLG','LLGGGL','LGLLGG','LGGLLG','LGGGLL','LGLGLG','LGLGGL','LGGLGL'];
    const check = body => {let s=0,flip=true;for(let i=body.length-1;i>=0;i--){s+=Number(body[i])*(flip?3:1);flip=!flip;}return String((10-(s%10))%10);};
    if(digits.length===12)digits+=check(digits);
    if(digits.length===7)digits+=check(digits);
    if(digits.length===13){let bits='101',p=parity[Number(digits[0])];for(let i=1;i<=6;i++)bits+=(p[i-1]==='L'?L:G)[digits[i]];bits+='01010';for(let i=7;i<13;i++)bits+=R[digits[i]];return {bits:bits+'101',digits};}
    if(digits.length===8){let bits='101';for(let i=0;i<4;i++)bits+=L[digits[i]];bits+='01010';for(let i=4;i<8;i++)bits+=R[digits[i]];return {bits:bits+'101',digits};}
    return null;
  }
  function barcodeSvg(value){
    const e=eanBits(value);if(!e)return value?`<div class="sign-barcode-fallback">${esc(value)}</div>`:'';
    const w=1.15,h=31,total=e.bits.length*w;let bars='';for(let i=0;i<e.bits.length;i++)if(e.bits[i]==='1')bars+=`<rect x="${(i*w).toFixed(2)}" y="0" width="${w.toFixed(2)}" height="${h}"/>`;
    return `<svg class="sign-barcode" viewBox="0 0 ${total.toFixed(2)} 38" role="img" aria-label="ברקוד ${esc(e.digits)}"><g fill="#000">${bars}</g><text x="${(total/2).toFixed(2)}" y="37" text-anchor="middle" font-family="Arial" font-size="5">${esc(e.digits)}</text></svg>`;
  }
  function barcodeText(value){
    const digits=normalizedBarcode(value);
    return digits?`<div class="sign-barcode-number" style="font-size:4mm;letter-spacing:.55mm;font-weight:700;line-height:1;direction:ltr;white-space:nowrap;text-align:center">${esc(digits)}</div>`:'';
  }
  function priceMarkup(type,value,unit=''){
    const p=moneyParts(value);
    const unitHtml=unit?`<span class="sign-unit">${esc(unit)}</span>`:'';
    return `<span class="sign-price-content"><span class="sign-price-major">${esc(p.major)}</span><span class="sign-price-side sign-adjustable-inner" data-sign-el="price_side" style="${signageElementStyle(type,'price_side')}"><span class="sign-price-minor">${esc(p.minor)}</span><span class="sign-shekel">₪</span>${unitHtml}</span></span>`;
  }
  const signageBox = (type,key,classes,html) => `<div class="${classes} sign-adjustable" data-sign-el="${key}" style="${signageElementStyle(type,key)}">${html}</div>`;
  function notesMarkup(type,d){
    const lines=[];
    if(d.noPromo)lines.push('לא משתתף במבצע');
    if(d.notes)lines.push(...d.notes.split(/\n+/).map(x=>x.trim()).filter(Boolean));
    return lines.length?signageBox(type,'notes','sign-notes sign-fit sign-fit-wrap',lines.map(x=>`<div>${esc(x)}</div>`).join('')):'';
  }
  function buildSignageMarkup(type,d,preview=false){
    const cal=signageConfig(type);
    const style=`--sign-x:${finiteOr(cal.x,SIGNAGE_DEFAULT_X)}mm;--sign-y:${finiteOr(cal.y,0)}mm`;
    let body='';
    if(type.kind==='basta'){
      body=signageBox(type,'product','sign-product sign-fit sign-fit-single',esc(d.product))+
        signageBox(type,'origin','sign-origin sign-fit sign-fit-single',`תוצרת ${esc(d.origin||'ישראל')}`)+
        signageBox(type,'price','sign-price',priceMarkup(type,d.price,d.unit==='unit'?'ליח׳':'לק״ג'));
    }else if(type.kind==='regular'){
      body=signageBox(type,'company','sign-company sign-fit sign-fit-single',esc(d.company))+
        signageBox(type,'product','sign-product sign-fit sign-fit-single',esc(d.product))+
        signageBox(type,'price','sign-price',priceMarkup(type,d.price))+
        notesMarkup(type,d)+signageBox(type,'barcode','sign-barcode-wrap',barcodeText(d.barcode));
    }else if(type.kind==='sale'){
      body=signageBox(type,'company','sign-company sign-fit sign-fit-single',esc(d.company))+
        signageBox(type,'product','sign-product sign-fit sign-fit-single',esc(d.product))+
        signageBox(type,'price','sign-price',priceMarkup(type,d.price))+
        signageBox(type,'before','sign-before sign-fit sign-fit-single',`מחיר רגיל: ${esc(Number(d.regularPrice||0).toFixed(2))} ₪`)+
        notesMarkup(type,d)+signageBox(type,'barcode','sign-barcode-wrap',barcodeText(d.barcode));
    }else{
      body=signageBox(type,'company','sign-company sign-fit sign-fit-single',esc(d.company))+
        signageBox(type,'product','sign-product sign-fit sign-fit-single',esc(d.product))+
        signageBox(type,'qty','sign-qty sign-fit sign-fit-single',`<span>${esc(d.quantity||'')}</span> יח׳ ב־`)+
        signageBox(type,'price','sign-price',priceMarkup(type,d.price))+
        signageBox(type,'before','sign-before sign-fit sign-fit-single',`מחיר יח׳: ${esc(Number(d.regularPrice||0).toFixed(2))} ₪`)+
        notesMarkup(type,d)+signageBox(type,'barcode','sign-barcode-wrap',barcodeText(d.barcode));
    }
    return `<div class="signage-paper${preview?' signage-preview-paper':''}" dir="rtl"><div class="signage-layout sign-${esc(type.key)}" style="${style}">${body}</div></div>`;
  }

  function fitSignageText(scope){
    if(!scope)return;
    const view=scope.defaultView||scope.ownerDocument?.defaultView||window;
    scope.querySelectorAll('.sign-fit').forEach(el=>{
      el.style.fontSize='';
      const computed=parseFloat(view.getComputedStyle(el).fontSize)||16;
      const min=computed*(el.classList.contains('sign-fit-wrap') ? .58 : .52);
      let size=computed,guard=0;
      while(size>min && guard++<120 && (el.scrollWidth>el.clientWidth+1 || el.scrollHeight>el.clientHeight+1)){
        size-=0.5;el.style.fontSize=`${size}px`;
      }
    });
    scope.querySelectorAll('.sign-price-content').forEach(el=>{
      el.style.transform='';
      const parent=el.parentElement;if(!parent)return;
      const er=el.getBoundingClientRect(),pr=parent.getBoundingClientRect();
      if(!er.width||!er.height||!pr.width||!pr.height)return;
      const scale=Math.min(1,(pr.width-2)/er.width,(pr.height-2)/er.height);
      if(scale<.999)el.style.transform=`scale(${Math.max(.68,scale)})`;
    });
  }

  async function renderSignage(){
    if(!requireModule('signage'))return;
    await Promise.all([loadSignageSettings(),loadSignageProduceCatalog()]);
    root.classList.remove('hidden');
    root.innerHTML=`${shellHeader('שילוט להדפסה','🖨️')}<div class="mg-form-card"><h3>סוג השילוט</h3><p>המערכת מדפיסה רק את התוכן המשתנה, באותם מיקומים של תבניות ה-Word. המסגרת, האליפסה ו"מבצע" שכבר מודפסים על השלט אינם מודפסים שוב.</p><div class="mg-sign-type-grid">${SIGNAGE_TYPES.map((t,i)=>`<button class="mg-sign-type${i===0?' active':''}" data-sign-type="${t.key}"><small>${esc(t.group)}</small><b>${esc(t.label)}</b></button>`).join('')}</div></div><div class="mg-form-card"><form id="mgSignageForm"><div id="mgSignageFields">${signageFieldsHtml(SIGNAGE_TYPES[0])}</div>${isManagement()?`<details class="mg-print-cal"><summary>כיול ועורך מיקום</summary><p>ברירת המחדל היא 20 מ״מ ימינה. אפשר להזיז את כל התבנית, או לבחור אלמנט בודד ולהזיז/להגדיל אותו. השינויים נשמרים ברמת העסק ומשפיעים על כל המשתמשים שקיבלו גישה לשילוט.</p><div class="mg-two"><div class="mg-field"><label>הזזה כללית X (מ״מ)</label><input id="signOffsetX" type="number" step="0.5" value="20"></div><div class="mg-field"><label>הזזה כללית Y (מ״מ)</label><input id="signOffsetY" type="number" step="0.5" value="0"></div></div><div class="mg-sign-editor"><h4>עורך אלמנט</h4><div class="mg-field"><label>מה להזיז?</label><select id="signElementSelect"></select></div><div class="mg-sign-editor-values"><div class="mg-field"><label>ימינה / שמאלה (מ״מ)</label><input id="signElementX" type="number" step="0.5" value="0"></div><div class="mg-field"><label>למטה / למעלה (מ״מ)</label><input id="signElementY" type="number" step="0.5" value="0"></div><div class="mg-field"><label>גודל (%)</label><input id="signElementScale" type="number" min="50" max="160" step="1" value="100"></div></div><div class="mg-sign-nudges"><button type="button" class="mg-secondary" data-sign-nudge="left">← 1 מ״מ</button><button type="button" class="mg-secondary" data-sign-nudge="right">1 מ״מ →</button><button type="button" class="mg-secondary" data-sign-nudge="up">↑ 1 מ״מ</button><button type="button" class="mg-secondary" data-sign-nudge="down">↓ 1 מ״מ</button></div><div class="mg-sign-editor-actions"><button id="mgResetSignElement" type="button" class="mg-secondary">אפס אלמנט</button><button id="mgResetAllSignElements" type="button" class="mg-secondary">אפס את כל האלמנטים</button></div><small>טיפ: פתח תצוגה מקדימה, בחר אלמנט והזז אותו. האלמנט הנבחר יסומן בירוק רק בתצוגה המקדימה — הסימון לא יודפס.</small></div><div class="mg-sign-cal-actions"><button id="mgSavePrintCalibration" type="button" class="mg-primary">שמור הגדרות הדפסה</button><button id="mgResetPrintCalibration" type="button" class="mg-secondary">אפס תבנית לברירת מחדל</button></div><div id="mgPrintCalMsg" class="mg-progress-text"></div></details>`:''}<div class="mg-sign-actions"><button id="mgPreviewSign" type="button" class="mg-secondary">תצוגה מקדימה</button><button class="mg-primary">שלח להדפסה</button></div></form></div><div id="mgSignagePreview"></div></main></div>`;
    bindBack();let selected=SIGNAGE_TYPES[0];
    const previewRoot=()=>document.getElementById('mgSignagePreview');
    const currentElementKey=()=>document.getElementById('signElementSelect')?.value||signageEditableElements(selected)[0];
    const highlightCurrent=()=>{const p=previewRoot();if(!p)return;p.querySelectorAll('[data-sign-el]').forEach(el=>el.classList.toggle('sign-editor-highlight',el.dataset.signEl===currentElementKey()));};
    const refreshPreview=(force=false)=>{const p=previewRoot();if(!p)return;if(!force&&!p.innerHTML)return;const data=signageData(selected);p.innerHTML=`<div class="mg-form-card"><div class="mg-detail-head"><div><h3>תצוגה מקדימה</h3><p>זהו מיקום התוכן על A4. האלמנטים שכבר קיימים על השלט הפיזי אינם מוצגים כאן.</p></div></div><div class="mg-signage-preview-wrap">${buildSignageMarkup(selected,data,true)}</div></div>`;requestAnimationFrame(()=>{fitSignageText(p);highlightCurrent();});};
    const applyCal=()=>{const c=signageConfig(selected);const x=document.getElementById('signOffsetX'),y=document.getElementById('signOffsetY');if(x)x.value=String(finiteOr(c.x,SIGNAGE_DEFAULT_X));if(y)y.value=String(finiteOr(c.y,0));};
    const loadElementInputs=()=>{const key=currentElementKey(),a=signageElementConfig(selected,key);const x=document.getElementById('signElementX'),y=document.getElementById('signElementY'),sc=document.getElementById('signElementScale');if(x)x.value=String(a.x);if(y)y.value=String(a.y);if(sc)sc.value=String(Math.round(a.scale*100));highlightCurrent();};
    const refreshEditor=()=>{const sel=document.getElementById('signElementSelect');if(!sel)return;const keys=signageEditableElements(selected);sel.innerHTML=keys.map(k=>`<option value="${k}">${esc(SIGNAGE_ELEMENT_LABELS[k]||k)}</option>`).join('');loadElementInputs();};
    const applyElementInputs=()=>{const key=currentElementKey();setSignageElementConfig(selected,key,{x:finiteOr(document.getElementById('signElementX')?.value,0),y:finiteOr(document.getElementById('signElementY')?.value,0),scale:finiteOr(document.getElementById('signElementScale')?.value,100)/100});refreshPreview();};
    applyCal();refreshEditor();bindSignageBarcodeLookup();bindBastaProductPicker();
    document.querySelectorAll('[data-sign-type]').forEach(btn=>btn.onclick=()=>{selected=signageType(btn.dataset.signType);document.querySelectorAll('[data-sign-type]').forEach(b=>b.classList.toggle('active',b===btn));document.getElementById('mgSignageFields').innerHTML=signageFieldsHtml(selected);previewRoot().innerHTML='';applyCal();refreshEditor();bindSignageBarcodeLookup();bindBastaProductPicker();});
    document.getElementById('mgPreviewSign').onclick=()=>{const form=document.getElementById('mgSignageForm');if(!form.reportValidity())return;refreshPreview(true);};
    document.getElementById('mgSignageForm').onsubmit=e=>{e.preventDefault();if(!e.currentTarget.reportValidity())return;printSignage(selected,signageData(selected));};
    ['signOffsetX','signOffsetY'].forEach(id=>document.getElementById(id)?.addEventListener('input',()=>{const cfg=signageConfig(selected);cfg.x=finiteOr(document.getElementById('signOffsetX')?.value,SIGNAGE_DEFAULT_X);cfg.y=finiteOr(document.getElementById('signOffsetY')?.value,0);refreshPreview();}));
    document.getElementById('signElementSelect')?.addEventListener('change',loadElementInputs);
    ['signElementX','signElementY','signElementScale'].forEach(id=>document.getElementById(id)?.addEventListener('input',applyElementInputs));
    document.querySelectorAll('[data-sign-nudge]').forEach(btn=>btn.addEventListener('click',()=>{const dir=btn.dataset.signNudge,x=document.getElementById('signElementX'),y=document.getElementById('signElementY');if(!x||!y)return;if(dir==='left')x.value=String(finiteOr(x.value,0)-1);if(dir==='right')x.value=String(finiteOr(x.value,0)+1);if(dir==='up')y.value=String(finiteOr(y.value,0)-1);if(dir==='down')y.value=String(finiteOr(y.value,0)+1);applyElementInputs();}));
    document.getElementById('mgResetSignElement')?.addEventListener('click',()=>{const key=currentElementKey(),cfg=signageConfig(selected);delete cfg.layout[key];loadElementInputs();refreshPreview();});
    document.getElementById('mgResetAllSignElements')?.addEventListener('click',()=>{signageConfig(selected).layout={};refreshEditor();refreshPreview();});
    document.getElementById('mgSavePrintCalibration')?.addEventListener('click',async()=>{const cfg=signageConfig(selected);cfg.x=finiteOr(document.getElementById('signOffsetX')?.value,SIGNAGE_DEFAULT_X);cfg.y=finiteOr(document.getElementById('signOffsetY')?.value,0);const row={business_id:profile.business_id,template_key:selected.key,offset_x_mm:cfg.x,offset_y_mm:cfg.y,layout_json:cfg.layout||{},updated_by:session.user.id,updated_at:new Date().toISOString()};const {error}=await sb.from('signage_settings').upsert(row,{onConflict:'business_id,template_key'});const msg=document.getElementById('mgPrintCalMsg');if(error)msg.textContent='לא נשמר: '+error.message;else msg.textContent='הגדרות ההדפסה נשמרו ✓';});
    document.getElementById('mgResetPrintCalibration')?.addEventListener('click',async()=>{const cfg={x:SIGNAGE_DEFAULT_X,y:0,layout:{}};const row={business_id:profile.business_id,template_key:selected.key,offset_x_mm:cfg.x,offset_y_mm:0,layout_json:{},updated_by:session.user.id,updated_at:new Date().toISOString()};const {error}=await sb.from('signage_settings').upsert(row,{onConflict:'business_id,template_key'});const msg=document.getElementById('mgPrintCalMsg');if(error)msg.textContent='לא אופס: '+error.message;else{signageSettings.set(selected.key,cfg);applyCal();refreshEditor();refreshPreview();msg.textContent='התבנית חזרה לברירת המחדל ✓';}});
  }

  const SIGNAGE_PRINT_CSS = ":root{--mg-green:#166534;--mg-green2:#15803d;--mg-bg:#f3f6f4;--mg-card:#fff;--mg-text:#17201b;--mg-muted:#68736b;--mg-line:#dfe6e1;--mg-danger:#b42318}\n#managementRoot{position:fixed;inset:0;z-index:200;background:var(--mg-bg);overflow:auto;padding:env(safe-area-inset-top) 0 env(safe-area-inset-bottom)}#managementRoot.hidden{display:none}\n.mg-shell{min-height:100%;display:flex;flex-direction:column}.mg-top{background:linear-gradient(135deg,#14532d,#166534 58%,#15803d);color:#fff;padding:18px 16px 20px}.mg-top-in{max-width:820px;margin:auto;display:flex;justify-content:space-between;align-items:center;gap:14px}.mg-brand strong{font-size:21px;display:block}.mg-brand span{font-size:12px;opacity:.82;display:block;margin-top:4px}.mg-user{display:flex;align-items:center;gap:9px}.mg-avatar{width:38px;height:38px;border-radius:12px;background:rgba(255,255,255,.16);display:grid;place-items:center;font-weight:900}.mg-user-meta{display:none}.mg-user-meta b,.mg-user-meta small{display:block}.mg-user-meta small{opacity:.78;margin-top:2px}.mg-logout{border:1px solid rgba(255,255,255,.24);background:rgba(255,255,255,.1);color:#fff;border-radius:10px;height:38px;padding:0 11px;font-weight:800}\n.mg-main{width:min(820px,100%);margin:0 auto;padding:16px;flex:1}.mg-hello{margin:4px 0 15px}.mg-hello h1{font-size:24px;margin:0 0 5px}.mg-hello p{margin:0;color:var(--mg-muted);font-size:13px}.mg-status{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:15px}.mg-chip{display:inline-flex;align-items:center;gap:6px;background:#fff;border:1px solid var(--mg-line);border-radius:999px;padding:7px 10px;font-size:12px;color:#526057}.mg-chip.ok{color:var(--mg-green);background:#f1faf4;border-color:#cde7d4}.mg-dot{width:7px;height:7px;border-radius:50%;background:currentColor}\n.mg-grid{display:grid;grid-template-columns:1fr;gap:11px}.mg-card{border:1px solid var(--mg-line);background:var(--mg-card);border-radius:17px;padding:15px;box-shadow:0 2px 14px rgba(24,39,30,.05);text-align:right;color:var(--mg-text)}button.mg-card{cursor:pointer;width:100%}.mg-card-head{display:flex;justify-content:space-between;align-items:flex-start;gap:10px}.mg-icon{width:43px;height:43px;border-radius:13px;background:#edf8f0;display:grid;place-items:center;font-size:23px}.mg-card h3{font-size:16px;margin:10px 0 4px}.mg-card p{font-size:12px;line-height:1.5;color:var(--mg-muted);margin:0}.mg-badge{font-size:10px;border-radius:999px;padding:5px 8px;background:#ecfdf5;color:var(--mg-green);font-weight:800}.mg-badge.soon{background:#f2f4f3;color:#7a837d}.mg-arrow{margin-top:13px;font-weight:800;color:var(--mg-green);font-size:13px}\n.mg-login{min-height:100dvh;display:grid;place-items:center;padding:20px}.mg-login-card{width:min(410px,100%);background:#fff;border:1px solid var(--mg-line);border-radius:22px;padding:22px;box-shadow:0 18px 55px rgba(22,101,52,.12)}.mg-login-logo{width:58px;height:58px;border-radius:18px;background:linear-gradient(135deg,#14532d,#15803d);display:grid;place-items:center;font-size:30px;margin-bottom:16px}.mg-login h1{margin:0 0 6px;font-size:25px}.mg-login p{margin:0 0 18px;color:var(--mg-muted);font-size:13px;line-height:1.55}.mg-field{margin:0 0 11px}.mg-field label{display:block;font-size:12px;font-weight:800;margin-bottom:6px}.mg-field input,.mg-field select{width:100%;height:47px;border:1px solid #cfd8d2;border-radius:12px;padding:0 12px;outline:none;background:#fff}.mg-field input:focus,.mg-field select:focus{border-color:#70ad84;box-shadow:0 0 0 3px #e4f3e9}.mg-primary{width:100%;height:48px;border:0;border-radius:12px;background:var(--mg-green);color:#fff;font-weight:900;font-size:15px}.mg-primary:disabled{opacity:.55}.mg-error{display:none;margin:10px 0 0;background:#fff4f2;color:var(--mg-danger);border:1px solid #f4ccc7;border-radius:10px;padding:9px 10px;font-size:12px;line-height:1.45}.mg-error.show{display:block}.mg-help{margin-top:13px;font-size:11px;color:#7b857e;line-height:1.5}.mg-setup{background:#fff8e8;border:1px solid #ecd59b;border-radius:14px;padding:13px;color:#6f5209;font-size:12px;line-height:1.55}\n.mg-panel-head{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:13px}.mg-panel-head h2{margin:0;font-size:20px}.mg-back{height:39px;border:1px solid var(--mg-line);border-radius:10px;background:#fff;color:#445048;font-weight:800;padding:0 11px}.mg-users-list{display:grid;gap:8px;margin-top:12px}.mg-member{background:#fff;border:1px solid var(--mg-line);border-radius:13px;padding:12px;display:flex;justify-content:space-between;align-items:center;gap:10px}.mg-member-main{min-width:0}.mg-member-main b,.mg-member-main small{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.mg-member-main small{color:var(--mg-muted);margin-top:3px}.mg-role{font-size:11px;font-weight:800;border-radius:999px;background:#eef8f1;color:var(--mg-green);padding:6px 8px;white-space:nowrap}.mg-form-card{background:#fff;border:1px solid var(--mg-line);border-radius:16px;padding:14px;margin-bottom:12px}.mg-form-card h3{margin:0 0 4px;font-size:15px}.mg-form-card>p{margin:0 0 12px;color:var(--mg-muted);font-size:12px;line-height:1.45}.mg-two{display:grid;grid-template-columns:1fr;gap:9px}.mg-secondary{height:44px;border:1px solid #b9d5c2;background:#eef8f1;color:var(--mg-green);border-radius:11px;font-weight:900;padding:0 13px}.inventory-management-strip{max-width:760px;margin:8px auto 0;display:flex;align-items:center;justify-content:space-between;gap:9px}.inventory-management-strip button{border:1px solid rgba(255,255,255,.28);background:rgba(255,255,255,.12);color:#fff;height:34px;border-radius:9px;padding:0 10px;font-weight:800;font-size:12px}.inventory-management-strip span{font-size:11px;opacity:.86}\n@media(min-width:620px){.mg-grid{grid-template-columns:1fr 1fr}.mg-user-meta{display:block}.mg-two{grid-template-columns:1fr 1fr}.mg-login-card{padding:28px}.mg-main{padding:20px}}\n/* V2 */\n.mg-clickable{cursor:pointer;width:100%}.mg-loading,.mg-empty{padding:18px;text-align:center;color:var(--mg-muted);font-size:13px}.mg-check{display:flex;align-items:center;gap:8px;font-size:13px;font-weight:800;margin:2px 0 14px}.mg-check input{width:18px;height:18px}.mg-calculator{max-width:580px;margin-inline:auto}.mg-calc-result{border:1px solid #b9d5c2;background:#f1faf4;border-radius:16px;padding:18px;text-align:center;margin-top:14px}.mg-calc-result small{display:block;color:var(--mg-muted);font-weight:800}.mg-calc-result strong{display:block;font-size:38px;line-height:1.05;color:var(--mg-green);margin:7px 0 9px;direction:ltr}.mg-calc-result div{font-size:12px;color:#536158;line-height:1.6;direction:rtl}\n.mg-history-list{display:grid;gap:8px;margin-top:12px}.mg-history-row{width:100%;border:1px solid var(--mg-line);background:#fff;border-radius:13px;padding:12px;display:flex;align-items:center;justify-content:space-between;gap:10px;text-align:right}.mg-history-row span b,.mg-history-row span small{display:block}.mg-history-row span small{color:var(--mg-muted);margin-top:4px;font-size:11px}.mg-history-row>strong{color:var(--mg-green);font-size:12px;white-space:nowrap}.mg-history-detail{scroll-margin-top:12px}.mg-detail-head{display:flex;justify-content:space-between;align-items:center;gap:10px}.mg-detail-head h3{margin:0}.mg-detail-head p{margin:3px 0 0;color:var(--mg-muted);font-size:11px}.mg-history-items{border-top:1px solid var(--mg-line);margin-top:12px;padding-top:8px}.mg-history-item{display:flex;justify-content:space-between;gap:12px;padding:7px 4px;border-bottom:1px solid #eef1ef;font-size:13px}.mg-history-item b{direction:ltr}.mg-history-section{margin:10px 0 3px;font-size:12px;font-weight:900;color:var(--mg-green);background:#f2f8f4;border-radius:8px;padding:6px 8px}.mg-history-notes{margin-top:12px;background:#f7f8f7;border-radius:10px;padding:10px;font-size:12px;line-height:1.55}\n.mg-member-wrap{border:1px solid var(--mg-line);border-radius:13px;overflow:hidden;background:#fff}.mg-member-wrap .mg-member{border:0;border-radius:0}.mg-member-actions{display:flex;align-items:center;justify-content:flex-end;gap:6px;flex-wrap:wrap}.mg-mini-btn{height:31px;border:1px solid var(--mg-line);background:#fff;border-radius:8px;padding:0 8px;font-size:11px;font-weight:800;color:#435047}.mg-mini-btn.danger{color:#a11b13;border-color:#edcac6;background:#fff7f5}.mg-inline-edit{border-top:1px solid var(--mg-line);background:#f8faf8;padding:12px}.mg-inline-buttons{display:flex;gap:8px;align-items:center}.mg-inline-buttons .mg-secondary{flex:1}.mg-users-list{gap:10px}\n.mg-upload{display:block;border:1.5px dashed #a7c5b0;background:#f5fbf7;border-radius:14px;padding:18px;text-align:center;margin:12px 0}.mg-upload input{display:none}.mg-upload span{display:block;font-weight:900;color:var(--mg-green);font-size:14px}.mg-upload small{display:block;color:var(--mg-muted);font-size:11px;margin-top:5px;direction:ltr}.mg-progress-text{font-size:12px;color:var(--mg-green);font-weight:800;line-height:1.5;margin-top:10px}.mg-release-list{display:grid;gap:8px;margin-top:12px}.mg-release{border:1px solid var(--mg-line);border-radius:11px;padding:10px 11px}.mg-release b,.mg-release span,.mg-release small{display:block}.mg-release span{font-size:10px;color:var(--mg-muted);margin-top:3px}.mg-release small{font-size:11px;margin-top:5px;color:#47534b;line-height:1.4}.mg-update-ready{position:fixed;z-index:1000;left:14px;right:14px;bottom:calc(14px + env(safe-area-inset-bottom));height:48px;border:0;border-radius:13px;background:#14532d;color:#fff;font-weight:900;box-shadow:0 10px 30px rgba(0,0,0,.2)}\n@media(max-width:520px){.mg-member{align-items:flex-start;flex-direction:column}.mg-member-actions{width:100%;justify-content:flex-start}.mg-calc-result strong{font-size:34px}}\n\n/* V2.1 tasks + notifications */\n.mg-notify-btn{position:relative;width:40px;height:40px;border-radius:11px;border:1px solid rgba(255,255,255,.24);background:rgba(255,255,255,.12);color:#fff;display:grid;place-items:center;font-size:19px}.mg-notify-btn span{position:absolute;top:-5px;right:-5px;min-width:18px;height:18px;padding:0 5px;border-radius:999px;background:#dc2626;color:#fff;font-size:10px;font-weight:900;line-height:18px}.mg-live-notification{position:fixed;z-index:1500;left:14px;right:14px;top:calc(14px + env(safe-area-inset-top));margin:auto;max-width:520px;border:1px solid #b9d5c2;background:#fff;border-radius:14px;padding:12px 14px;text-align:right;box-shadow:0 14px 38px rgba(0,0,0,.18);color:var(--mg-text)}.mg-live-notification b,.mg-live-notification span{display:block}.mg-live-notification span{font-size:12px;color:var(--mg-muted);margin-top:3px}.mg-notification-list{display:grid;gap:8px;margin-top:12px}.mg-notification-row{width:100%;display:flex;justify-content:space-between;gap:12px;align-items:flex-start;text-align:right;border:1px solid var(--mg-line);background:#fff;border-radius:12px;padding:11px;color:var(--mg-text)}.mg-notification-row.unread{background:#f1faf4;border-color:#b9d5c2}.mg-notification-row span{min-width:0}.mg-notification-row b,.mg-notification-row small{display:block}.mg-notification-row small{margin-top:4px;color:var(--mg-muted);line-height:1.4}.mg-notification-row time{font-size:10px;color:#7b857e;white-space:nowrap}.mg-tasks-list{display:grid;gap:10px;margin-top:12px}.mg-task{border:1px solid var(--mg-line);border-radius:14px;padding:13px;background:#fff}.mg-task.urgent{border-color:#f0b5ae;background:#fff9f8}.mg-task.completed{opacity:.72}.mg-task-top{display:flex;align-items:flex-start;justify-content:space-between;gap:10px}.mg-task h3{margin:5px 0 0;font-size:15px}.mg-task p{font-size:12px;line-height:1.55;color:var(--mg-muted);margin:9px 0}.mg-task-priority{font-size:10px;font-weight:900;color:var(--mg-green);background:#eef8f1;border-radius:999px;padding:4px 7px}.mg-task.urgent .mg-task-priority{color:#b42318;background:#fff0ee}.mg-task-done{font-size:11px;font-weight:900;color:var(--mg-green)}.mg-task-meta{display:flex;gap:6px;flex-wrap:wrap;margin-top:9px}.mg-task-meta span{font-size:10px;color:#536158;background:#f4f7f5;border-radius:8px;padding:5px 7px}.mg-task-actions{display:flex;gap:8px;align-items:center;margin-top:11px}.mg-task-actions .mg-primary,.mg-task-actions .mg-secondary{flex:1}.mg-field textarea{width:100%;border:1px solid #cfd8d2;border-radius:12px;padding:10px 12px;outline:none;background:#fff;resize:vertical;font:inherit}.mg-field textarea:focus{border-color:#70ad84;box-shadow:0 0 0 3px #e4f3e9}.mg-weekdays{display:flex;gap:6px;flex-wrap:wrap;margin:0 0 12px}.mg-weekdays label input{display:none}.mg-weekdays label span{width:38px;height:38px;border:1px solid var(--mg-line);border-radius:10px;display:grid;place-items:center;background:#fff;font-weight:900;font-size:12px}.mg-weekdays label input:checked+span{background:#166534;color:#fff;border-color:#166534}@media(max-width:520px){.mg-task-actions{align-items:stretch}.mg-notification-row{flex-direction:column}.mg-notification-row time{white-space:normal}}\n.mg-task.overdue{border-color:#efb8b0}.mg-task-done.overdue{color:#b42318}.mg-task-done.working{color:#9a6700}\n\n\n/* V2.2 suppliers + orders */\n.mg-supplier-grid{display:grid;gap:9px;margin-top:12px}.mg-supplier-card{width:100%;border:1px solid var(--mg-line);border-radius:14px;background:#fff;padding:13px;display:flex;align-items:center;justify-content:space-between;gap:12px;text-align:right;color:var(--mg-text)}.mg-supplier-card>div{display:grid;grid-template-columns:42px 1fr;grid-template-rows:auto auto;column-gap:10px;align-items:center}.mg-supplier-icon{grid-row:1/3;width:42px;height:42px;border-radius:12px;background:#edf8f0;display:grid;place-items:center;font-size:21px}.mg-supplier-card b{font-size:15px}.mg-supplier-card small{color:var(--mg-muted);font-size:11px;margin-top:2px}.mg-supplier-card strong{color:var(--mg-green);font-size:12px;white-space:nowrap}.mg-supplier-card.inactive{opacity:.58}.mg-order-toolbar{display:flex;gap:8px;align-items:center;margin-bottom:10px}.mg-search-wrap{height:46px;border:1px solid var(--mg-line);background:#fff;border-radius:12px;display:flex;align-items:center;gap:8px;padding:0 12px;flex:1}.mg-search-wrap input{border:0;outline:0;width:100%;font:inherit;background:transparent}.mg-order-toolbar>.mg-secondary{height:46px;white-space:nowrap}.mg-order-help{display:flex;gap:8px;align-items:flex-start}.mg-order-help b{white-space:nowrap;color:var(--mg-green)}.mg-order-help span{font-size:12px;line-height:1.5;color:var(--mg-muted)}.mg-product-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;padding-bottom:92px}.mg-product-card{position:relative;border:1px solid var(--mg-line);border-radius:14px;background:#fff;min-height:82px;overflow:hidden;transition:.12s}.mg-product-card.selected{border-color:#73ad84;background:#f2faf4;box-shadow:0 0 0 2px rgba(22,101,52,.06)}.mg-product-add{width:100%;height:100%;min-height:82px;border:0;background:transparent;padding:13px;text-align:right;font-weight:900;color:var(--mg-text);display:flex;align-items:center;justify-content:space-between;gap:8px}.mg-product-add span{line-height:1.35}.mg-product-add b{min-width:28px;height:28px;border-radius:999px;background:var(--mg-green);color:#fff;display:grid;place-items:center;font-size:13px}.mg-product-minus{position:absolute;left:7px;bottom:7px;width:28px;height:28px;border-radius:9px;border:1px solid #cbd7cf;background:#fff;color:#5b675f;font-size:18px;font-weight:900;line-height:1}.mg-order-dock{position:fixed;z-index:500;left:12px;right:12px;bottom:calc(12px + env(safe-area-inset-bottom));max-width:796px;margin:auto;border:1px solid #b6d1bf;background:#fff;border-radius:16px;padding:10px;box-shadow:0 12px 34px rgba(0,0,0,.16);display:flex;align-items:center;gap:12px}.mg-order-dock[hidden]{display:none}.mg-order-dock>div{min-width:92px}.mg-order-dock b,.mg-order-dock small{display:block}.mg-order-dock b{font-size:13px}.mg-order-dock small{font-size:10px;color:var(--mg-muted);margin-top:2px}.mg-order-dock .mg-primary{flex:1;height:44px}.mg-final-order{border-top:1px solid var(--mg-line);margin-top:12px}.mg-final-order>div{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:11px 2px;border-bottom:1px solid #edf1ee}.mg-final-order span{font-weight:800}.mg-final-order span small{display:block;color:var(--mg-muted);font-size:10px;margin-top:3px;font-weight:600}.mg-final-order b{white-space:nowrap;direction:ltr}.mg-whatsapp-preview{margin:14px 0;background:#f5f7f5;border-radius:12px;padding:12px}.mg-whatsapp-preview>b{font-size:11px;color:var(--mg-muted)}.mg-whatsapp-preview pre{white-space:pre-wrap;direction:rtl;text-align:right;font:inherit;font-size:12px;line-height:1.6;margin:8px 0 0}.mg-whatsapp-btn{width:100%;height:50px;border:0;border-radius:13px;background:#128c4a;color:#fff;font-weight:900;font-size:14px}.mg-whatsapp-btn:disabled{opacity:.55}.mg-catalog-list{display:grid;gap:9px;margin-top:12px}.mg-catalog-row{border:1px solid var(--mg-line);border-radius:13px;padding:10px;background:#fff;display:grid;grid-template-columns:28px minmax(0,1fr);gap:8px}.mg-catalog-number{width:28px;height:28px;border-radius:9px;background:#eef8f1;color:var(--mg-green);display:grid;place-items:center;font-size:11px;font-weight:900}.mg-catalog-fields{min-width:0}.mg-catalog-fields>input,.mg-catalog-fields>div input{height:39px;border:1px solid #d5ddd8;border-radius:9px;padding:0 9px;width:100%;font:inherit;font-size:12px}.mg-catalog-fields>input{font-weight:900}.mg-catalog-fields>div{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:6px}.mg-catalog-actions{grid-column:1/-1;display:flex;gap:6px;justify-content:flex-end;flex-wrap:wrap}.mg-order-move{width:32px;height:31px;border-radius:8px;border:1px solid var(--mg-line);background:#fff;font-weight:900}.mg-order-move:disabled{opacity:.3}.mg-supplier-admin .mg-secondary{width:100%}\n@media(min-width:620px){.mg-product-grid{grid-template-columns:repeat(3,minmax(0,1fr))}.mg-catalog-row{grid-template-columns:32px minmax(0,1fr) auto;align-items:start}.mg-catalog-actions{grid-column:auto;align-self:center}.mg-order-dock{left:calc(50% - 398px);right:auto;width:796px}}\n@media(max-width:430px){.mg-product-grid{grid-template-columns:1fr 1fr}.mg-order-toolbar{align-items:stretch;flex-direction:column}.mg-order-toolbar>.mg-secondary{width:100%}.mg-order-help{flex-direction:column}.mg-catalog-fields>div{grid-template-columns:1fr}}\n\n/* V2.2.1 supplier reminders + order history */\n.mg-order-edit-banner{display:flex;align-items:flex-start;gap:8px;flex-wrap:wrap;background:#fff8e8;border-color:#ecd59b}.mg-order-edit-banner>b{color:#7b5700}.mg-order-edit-banner>span{font-size:12px;line-height:1.5;color:#6e6250;flex:1;min-width:180px}.mg-order-edit-banner .mg-mini-btn{margin-inline-start:auto}\n.mg-reminder-list{display:grid;gap:8px;margin-top:12px}.mg-reminder-row{border:1px solid var(--mg-line);border-radius:12px;padding:10px 11px;background:#fff;display:flex;align-items:center;justify-content:space-between;gap:10px}.mg-reminder-row.inactive{opacity:.58}.mg-reminder-row span b,.mg-reminder-row span small{display:block}.mg-reminder-row span small{font-size:11px;color:var(--mg-muted);margin-top:3px}.mg-reminder-row>div{display:flex;gap:6px;flex-wrap:wrap}\n.mg-supplier-history{display:grid;gap:10px;margin-top:12px}.mg-order-history-row{border:1px solid var(--mg-line);border-radius:14px;padding:12px;background:#fff}.mg-order-history-head b,.mg-order-history-head small{display:block}.mg-order-history-head small{font-size:11px;color:var(--mg-muted);margin-top:4px}.mg-order-history-items{border-top:1px solid var(--mg-line);margin:10px 0}.mg-order-history-items>div{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:8px 2px;border-bottom:1px solid #edf1ee;font-size:12px}.mg-order-history-items span{font-weight:800}.mg-order-history-items span small{display:block;font-size:10px;color:var(--mg-muted);margin-top:2px;font-weight:600}.mg-order-history-items b{direction:ltr;white-space:nowrap}\n@media(max-width:520px){.mg-reminder-row{align-items:flex-start;flex-direction:column}.mg-reminder-row>div{width:100%}.mg-order-edit-banner .mg-mini-btn{margin-inline-start:0}.mg-order-toolbar{gap:6px}.mg-order-toolbar>.mg-secondary{width:auto;flex:1}}\n\n/* V2.2.2 — self profile, module permissions and supplier drafts */\n.mg-avatar-button{border:0;cursor:pointer;font:inherit;padding:0}\n.mg-avatar-button:hover{transform:translateY(-1px)}\n.mg-permissions-table{display:grid;gap:8px;margin:18px 0;overflow-x:auto}\n.mg-permissions-row{display:grid;grid-template-columns:minmax(190px,1.5fr) repeat(3,minmax(115px,1fr));gap:8px;align-items:center;padding:12px;border:1px solid var(--mg-border,#e8e8eb);border-radius:14px;background:#fff;min-width:650px}\n.mg-permissions-row.head{background:#f7f7f8;font-size:13px}\n.mg-permission-toggle{display:flex;align-items:center;justify-content:center;gap:7px;cursor:pointer;font-size:13px;font-weight:700}\n.mg-permission-toggle input{width:18px;height:18px;accent-color:#111}\n.mg-info-card{background:#f8fafc}\n.mg-order-final-actions{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:16px}\n.mg-order-history-row.draft{border:1px dashed #b7b7bd;background:#fbfbfc}\n@media(max-width:720px){.mg-order-final-actions{grid-template-columns:1fr}.mg-permissions-table{margin-inline:-4px}.mg-permissions-row{min-width:610px}}\n\n/* V2.3 — mobile overlay safety */\nhtml.mg-overlay-active,html.mg-overlay-active body{height:100%!important;overflow:hidden!important;overscroll-behavior:none;background:var(--mg-bg)!important}\n#managementRoot{width:100vw!important;height:100dvh!important;min-height:100dvh!important;max-height:100dvh!important;box-sizing:border-box!important;overscroll-behavior:contain;isolation:isolate;transform:translateZ(0);-webkit-overflow-scrolling:touch}\n#managementRoot:not(.hidden){display:block!important;background:var(--mg-bg)!important}\n#managementRoot .mg-shell{min-height:100dvh;background:var(--mg-bg)}\n@supports not (height:100dvh){#managementRoot,#managementRoot .mg-shell{height:100vh!important;min-height:100vh!important;max-height:100vh!important}}\n@media(max-width:620px){#managementRoot{inset:0!important}.mg-main{min-height:calc(100dvh - 90px);background:var(--mg-bg)}.mg-product-grid{padding-bottom:118px}.mg-order-dock{left:max(8px,env(safe-area-inset-left));right:max(8px,env(safe-area-inset-right));bottom:max(8px,env(safe-area-inset-bottom));width:auto;max-width:none}.mg-order-dock>div{min-width:74px}.mg-order-dock .mg-primary{min-width:0}}\n\n/* V2.3 — signage module */\n.mg-sign-type-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-top:12px}.mg-sign-type{border:1px solid var(--mg-line);border-radius:13px;background:#fff;padding:12px;text-align:right;color:var(--mg-text)}.mg-sign-type small,.mg-sign-type b{display:block}.mg-sign-type small{font-size:10px;color:var(--mg-muted);margin-bottom:4px}.mg-sign-type b{font-size:13px}.mg-sign-type.active{border-color:#79ad88;background:#f1faf4;box-shadow:0 0 0 2px rgba(22,101,52,.05)}.mg-sign-actions{display:grid;grid-template-columns:1fr 1fr;gap:9px;margin-top:14px}.mg-print-cal{border-top:1px solid var(--mg-line);margin-top:12px;padding-top:12px}.mg-print-cal summary{cursor:pointer;font-weight:900;font-size:12px;color:var(--mg-green)}.mg-print-cal>p{font-size:11px;color:var(--mg-muted);line-height:1.5}.mg-signage-preview-wrap{height:470px;overflow:auto;background:#dfe3e0;border-radius:14px;padding:12px;display:flex;justify-content:center;align-items:flex-start}.signage-preview-paper{transform:scale(.48);transform-origin:top center;flex:0 0 210mm;margin-bottom:-154mm;box-shadow:0 8px 30px rgba(0,0,0,.2)}\n@media(max-width:520px){.mg-sign-type-grid{grid-template-columns:1fr}.mg-sign-actions{grid-template-columns:1fr}.mg-signage-preview-wrap{height:390px}.signage-preview-paper{transform:scale(.36);margin-bottom:-190mm}}\n\n#signagePrintRoot{display:none}.signage-paper{position:relative;width:210mm;height:297mm;background:#fff;overflow:hidden;color:#000;direction:rtl;font-family:Arial,\"Arial Hebrew\",sans-serif;font-weight:900;box-sizing:border-box}.signage-layout{position:absolute;transform:translate(var(--sign-x,0mm),var(--sign-y,0mm));transform-origin:top right}.signage-layout>div{position:absolute;box-sizing:border-box}.sign-company,.sign-product{text-align:center;white-space:normal;overflow:hidden}.sign-price{direction:ltr;text-align:center;white-space:nowrap;font-style:italic}.sign-price-major{font-weight:900;letter-spacing:-2px}.sign-price-minor{font-weight:900;vertical-align:top}.sign-shekel{font-style:normal;font-weight:900}.sign-before,.sign-notes{font-weight:900;line-height:1.08}.sign-barcode-wrap{display:flex;justify-content:center;align-items:flex-end}.sign-barcode{width:100%;height:100%;overflow:visible}.sign-barcode-fallback{font-size:4mm;letter-spacing:.6mm;border-top:1px solid #000;border-bottom:1px solid #000;padding:1.5mm;text-align:center;direction:ltr}.sign-origin{text-align:center;font-weight:900}.sign-unit{font-style:normal;font-weight:900;display:inline-block;margin-left:1.5mm}\n\n/* V2.3.4 — Word-faithful signage output. Only variable content is printed. */\n.signage-paper{position:relative;width:210mm;height:297mm;background:#fff;overflow:hidden;color:#000;direction:rtl;font-family:Tahoma,\"Arial Hebrew\",Arial,sans-serif;font-weight:900;box-sizing:border-box}\n.signage-layout{position:absolute;left:0;top:0;width:210mm;height:297mm;transform:translate(var(--sign-x,0mm),var(--sign-y,0mm));transform-origin:top left}\n.signage-layout>div{position:absolute;box-sizing:border-box;color:#000}\n.sign-fit-single{white-space:nowrap!important;overflow:hidden!important;text-overflow:clip!important;line-height:1!important}\n.sign-fit-wrap{overflow:hidden!important}\n.sign-company,.sign-product,.sign-origin{text-align:center}\n.sign-price{direction:ltr;text-align:center;white-space:nowrap;display:flex;align-items:flex-start;justify-content:center;overflow:visible}\n.sign-price-content{display:inline-flex;align-items:flex-start;justify-content:center;transform-origin:center top}\n.sign-price-major{font-family:Tahoma,Arial,sans-serif;font-weight:900;font-style:italic;letter-spacing:-1.2mm;line-height:.86}\n.sign-price-side{display:flex;flex-direction:column;align-items:center;justify-content:flex-start;line-height:.86;margin-left:1.2mm;padding-top:.5mm}\n.sign-price-minor{font-family:Tahoma,Arial,sans-serif;font-weight:900;font-style:italic;line-height:.82}\n.sign-shekel{font-style:normal;font-weight:900;line-height:.9;margin-top:.7mm}\n.sign-before,.sign-notes{font-weight:900;line-height:1.08}.sign-notes{text-align:center}\n.sign-qty{font-weight:900;text-align:center;direction:rtl;white-space:nowrap}.sign-qty span{font-family:Tahoma,Arial,sans-serif;font-size:1.08em}\n.sign-barcode-wrap{display:flex;justify-content:center;align-items:flex-end}.sign-barcode{width:100%;height:100%;overflow:visible}.sign-barcode-fallback{font-size:3.5mm;letter-spacing:.4mm;border-top:.3mm solid #000;border-bottom:.3mm solid #000;padding:1mm;text-align:center;direction:ltr}.sign-unit{font-style:normal;font-weight:900;display:block;line-height:.95;margin-top:.6mm}\n\n/* מחיר רגיל קטן — coordinates taken from the Word A4 template. */\n.sign-small_regular .sign-company{left:55mm;top:5mm;width:40mm;height:13mm;font-size:11mm}\n.sign-small_regular .sign-product{left:18mm;top:17mm;width:115mm;height:17mm;font-size:13.5mm}\n.sign-small_regular .sign-price{left:42mm;top:33mm;width:66mm;height:31mm}.sign-small_regular .sign-price-major{font-size:31mm}.sign-small_regular .sign-price-minor{font-size:10.8mm}.sign-small_regular .sign-shekel{font-size:7.5mm}\n.sign-small_regular .sign-notes{left:20mm;top:63mm;width:112mm;height:10mm;font-size:4.6mm}.sign-small_regular .sign-barcode-wrap{left:50mm;top:74mm;width:52mm;height:13mm}\n\n/* מבצע קטן */\n.sign-small_sale .sign-company{left:58mm;top:12.5mm;width:38mm;height:6mm;font-size:4.8mm}\n.sign-small_sale .sign-product{left:18mm;top:19mm;width:148mm;height:14mm;font-size:12.5mm}\n.sign-small_sale .sign-price{left:43mm;top:35mm;width:62mm;height:28mm}.sign-small_sale .sign-price-major{font-size:29mm}.sign-small_sale .sign-price-minor{font-size:10.5mm}.sign-small_sale .sign-shekel{font-size:7mm}\n.sign-small_sale .sign-before{left:112mm;top:55mm;width:56mm;height:7mm;font-size:4.4mm;text-align:right}\n.sign-small_sale .sign-notes{left:40mm;top:62mm;width:101mm;height:10mm;font-size:4.2mm}.sign-small_sale .sign-barcode-wrap{left:116mm;top:72.5mm;width:45mm;height:11mm}\n\n/* מבצע כמות קטן */\n.sign-small_qty .sign-company{left:58mm;top:12.5mm;width:38mm;height:6mm;font-size:4.8mm}\n.sign-small_qty .sign-product{left:18mm;top:19mm;width:150mm;height:14mm;font-size:12.2mm}\n.sign-small_qty .sign-price{left:17mm;top:35mm;width:61mm;height:29mm}.sign-small_qty .sign-price-major{font-size:29mm}.sign-small_qty .sign-price-minor{font-size:10.5mm}.sign-small_qty .sign-shekel{font-size:7mm}\n.sign-small_qty .sign-qty{left:96mm;top:35mm;width:72mm;height:22mm;font-size:15.8mm}\n.sign-small_qty .sign-before{left:119mm;top:55.5mm;width:52mm;height:7mm;font-size:4.4mm;text-align:right}\n.sign-small_qty .sign-notes{left:40mm;top:62mm;width:101mm;height:10mm;font-size:4.2mm}.sign-small_qty .sign-barcode-wrap{left:119mm;top:72.5mm;width:45mm;height:11mm}\n\n/* מחיר רגיל גדול */\n.sign-large_regular .sign-company{left:0;top:7mm;width:176mm;height:20mm;font-size:17.5mm}\n.sign-large_regular .sign-product{left:0;top:32mm;width:176mm;height:21mm;font-size:17.2mm}\n.sign-large_regular .sign-price{left:25mm;top:54mm;width:96mm;height:50mm}.sign-large_regular .sign-price-major{font-size:49mm}.sign-large_regular .sign-price-minor{font-size:17mm}.sign-large_regular .sign-shekel{font-size:12mm}\n.sign-large_regular .sign-notes{left:16mm;top:105mm;width:150mm;height:13mm;font-size:5.6mm}.sign-large_regular .sign-barcode-wrap{left:57mm;top:120mm;width:62mm;height:16mm}\n\n/* מבצע גדול */\n.sign-large_sale .sign-company{left:112mm;top:13mm;width:51mm;height:16mm;font-size:13.5mm}\n.sign-large_sale .sign-product{left:0;top:30mm;width:175mm;height:19mm;font-size:15.5mm}\n.sign-large_sale .sign-price{left:14mm;top:45mm;width:101mm;height:41mm}.sign-large_sale .sign-price-major{font-size:44mm}.sign-large_sale .sign-price-minor{font-size:16mm}.sign-large_sale .sign-shekel{font-size:11mm}\n.sign-large_sale .sign-before{left:82mm;top:90mm;width:87mm;height:10mm;font-size:6.1mm;text-align:right}\n.sign-large_sale .sign-notes{left:14mm;top:101mm;width:154mm;height:13mm;font-size:5.3mm}.sign-large_sale .sign-barcode-wrap{left:58mm;top:116mm;width:60mm;height:16mm}\n\n/* מבצע כמות גדול */\n.sign-large_qty .sign-company{left:115mm;top:16.5mm;width:49mm;height:15mm;font-size:12.8mm}\n.sign-large_qty .sign-product{left:0;top:30mm;width:175mm;height:19mm;font-size:15.5mm}\n.sign-large_qty .sign-price{left:0;top:51.5mm;width:88mm;height:34mm}.sign-large_qty .sign-price-major{font-size:43mm}.sign-large_qty .sign-price-minor{font-size:15.5mm}.sign-large_qty .sign-shekel{font-size:10.5mm}\n.sign-large_qty .sign-qty{left:87mm;top:51.5mm;width:82mm;height:34mm;font-size:21mm}\n.sign-large_qty .sign-before{left:82mm;top:90mm;width:87mm;height:10mm;font-size:6.1mm;text-align:right}\n.sign-large_qty .sign-notes{left:14mm;top:101mm;width:154mm;height:13mm;font-size:5.3mm}.sign-large_qty .sign-barcode-wrap{left:58mm;top:116mm;width:60mm;height:16mm}\n\n/* בסטה — same Word placement for kg / unit, only the unit label changes. */\n.sign-basta .sign-product{left:35mm;top:10.5mm;width:78mm;height:19mm;font-size:18mm}\n.sign-basta .sign-origin{left:36mm;top:27.5mm;width:76mm;height:10mm;font-size:7mm}\n.sign-basta .sign-price{left:35mm;top:38.5mm;width:78mm;height:56mm}.sign-basta .sign-price-major{font-size:53mm}.sign-basta .sign-price-minor{font-size:17.5mm}.sign-basta .sign-shekel{font-size:10mm}.sign-basta .sign-unit{font-size:8mm}\n\nbody.signage-preparing #signagePrintRoot{display:block!important;position:fixed!important;left:-10000px!important;top:0!important;width:210mm!important;height:297mm!important;visibility:hidden!important;pointer-events:none!important}\n.mg-sign-cal-actions{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px}\n@media print{\n  @page{size:A4 portrait;margin:0}\n  html,body{width:210mm!important;height:297mm!important;margin:0!important;padding:0!important;background:#fff!important;overflow:hidden!important}\n  body.signage-printing>*:not(#signagePrintRoot){display:none!important}\n  body.signage-printing #signagePrintRoot{display:block!important;position:fixed!important;inset:0!important;width:210mm!important;height:297mm!important;margin:0!important;padding:0!important;background:#fff!important;z-index:2147483647!important}\n  body.signage-printing #signagePrintRoot .signage-paper{display:block!important;margin:0!important;box-shadow:none!important;transform:none!important}\n}\n\n/* V2.3 — shortage lists */\n.mg-shortage-add{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;margin-bottom:10px}.mg-shortage-add input{height:46px;border:1px solid #cfd8d2;border-radius:12px;padding:0 12px;font:inherit}.mg-shortage-composer{display:grid;gap:6px;margin:10px 0 13px}.mg-shortage-composer>div:not(.mg-empty){display:flex;align-items:center;justify-content:space-between;gap:10px;border:1px solid var(--mg-line);border-radius:11px;padding:9px 10px;background:#fff;font-size:12px;font-weight:800}.mg-shortage-list{display:grid;gap:8px;margin-top:12px}.mg-shortage-card{width:100%;border:1px solid var(--mg-line);border-radius:13px;background:#fff;padding:12px;text-align:right;display:flex;justify-content:space-between;align-items:center;gap:12px;color:var(--mg-text)}.mg-shortage-card>div b,.mg-shortage-card>div small,.mg-shortage-state{display:block}.mg-shortage-state{font-size:10px;color:var(--mg-green);font-weight:900;margin-bottom:4px}.mg-shortage-card small{font-size:10px;color:var(--mg-muted);margin-top:3px}.mg-shortage-card strong{font-size:11px;color:var(--mg-green);white-space:nowrap}.mg-shortage-card.ready{border-color:#9acaa7;background:#f4fbf6}.mg-shortage-card.working{border-color:#dfc27e;background:#fffaf0}.mg-shortage-work-list{display:grid;gap:8px;margin-top:14px}.mg-shortage-work-row{border:1px solid var(--mg-line);border-radius:12px;padding:10px;background:#fff;display:flex;align-items:center;justify-content:space-between;gap:10px}.mg-shortage-work-row>div:first-child b,.mg-shortage-work-row>div:first-child small{display:block}.mg-shortage-work-row>div:first-child small{font-size:10px;color:var(--mg-muted);margin-top:3px}.mg-shortage-work-row.fulfilled{border-color:#a8d4b4;background:#f4fbf6}.mg-shortage-work-row.missing{border-color:#efc0ba;background:#fff8f7}.mg-shortage-item-actions{display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end}.mg-shortage-item-actions .active{background:#eaf7ed;border-color:#8fbea0;color:var(--mg-green)}.mg-shortage-item-actions .danger.active{background:#fff0ee;border-color:#e3a69e;color:#a11b13}.mg-shortage-finish{margin-top:14px;padding-top:12px;border-top:1px solid var(--mg-line)}.mg-shortage-finish p{font-size:11px;color:var(--mg-muted);line-height:1.5}.mg-reorder-list{display:grid;gap:7px;margin-top:12px}.mg-reorder-row{border:1px solid #eccf94;background:#fffaf0;border-radius:11px;padding:10px;display:flex;align-items:center;justify-content:space-between;gap:10px}.mg-reorder-row span b,.mg-reorder-row span small{display:block}.mg-reorder-row span small{font-size:10px;color:#816b3d;margin-top:3px}\n@media(max-width:520px){.mg-shortage-add{grid-template-columns:1fr}.mg-shortage-work-row{align-items:flex-start;flex-direction:column}.mg-shortage-item-actions{width:100%;justify-content:flex-start}.mg-reorder-row{align-items:flex-start;flex-direction:column}.mg-reorder-row .mg-mini-btn{width:100%}}\n\n/* V2.3.2 — UI refresh + clearer navigation */\n:root{\n  --mg-green:#0f5132;--mg-green2:#176b43;--mg-ink:#162019;--mg-bg:#f5f5f1;\n  --mg-card:#ffffff;--mg-text:#17201b;--mg-muted:#6f786f;--mg-line:#e7e9e5;\n  --mg-soft:#eef5f0;--mg-soft2:#fafaf7;--mg-danger:#b42318;--mg-shadow:0 8px 28px rgba(24,39,30,.07)\n}\n#managementRoot{background:var(--mg-bg);overscroll-behavior:none}\n.mg-shell{min-height:100dvh;background:var(--mg-bg)}\n.mg-top{position:sticky;top:0;z-index:40;background:rgba(15,65,44,.96);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);padding:calc(10px + env(safe-area-inset-top)) 15px 10px;box-shadow:0 1px 0 rgba(255,255,255,.08)}\n.mg-top-in{max-width:1040px}.mg-top-page{padding-bottom:10px}\n.mg-brand{display:flex;align-items:center;gap:10px;min-width:0}.mg-brand-mark{width:38px;height:38px;border-radius:12px;background:#fff;color:var(--mg-green);display:grid;place-items:center;font-size:14px;font-weight:950;box-shadow:inset 0 0 0 1px rgba(15,81,50,.08);flex:0 0 auto}.mg-brand>div:last-child{min-width:0}.mg-brand strong{font-size:15px;line-height:1.2;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.mg-brand span{font-size:10px;margin-top:2px;opacity:.72}\n.mg-user{gap:7px}.mg-avatar{width:38px;height:38px;border-radius:12px;background:#f5fff8;color:#164f34;border:0}.mg-logout{height:38px;border-radius:11px;padding:0 10px}.mg-notify-btn{border-radius:11px}\n.mg-main{width:min(1040px,100%);padding:18px 16px 100px}.mg-dashboard{padding-top:18px}.mg-page-main{padding-top:14px}\n.mg-dashboard-hero{background:linear-gradient(135deg,#0f5132,#1c7049);border-radius:22px;padding:22px;color:#fff;display:flex;justify-content:space-between;align-items:flex-end;gap:20px;box-shadow:0 14px 36px rgba(15,81,50,.17);margin-bottom:12px;overflow:hidden;position:relative}.mg-dashboard-hero:after{content:\"\";position:absolute;width:190px;height:190px;border-radius:50%;background:rgba(255,255,255,.07);left:-55px;top:-85px}.mg-dashboard-hero>div{position:relative;z-index:1}.mg-eyebrow{display:block;font-size:11px;font-weight:900;opacity:.76;margin-bottom:5px}.mg-dashboard-hero h1{margin:0;font-size:27px;letter-spacing:-.4px}.mg-dashboard-hero p{margin:5px 0 0;font-size:13px;opacity:.82}.mg-hero-role{font-size:11px;font-weight:900;background:rgba(255,255,255,.13);border:1px solid rgba(255,255,255,.16);border-radius:999px;padding:8px 11px;white-space:nowrap}\n.mg-status{margin:0 0 14px;gap:7px}.mg-chip{background:#fff;border-color:#e5e8e4;box-shadow:0 2px 7px rgba(0,0,0,.025);padding:6px 9px;font-size:11px}.mg-chip.ok{background:#f4fbf6}\n.mg-dashboard-search{height:48px;background:#fff;border:1px solid var(--mg-line);border-radius:15px;display:flex;align-items:center;gap:9px;padding:0 13px;margin-bottom:22px;box-shadow:0 4px 16px rgba(24,39,30,.035)}.mg-dashboard-search span{font-size:22px;color:#7d877f;line-height:1}.mg-dashboard-search input{border:0;outline:0;background:transparent;width:100%;font:inherit;color:var(--mg-text);font-size:13px}.mg-dashboard-search input::placeholder{color:#9ba29d}\n.mg-dashboard-section{margin:0 0 24px}.mg-section-head{display:flex;align-items:end;justify-content:space-between;margin:0 2px 9px}.mg-section-head h2{font-size:16px;margin:0;color:#1c2720}.mg-section-head p{font-size:11px;color:var(--mg-muted);margin:3px 0 0}\n.mg-grid{grid-template-columns:1fr 1fr;gap:10px}.mg-card{position:relative;border-color:#e7e9e6;border-radius:17px;padding:14px 15px;box-shadow:0 3px 14px rgba(24,39,30,.035);display:flex;align-items:center;justify-content:space-between;gap:12px;min-height:90px;transition:transform .14s ease,box-shadow .14s ease,border-color .14s ease}.mg-card:hover{transform:translateY(-1px);border-color:#cfd9d2;box-shadow:var(--mg-shadow)}.mg-card-leading{display:flex;align-items:center;gap:13px;min-width:0}.mg-icon{width:46px;height:46px;border-radius:14px;background:var(--mg-soft);font-size:22px;flex:0 0 auto}.mg-card-copy{min-width:0;text-align:right}.mg-card-title-row{display:flex;align-items:center;gap:7px;flex-wrap:wrap}.mg-card h3{margin:0;font-size:14px}.mg-card p{margin:4px 0 0;font-size:11px;line-height:1.4;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.mg-badge{font-size:9px;padding:4px 7px;background:#f0f6f2}.mg-card-chevron{font-size:28px;font-weight:300;color:#a2aba4;line-height:1;flex:0 0 auto}.mg-card-head,.mg-arrow{display:none}\n.mg-panel-head{position:sticky;top:59px;z-index:30;background:rgba(245,245,241,.94);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);margin:-2px -4px 14px;padding:8px 4px 10px;justify-content:flex-start}.mg-page-title{display:flex;align-items:center;gap:8px;min-width:0}.mg-page-title>span{width:34px;height:34px;display:grid;place-items:center;border-radius:10px;background:#eaf3ed}.mg-page-title h2{font-size:18px;margin:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.mg-back{width:38px;padding:0;height:38px;border-radius:11px;font-size:18px;flex:0 0 auto}\n.mg-form-card{border-color:#e6e8e5;border-radius:18px;padding:16px;box-shadow:0 3px 16px rgba(24,39,30,.035);margin-bottom:12px}.mg-form-card h3{font-size:15px}.mg-field input,.mg-field select{height:48px;border-radius:13px;background:#fff}.mg-primary{height:48px;border-radius:13px;background:linear-gradient(135deg,#0f5132,#176b43);box-shadow:0 6px 15px rgba(15,81,50,.14)}.mg-secondary{border-radius:12px;background:#f0f6f2}.mg-mini-btn{border-radius:9px}\n.mg-shortage-card{border-radius:14px;padding:13px 14px;box-shadow:0 2px 10px rgba(24,39,30,.025)}.mg-shortage-work-row{border-radius:14px;padding:12px}.mg-reorder-row{border-radius:14px}.mg-shortage-composer>div:not(.mg-empty){border-radius:12px;padding:10px 11px}\n.mg-list-admin-actions{margin-top:16px;padding:14px;border-radius:15px;background:#fff8f7;border:1px solid #f0d7d2;display:flex;align-items:center;justify-content:space-between;gap:12px}.mg-list-admin-actions b,.mg-list-admin-actions small{display:block}.mg-list-admin-actions b{font-size:12px;color:#6f251e}.mg-list-admin-actions small{font-size:10px;color:#9b5a53;margin-top:3px;line-height:1.4}.mg-list-admin-buttons{display:flex;gap:7px;flex-wrap:wrap;justify-content:flex-end}.mg-list-admin-buttons .mg-secondary{height:38px}.mg-danger-btn{height:38px;border-radius:11px;border:1px solid #e8b7b0;background:#fff;color:#a11b13;font-weight:900;padding:0 12px}\n.mg-bottom-nav{display:none}\n@media(min-width:860px){.mg-grid{grid-template-columns:repeat(3,minmax(0,1fr))}.mg-dashboard-hero{padding:26px}.mg-dashboard-hero h1{font-size:30px}.mg-user-meta{display:block}}\n@media(max-width:619px){\n  .mg-top{padding-left:12px;padding-right:12px}.mg-user-meta,.mg-logout{display:none}.mg-brand strong{font-size:13px}.mg-brand span{display:none}.mg-brand-mark{width:36px;height:36px}.mg-main{padding:14px 12px 94px}.mg-dashboard{padding-top:12px}.mg-dashboard-hero{border-radius:18px;padding:18px 16px;align-items:flex-start;min-height:120px}.mg-dashboard-hero h1{font-size:24px}.mg-hero-role{font-size:10px;padding:6px 8px}.mg-dashboard-search{margin-bottom:19px}.mg-section-head{margin-bottom:8px}.mg-grid{grid-template-columns:1fr;gap:8px}.mg-card{min-height:76px;border-radius:15px;padding:12px}.mg-icon{width:42px;height:42px;border-radius:12px;font-size:20px}.mg-card h3{font-size:13px}.mg-card p{font-size:10.5px}.mg-panel-head{top:57px;margin-left:-2px;margin-right:-2px}.mg-form-card{padding:14px;border-radius:16px}.mg-list-admin-actions{align-items:flex-start;flex-direction:column}.mg-list-admin-buttons{width:100%}.mg-list-admin-buttons>*{flex:1}.mg-bottom-nav{position:fixed;z-index:80;display:grid;grid-template-columns:repeat(3,1fr);left:10px;right:10px;bottom:calc(8px + env(safe-area-inset-bottom));height:62px;background:rgba(255,255,255,.96);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);border:1px solid rgba(215,220,216,.9);border-radius:18px;box-shadow:0 12px 32px rgba(23,32,27,.16);padding:5px}.mg-bottom-nav button{position:relative;border:0;background:transparent;border-radius:13px;color:#788079;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;font:inherit}.mg-bottom-nav button>span{font-size:18px;line-height:1}.mg-bottom-nav button>b{font-size:9px}.mg-bottom-nav button.active{background:#edf5ef;color:var(--mg-green)}.mg-bottom-nav button>i{position:absolute;top:4px;right:calc(50% - 18px);min-width:15px;height:15px;padding:0 4px;border-radius:999px;background:#d92d20;color:#fff;font-size:8px;font-style:normal;display:grid;place-items:center}.mg-bottom-nav button>i[hidden]{display:none}}\n\n\n/* V2.3.3 — shortage catalog, reorder export/print, stable mobile nav */\n#managementRoot{transform:none!important;-webkit-transform:none!important}\n.mg-catalog-status{display:flex;align-items:center;gap:7px;flex-wrap:wrap;padding:9px 11px;margin:10px 0 12px;border-radius:12px;background:#f2f7f3;border:1px solid #dfe9e2;color:#365140}.mg-catalog-status span{font-size:10px;font-weight:900}.mg-catalog-status b{font-size:11px;color:var(--mg-green)}.mg-catalog-status small{font-size:9.5px;color:var(--mg-muted);width:100%}\n.mg-catalog-manager summary{list-style:none;cursor:pointer;display:flex;align-items:center;justify-content:space-between;gap:10px}.mg-catalog-manager summary::-webkit-details-marker{display:none}.mg-catalog-manager summary span b,.mg-catalog-manager summary span small{display:block}.mg-catalog-manager summary span b{font-size:14px}.mg-catalog-manager summary span small{font-size:10px;color:var(--mg-muted);margin-top:3px}.mg-catalog-manager summary strong{font-size:11px;color:var(--mg-green)}.mg-catalog-manager-body{padding-top:14px;margin-top:12px;border-top:1px solid var(--mg-line)}.mg-shortage-catalog-list{display:grid;gap:7px}.mg-shortage-catalog-row{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center;gap:8px;border:1px solid var(--mg-line);border-radius:11px;padding:8px;background:#fff}.mg-shortage-catalog-row input{height:39px;border:1px solid #d8ded9;border-radius:9px;padding:0 10px;font:inherit;font-size:12px}.mg-shortage-catalog-row>div{display:flex;gap:5px}\n.mg-reorder-toolbar{display:flex;gap:7px;margin:10px 0}.mg-reorder-toolbar .mg-secondary{height:40px}.mg-reorder-row>span{min-width:0;flex:1}.mg-reorder-name-input{width:100%;height:38px;border:1px solid #e2c98f;border-radius:9px;background:#fff;padding:0 9px;font:inherit;font-weight:800;font-size:12px;color:var(--mg-text)}.mg-reorder-actions{display:flex;gap:5px;flex-wrap:wrap}\n#reorderPrintRoot{display:none}\n@media print{\n  body.reorder-printing>*:not(#reorderPrintRoot){display:none!important}\n  body.reorder-printing #reorderPrintRoot{display:block!important;position:static!important;background:#fff!important;color:#000!important}\n  .reorder-print-sheet{font-family:Arial,sans-serif;padding:12mm;direction:rtl;color:#000}.reorder-print-sheet h1{font-size:20pt;margin:0 0 2mm}.reorder-print-sheet h2{font-size:16pt;margin:0 0 2mm}.reorder-print-sheet p{font-size:9pt;margin:0 0 6mm}.reorder-print-sheet ol{margin:0;padding-right:8mm}.reorder-print-sheet li{font-size:14pt;font-weight:700;padding:2.5mm 0;border-bottom:.2mm solid #bbb}\n}\n@media(max-width:619px){\n  body>.mg-bottom-nav{position:fixed!important;z-index:500!important;left:10px!important;right:10px!important;bottom:max(8px,env(safe-area-inset-bottom))!important;top:auto!important;transform:none!important;-webkit-transform:none!important;margin:0!important}\n  .mg-shortage-catalog-row{grid-template-columns:1fr}.mg-shortage-catalog-row>div{justify-content:flex-end}\n  .mg-reorder-toolbar{display:grid;grid-template-columns:1fr 1fr}.mg-reorder-row{align-items:stretch!important}.mg-reorder-actions{width:100%}.mg-reorder-actions .mg-mini-btn{flex:1}\n}\n\n/* V2.3.4 — do not let iOS virtual keyboard push the bottom nav into the middle of the screen. */\n@media(max-width:619px){body>.mg-bottom-nav.mg-keyboard-open{display:none!important}.mg-bottom-nav{position:fixed!important;top:auto!important;bottom:max(8px,env(safe-area-inset-bottom))!important;transform:none!important;translate:none!important}}\n\n/* V2.3.5 — signage defaults + per-element editor */\n.sign-adjustable{transform:translate(var(--el-x,0mm),var(--el-y,0mm)) scale(var(--el-scale,1));transform-origin:center center}\n.sign-adjustable-inner{transform:translate(var(--el-x,0mm),var(--el-y,0mm)) scale(var(--el-scale,1));transform-origin:center top}\n.sign-price-side{margin-left:3.2mm}\n.signage-preview-paper .sign-editor-highlight{outline:1.2mm dashed rgba(15,81,50,.72);outline-offset:1mm;background:rgba(15,81,50,.035)}\n.signage-preview-paper .sign-price-side.sign-editor-highlight{outline-width:.8mm;outline-offset:.5mm}\n.mg-sign-editor{margin-top:14px;padding:13px;border:1px solid #dfe8e1;border-radius:14px;background:#f7faf8}.mg-sign-editor h4{margin:0 0 10px;font-size:13px;color:var(--mg-green)}.mg-sign-editor-values{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}.mg-sign-nudges{display:grid;grid-template-columns:repeat(4,1fr);gap:7px;margin-top:9px}.mg-sign-nudges .mg-secondary{height:40px;padding:0 7px}.mg-sign-editor-actions{display:flex;gap:7px;margin-top:9px}.mg-sign-editor-actions .mg-secondary{height:40px}.mg-sign-editor>small{display:block;margin-top:9px;color:var(--mg-muted);font-size:10px;line-height:1.5}\n@media(max-width:619px){.mg-sign-editor-values{grid-template-columns:1fr}.mg-sign-nudges{grid-template-columns:1fr 1fr}.mg-sign-editor-actions{display:grid;grid-template-columns:1fr}}\n\n/* Requested physical-print refinements. Global X default is +20mm in JS/DB. */\n.sign-small_sale .sign-company{left:126mm;top:11.5mm;width:36mm;height:7mm;font-size:6.2mm;text-align:right}\n.sign-small_sale .sign-price{left:58mm;top:35mm;width:64mm;height:28mm}\n.sign-small_sale .sign-before{left:104mm;top:55mm;width:56mm;height:7mm}\n\n.sign-small_qty .sign-company{left:126mm;top:11.5mm;width:36mm;height:7mm;font-size:6.2mm;text-align:right}\n.sign-small_qty .sign-price{left:50mm;top:35mm;width:63mm;height:29mm}\n.sign-small_qty .sign-before{left:108mm;top:55.5mm;width:52mm;height:7mm}\n\n.sign-large_regular .sign-company{font-size:18.5mm}\n.sign-large_regular .sign-product{font-size:18.4mm}\n.sign-large_regular .sign-price-major{font-size:52mm}.sign-large_regular .sign-price-minor{font-size:18mm}.sign-large_regular .sign-shekel{font-size:12.5mm}\n\n.sign-large_sale .sign-company{left:125mm;top:12mm;width:40mm;height:16mm;font-size:14.2mm;text-align:right}\n.sign-large_sale .sign-price{left:33mm;top:45mm;width:103mm;height:41mm}\n\n.sign-large_qty .sign-company{left:125mm;top:15mm;width:40mm;height:15mm;font-size:13.7mm;text-align:right}\n\n.sign-basta .sign-product{left:43mm;top:10mm;width:82mm;height:20mm;font-size:19.5mm}\n.sign-basta .sign-origin{left:44mm;top:27mm;width:80mm;height:10mm;font-size:7.6mm}\n.sign-basta .sign-price{left:43mm;top:38mm;width:82mm;height:58mm}.sign-basta .sign-price-major{font-size:57mm}.sign-basta .sign-price-minor{font-size:19mm}.sign-basta .sign-shekel{font-size:11mm}.sign-basta .sign-unit{font-size:8.7mm}\n.signage-paper,.signage-paper *{font-weight:900!important}\n";

  function printSignageLegacy(type,data){
    document.getElementById('signagePrintRoot')?.remove();
    const wrap=document.createElement('div');wrap.id='signagePrintRoot';wrap.innerHTML=buildSignageMarkup(type,data,false);document.body.appendChild(wrap);
    document.body.classList.add('signage-preparing');
    requestAnimationFrame(()=>requestAnimationFrame(()=>{
      fitSignageText(wrap);
      document.body.classList.remove('signage-preparing');
      document.body.classList.add('signage-printing');
      const cleanup=()=>{document.body.classList.remove('signage-printing');document.body.classList.remove('signage-preparing');setTimeout(()=>document.getElementById('signagePrintRoot')?.remove(),300);};
      window.addEventListener('afterprint',cleanup,{once:true});
      setTimeout(()=>window.print(),60);
      setTimeout(()=>{if(document.body.classList.contains('signage-printing'))cleanup();},7000);
    }));
  }

  function printSignage(type,data){
    // V2.8.0: Android standalone PWAs can block/lose print from a popup window.
    // In installed Android mode print from the current document; iOS keeps the isolated flow.
    const isAndroid=/Android/i.test(navigator.userAgent||'');
    const isStandalone=window.matchMedia?.('(display-mode: standalone)')?.matches||navigator.standalone===true;
    if(isAndroid&&isStandalone){printSignageLegacy(type,data);return;}
    // V2.3.7: iOS print must be self-contained. Do not rely on an external stylesheet,
    // because Safari can create the print snapshot before the linked CSS is applied.
    const printWindow=window.open('','_blank');
    if(!printWindow){ printSignageLegacy(type,data); return; }
    const markup=buildSignageMarkup(type,data,false);
    const title=`שילוט - ${type.label||''}`;
    const isolatedOverrides=`
      html,body{margin:0!important;padding:0!important;background:#fff!important;width:210mm!important;height:297mm!important;min-height:297mm!important;overflow:hidden!important}
      body{position:relative!important}
      #signagePrintRoot{display:block!important;position:absolute!important;inset:0!important;width:210mm!important;height:297mm!important;margin:0!important;padding:0!important;background:#fff!important;overflow:hidden!important}
      #signagePrintRoot .signage-paper{display:block!important;position:relative!important;width:210mm!important;height:297mm!important;margin:0!important;padding:0!important;box-shadow:none!important;transform:none!important;background:#fff!important;overflow:hidden!important}
      .sign-print-controls{position:fixed;z-index:999999;left:12px;right:12px;bottom:calc(12px + env(safe-area-inset-bottom));display:grid;grid-template-columns:1fr 1fr;gap:8px}.sign-print-help,.sign-print-back{min-height:48px;padding:10px 12px;border-radius:12px;font:700 15px Arial,sans-serif;box-shadow:0 4px 20px rgba(0,0,0,.16)}.sign-print-help{border:0;background:#0f5132;color:#fff}.sign-print-back{border:1px solid #d7ddd9;background:#fff;color:#253229}
      @page{size:A4 portrait;margin:0}
      @media print{
        html,body,#signagePrintRoot,#signagePrintRoot .signage-paper{width:210mm!important;height:297mm!important;margin:0!important;padding:0!important;overflow:hidden!important}
        .sign-print-controls{display:none!important}
      }
    `;
    try{
      printWindow.document.open();
      printWindow.document.write(`<!doctype html><html lang="he" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1"><title>${esc(title)}</title><style>${SIGNAGE_PRINT_CSS}</style><style>${isolatedOverrides}</style></head><body><div id="signagePrintRoot">${markup}</div><div class="sign-print-controls"><button class="sign-print-back" type="button">חזרה למערכת</button><button class="sign-print-help" type="button">הדפס את השלט</button></div></body></html>`);
      printWindow.document.close();
    }catch(_e){
      try{printWindow.close();}catch(__e){}
      printSignageLegacy(type,data);
      return;
    }

    const returnToApp=()=>{
      try{window.focus();}catch(_e){}
      try{if(!printWindow.closed)printWindow.close();}catch(_e){}
    };
    try{printWindow.addEventListener('afterprint',()=>setTimeout(returnToApp,180));}catch(_e){}
    try{const mq=printWindow.matchMedia?.('print');mq?.addEventListener?.('change',e=>{if(!e.matches)setTimeout(returnToApp,180);});}catch(_e){}
    let ready=false;
    const prepare=async()=>{
      if(ready||printWindow.closed)return;
      ready=true;
      try{
        // Give iOS one layout cycle, then wait for any available fonts before fitting text.
        await new Promise(r=>printWindow.requestAnimationFrame(()=>printWindow.requestAnimationFrame(r)));
        if(printWindow.document.fonts?.ready){
          try{await Promise.race([printWindow.document.fonts.ready,new Promise(r=>setTimeout(r,600))]);}catch(_e){}
        }
        fitSignageText(printWindow.document);
        await new Promise(r=>printWindow.requestAnimationFrame(()=>printWindow.requestAnimationFrame(r)));
        printWindow.focus();
        setTimeout(()=>{try{printWindow.print();}catch(_e){}},120);
      }catch(_e){}
    };
    const manual=printWindow.document.querySelector('.sign-print-help');
    const back=printWindow.document.querySelector('.sign-print-back');
    if(manual)manual.addEventListener('click',()=>{try{fitSignageText(printWindow.document);printWindow.print();}catch(_e){}});
    if(back)back.addEventListener('click',returnToApp);
    if(printWindow.document.readyState==='complete')prepare();
    else printWindow.addEventListener('load',prepare,{once:true});
    // Fallback only after the self-contained document has existed long enough to layout.
    setTimeout(prepare,900);
  }

  function shortageStatusLabel(s){return s==='draft'?'טיוטה':s==='sent'?'נשלחה לעובד':s==='working'?'בטיפול':s==='ready'?'מוכנה לאיסוף':s==='closed'?'נסגרה':'בוטלה';}
  function shortageItemStatusLabel(s){return s==='fulfilled'?'הוצא מהמחסן ✓':s==='missing'?'לא נמצא במחסן':'ממתין';}
  function shortageCard(l,memberMap){const meAssigned=l.assigned_user_id===session.user.id;return `<button class="mg-shortage-card ${esc(l.status)}" data-shortage-open="${esc(l.id)}"><div><span class="mg-shortage-state">${esc(shortageStatusLabel(l.status))}</span><b>${esc(memberMap.get(l.assigned_user_id)||'עובד')}</b><small>${esc(formatDateTime(l.created_at))}${l.created_by===session.user.id?' • אני יצרתי':''}</small></div><strong>${meAssigned&&['sent','working'].includes(l.status)?'לטיפול ←':'צפייה ←'}</strong></button>`;}

  async function renderShortages(){
    if(!requireModule('shortages'))return;
    const [{data:lists,error:listError},{data:members},{data:catalog},{data:reorder}]=await Promise.all([
      sb.from('shortage_lists').select('*').eq('business_id',profile.business_id).order('created_at',{ascending:false}).limit(60),
      sb.from('profiles').select('user_id,full_name,email,role,department,is_active').eq('business_id',profile.business_id).eq('is_active',true),
      sb.from('shortage_catalog').select('id,name,last_used_at').eq('business_id',profile.business_id).order('name',{ascending:true}).limit(1000),
      isManagement()?sb.from('shortage_reorder_items').select('*').eq('business_id',profile.business_id).eq('status','open').order('created_at',{ascending:true}):Promise.resolve({data:[]})
    ]);
    root.classList.remove('hidden');
    if(listError){root.innerHTML=`${shellHeader('רשימות חוסרים','📋')}<div class="mg-error show">${esc(listError.message)}</div></main></div>`;bindBack();return;}
    const memberMap=new Map((members||[]).map(m=>[m.user_id,m.full_name||m.email||'משתמש']));
    const workers=(members||[]).filter(m=>m.user_id!==session.user.id&&m.role!=='super_admin');
    const visible=(lists||[]).filter(l=>l.status!=='draft'||l.created_by===session.user.id||isManagement());

    const catalogManagerHtml=isManagement()?`<div class="mg-form-card"><details class="mg-catalog-manager"><summary><span><b>קטלוג חוסרים</b><small>${(catalog||[]).length} מוצרים שנשמרו מהקלדה ידנית</small></span><strong>ניהול קטלוג</strong></summary><div class="mg-catalog-manager-body"><div class="mg-shortage-add"><input id="mgCatalogNewName" placeholder="הוסף מוצר לקטלוג..."><button id="mgCatalogAdd" class="mg-secondary" type="button">הוסף</button></div><div class="mg-shortage-catalog-list">${(catalog||[]).length?(catalog||[]).map(c=>`<div class="mg-shortage-catalog-row" data-shortage-catalog-row="${esc(c.id)}"><input value="${esc(c.name)}" aria-label="שם מוצר"><div><button class="mg-mini-btn" data-shortage-catalog-save="${esc(c.id)}">שמור</button><button class="mg-mini-btn danger" data-shortage-catalog-delete="${esc(c.id)}">מחק</button></div></div>`).join(''):'<div class="mg-empty">הקטלוג עדיין ריק. מוצר חדש נשמר אוטומטית כששולחים רשימת חוסרים.</div>'}</div></div></details></div>`:'';

    const reorderHtml=isManagement()?`<div class="mg-form-card"><div class="mg-detail-head"><div><h3>צריך להזמין</h3><p>פריטים שלא נמצאו במחסן. אפשר לערוך לפני הדפסה/ייצוא.</p></div><span class="mg-badge">${(reorder||[]).length}</span></div><div class="mg-reorder-toolbar"><button id="mgPrintReorder" class="mg-secondary" ${!(reorder||[]).length?'disabled':''}>🖨️ הדפס</button><button id="mgExportReorder" class="mg-secondary" ${!(reorder||[]).length?'disabled':''}>⬇️ ייצוא CSV</button></div><div class="mg-reorder-list">${(reorder||[]).length?(reorder||[]).map(r=>`<div class="mg-reorder-row" data-reorder-row="${esc(r.id)}"><span><input class="mg-reorder-name-input" value="${esc(r.item_name)}" aria-label="שם מוצר"><small>${esc(formatDateTime(r.created_at))}</small></span><div class="mg-reorder-actions"><button class="mg-mini-btn" data-reorder-save="${esc(r.id)}">שמור</button><button class="mg-mini-btn" data-reorder-done="${esc(r.id)}">הוזמן</button><button class="mg-mini-btn danger" data-reorder-delete="${esc(r.id)}">הסר</button></div></div>`).join(''):'<div class="mg-empty">אין כרגע חוסרים שממתינים להזמנה.</div>'}</div></div>`:'';

    root.innerHTML=`${shellHeader('רשימות חוסרים','📋')}<div class="mg-form-card"><h3>רשימה חדשה למילוי החנות</h3><p>הוסף ידנית את מה שחסר ובחר מי יוציא את המוצרים מהמחסן.</p><div class="mg-catalog-status"><span>קטלוג חוסרים</span><b>${(catalog||[]).length} מוצרים</b><small>מוצר חדש נשמר בקטלוג מיד כשמוסיפים אותו לרשימה.</small></div><div class="mg-field"><label>שלח לעובד</label><select id="mgShortageAssignee"><option value="">בחר עובד</option>${workers.map(m=>`<option value="${esc(m.user_id)}">${esc(m.full_name||m.email)} — ${esc(roleLabel(m.role)+(m.department?' / '+deptLabel(m.department):''))}</option>`).join('')}</select></div><div class="mg-shortage-barcode"><input id="mgShortageBarcode" inputmode="numeric" autocomplete="off" placeholder="סרוק / הקלד ברקוד"><button id="mgLookupShortageBarcode" class="mg-secondary" type="button">זהה והוסף</button><button id="mgScanShortageBarcode" class="mg-secondary" type="button">📷 סרוק</button></div><div id="mgShortageBarcodeMsg" class="mg-progress-text"></div><div class="mg-shortage-add"><input id="mgShortageItemInput" list="mgShortageCatalog" placeholder="כתוב מוצר שחסר..."><datalist id="mgShortageCatalog">${(catalog||[]).map(c=>`<option value="${esc(c.name)}"></option>`).join('')}</datalist><button id="mgAddShortageItem" class="mg-secondary" type="button">הוסף</button></div><div id="mgShortageComposer" class="mg-shortage-composer"></div><button id="mgSendShortageList" class="mg-primary" disabled>שלח רשימה לעובד</button><div id="mgShortageCreateMsg" class="mg-progress-text"></div></div>${catalogManagerHtml}${reorderHtml}<div class="mg-form-card"><div class="mg-detail-head"><div><h3>רשימות פעילות והיסטוריה</h3><p>${visible.length} רשימות שניתן לראות בחשבון שלך.</p></div></div><div class="mg-shortage-list">${visible.length?visible.map(l=>shortageCard(l,memberMap)).join(''):'<div class="mg-empty">עדיין אין רשימות חוסרים.</div>'}</div></div></main></div>`;
    bindBack();renderShortageComposer();

    const addName=async(name,focusManual=true)=>{name=String(name||'').trim();if(!name)return;if(!shortageComposer.some(x=>x.toLocaleLowerCase('he')===name.toLocaleLowerCase('he')))shortageComposer.push(name);renderShortageComposer();const input=document.getElementById('mgShortageItemInput');if(focusManual&&input)input.focus();const status=document.querySelector('.mg-catalog-status small');if(status)status.textContent='שומר את המוצר בקטלוג…';const {error}=await sb.rpc('upsert_shortage_catalog_item',{p_name:name});if(status)status.textContent=error?'המוצר נוסף לרשימה, אבל לא נשמר בקטלוג: '+error.message:'נשמר בקטלוג ✓';};
    const add=async()=>{const input=document.getElementById('mgShortageItemInput');const name=input.value.trim();if(!name)return;input.value='';await addName(name,true);};
    const lookupShortage=async raw=>{const input=document.getElementById('mgShortageBarcode'),msg=document.getElementById('mgShortageBarcodeMsg'),btn=document.getElementById('mgLookupShortageBarcode');const barcode=normalizedBarcode(raw||input?.value);if(!barcode)return;if(input)input.value=barcode;if(btn)btn.disabled=true;if(msg)msg.textContent='מחפש בקובצי שקיפות המחירים…';try{const p=await lookupProductByBarcode(barcode);await addName(p.name||p.description,false);if(msg)msg.textContent=`נוסף לרשימה ✓ ${p.name||''} • ${p.source_label||'שקיפות מחירים'}`;}catch(e){if(msg)msg.textContent=e.message||String(e);}finally{if(btn)btn.disabled=false;}};
    document.getElementById('mgLookupShortageBarcode')?.addEventListener('click',()=>lookupShortage());
    document.getElementById('mgShortageBarcode')?.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();lookupShortage();}});
    document.getElementById('mgScanShortageBarcode')?.addEventListener('click',async()=>{try{await scanBarcodeLive(lookupShortage,document.getElementById('mgShortageBarcodeMsg'));}catch(e){const m=document.getElementById('mgShortageBarcodeMsg');if(m)m.textContent=e.message||String(e);}});
    document.getElementById('mgAddShortageItem').onclick=add;document.getElementById('mgShortageItemInput').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();add();}};
    document.getElementById('mgShortageAssignee').onchange=renderShortageComposer;document.getElementById('mgSendShortageList').onclick=createShortageList;
    document.querySelectorAll('[data-shortage-open]').forEach(b=>b.onclick=()=>renderShortageDetail(b.dataset.shortageOpen));

    document.getElementById('mgCatalogAdd')?.addEventListener('click',async()=>{
      const input=document.getElementById('mgCatalogNewName'),name=input?.value.trim();if(!name)return;
      const {error}=await sb.rpc('upsert_shortage_catalog_item',{p_name:name});
      if(error)alert('לא ניתן לשמור בקטלוג: '+error.message);else renderShortages();
    });
    document.querySelectorAll('[data-shortage-catalog-save]').forEach(b=>b.onclick=async()=>{
      const row=document.querySelector(`[data-shortage-catalog-row="${b.dataset.shortageCatalogSave}"]`),name=row?.querySelector('input')?.value.trim();if(!name)return;
      const {error}=await sb.from('shortage_catalog').update({name,name_key:name.toLocaleLowerCase('he').trim(),last_used_at:new Date().toISOString()}).eq('id',b.dataset.shortageCatalogSave).eq('business_id',profile.business_id);
      if(error)alert('לא ניתן לעדכן את המוצר: '+error.message);else renderShortages();
    });
    document.querySelectorAll('[data-shortage-catalog-delete]').forEach(b=>b.onclick=async()=>{
      if(!confirm('למחוק את המוצר מהקטלוג? רשימות ישנות לא ייפגעו.'))return;
      const {error}=await sb.from('shortage_catalog').delete().eq('id',b.dataset.shortageCatalogDelete).eq('business_id',profile.business_id);
      if(error)alert('לא ניתן למחוק מהקטלוג: '+error.message);else renderShortages();
    });

    document.querySelectorAll('[data-reorder-save]').forEach(b=>b.onclick=async()=>{
      const row=document.querySelector(`[data-reorder-row="${b.dataset.reorderSave}"]`),name=row?.querySelector('.mg-reorder-name-input')?.value.trim();if(!name)return;
      const {error}=await sb.from('shortage_reorder_items').update({item_name:name,updated_at:new Date().toISOString()}).eq('id',b.dataset.reorderSave).eq('business_id',profile.business_id);
      if(error)alert('לא ניתן לעדכן: '+error.message);else{b.textContent='נשמר ✓';setTimeout(()=>b.textContent='שמור',900);}
    });
    document.querySelectorAll('[data-reorder-done]').forEach(b=>b.onclick=async()=>{const {error}=await sb.from('shortage_reorder_items').update({status:'ordered',resolved_by:session.user.id,resolved_at:new Date().toISOString(),updated_at:new Date().toISOString()}).eq('id',b.dataset.reorderDone).eq('business_id',profile.business_id);if(error)alert(error.message);else renderShortages();});
    document.querySelectorAll('[data-reorder-delete]').forEach(b=>b.onclick=async()=>{
      if(!confirm('להסיר את הפריט מרשימת צריך להזמין?'))return;
      const {error}=await sb.from('shortage_reorder_items').delete().eq('id',b.dataset.reorderDelete).eq('business_id',profile.business_id);
      if(error)alert(error.message);else renderShortages();
    });
    document.getElementById('mgExportReorder')?.addEventListener('click',()=>exportReorderCsv(reorder||[]));
    document.getElementById('mgPrintReorder')?.addEventListener('click',()=>printReorderList(reorder||[]));
  }

  function exportReorderCsv(rows){
    if(!rows?.length)return;
    const q=v=>`"${String(v??'').replace(/"/g,'""')}"`;
    const lines=[['מוצר','נוסף בתאריך'].map(q).join(',')].concat(rows.map(r=>[r.item_name,formatDateTime(r.created_at)].map(q).join(',')));
    const blob=new Blob(['\ufeff'+lines.join('\r\n')],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');
    a.href=url;a.download=`חוסרים-להזמנה-${todayISO()}.csv`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);
  }

  function printReorderList(rows){
    if(!rows?.length)return;
    document.getElementById('reorderPrintRoot')?.remove();
    const el=document.createElement('div');el.id='reorderPrintRoot';el.innerHTML=`<div class="reorder-print-sheet" dir="rtl"><h1>אחים דוד יקנעם</h1><h2>רשימת חוסרים להזמנה</h2><p>${esc(new Intl.DateTimeFormat('he-IL',{dateStyle:'full',timeStyle:'short'}).format(new Date()))}</p><ol>${rows.map(r=>`<li>${esc(r.item_name)}</li>`).join('')}</ol></div>`;document.body.appendChild(el);
    document.body.classList.add('reorder-printing');
    const cleanup=()=>{document.body.classList.remove('reorder-printing');setTimeout(()=>document.getElementById('reorderPrintRoot')?.remove(),250);};
    window.addEventListener('afterprint',cleanup,{once:true});setTimeout(()=>window.print(),80);setTimeout(()=>{if(document.body.classList.contains('reorder-printing'))cleanup();},5000);
  }

  function renderShortageComposer(){
    const box=document.getElementById('mgShortageComposer');if(!box)return;box.innerHTML=shortageComposer.length?shortageComposer.map((x,i)=>`<div><span>${i+1}. ${esc(x)}</span><button type="button" class="mg-mini-btn danger" data-shortage-remove="${i}">הסר</button></div>`).join(''):'<div class="mg-empty">עוד לא הוספת פריטים.</div>';
    document.querySelectorAll('[data-shortage-remove]').forEach(b=>b.onclick=()=>{shortageComposer.splice(Number(b.dataset.shortageRemove),1);renderShortageComposer();});
    const send=document.getElementById('mgSendShortageList');if(send)send.disabled=!shortageComposer.length||!document.getElementById('mgShortageAssignee')?.value;
  }

  async function createShortageList(){
    const assigned=document.getElementById('mgShortageAssignee').value,msg=document.getElementById('mgShortageCreateMsg');if(!assigned||!shortageComposer.length)return;
    const btn=document.getElementById('mgSendShortageList');btn.disabled=true;msg.textContent='שומר ושולח את הרשימה…';
    try{
      // V2.3.1: creation is atomic on the server. The list, its items, catalog entries
      // and the in-app notification either all succeed together or nothing is saved.
      const {data,error}=await sb.rpc('create_and_send_shortage_list',{
        p_assigned_user_id:assigned,
        p_items:shortageComposer
      });
      if(error)throw error;
      const listId=data?.list_id||data?.id||data;
      if(!listId)throw new Error('לא התקבל מזהה רשימה מהשרת');
      msg.textContent='הרשימה נשמרה ונשלחה בהצלחה ✓';
      // Push is best-effort; the in-app notification was already created atomically in SQL.
      try{await sb.functions.invoke('task-push',{body:{action:'shortage',shortage_list_id:listId}});}catch(_e){}
      shortageComposer=[];
      setTimeout(()=>renderShortages(),350);
    }catch(err){
      console.error('createShortageList failed',err);
      msg.textContent='לא ניתן לשמור ולשלוח את הרשימה: '+(err?.message||String(err));
      btn.disabled=false;
    }
  }

  async function renderShortageDetail(listId){
    if(!requireModule('shortages'))return;
    const [{data:list,error:listError},{data:items,error:itemError},{data:members}]=await Promise.all([
      sb.from('shortage_lists').select('*').eq('business_id',profile.business_id).eq('id',listId).single(),
      sb.from('shortage_items').select('*').eq('business_id',profile.business_id).eq('list_id',listId).order('sort_order',{ascending:true}),
      sb.from('profiles').select('user_id,full_name,email').eq('business_id',profile.business_id)
    ]);if(listError||itemError){alert((listError||itemError).message);return renderShortages();}
    const names=new Map((members||[]).map(m=>[m.user_id,m.full_name||m.email||'משתמש']));const mine=list.assigned_user_id===session.user.id,editable=mine&&['sent','working'].includes(list.status);
    root.classList.remove('hidden');
    const managementActions=isManagement()?`<div class="mg-list-admin-actions"><div><b>ניהול הרשימה</b><small>איפוס מחזיר את כל הפריטים למצב ממתין. מחיקה היא סופית.</small></div><div class="mg-list-admin-buttons"><button id="mgResetShortage" class="mg-secondary">↻ אפס רשימה</button><button id="mgDeleteShortage" class="mg-danger-btn">מחק רשימה</button></div></div>`:'';
    root.innerHTML=`${shellHeader('רשימת חוסרים','📋')}<div class="mg-form-card"><div class="mg-detail-head"><div><h3>${esc(shortageStatusLabel(list.status))}</h3><p>נוצרה ע״י ${esc(names.get(list.created_by)||'משתמש')} • לטיפול ${esc(names.get(list.assigned_user_id)||'עובד')}</p></div><span class="mg-badge">${(items||[]).length} פריטים</span></div><div class="mg-shortage-work-list">${(items||[]).map(i=>`<div class="mg-shortage-work-row ${esc(i.status)}"><div><b>${esc(i.name)}</b><small>${esc(shortageItemStatusLabel(i.status))}</small></div>${editable?`<div class="mg-shortage-item-actions"><button class="mg-mini-btn${i.status==='fulfilled'?' active':''}" data-shortage-status="fulfilled" data-item="${i.id}">✓ שמתי</button><button class="mg-mini-btn danger${i.status==='missing'?' active':''}" data-shortage-status="missing" data-item="${i.id}">אין במחסן</button></div>`:''}</div>`).join('')}</div>${editable?`<div class="mg-shortage-finish"><p>בסיום, כל פריט שלא סומן כ״שמתי״ יעבור אוטומטית לרשימת <b>צריך להזמין</b> של המנהל.</p><button id="mgFinishShortage" class="mg-primary">סיימתי להכין — שלח התראה</button></div>`:''}${(list.created_by===session.user.id||isManagement())&&list.status==='ready'?`<button id="mgCloseShortage" class="mg-secondary" style="width:100%;margin-top:10px">אספתי — סגור רשימה</button>`:''}${managementActions}</div></main></div>`;
    bindBack();document.getElementById('mgPageBack').onclick=renderShortages;
    document.querySelectorAll('[data-shortage-status]').forEach(b=>b.onclick=()=>setShortageItemStatus(list,b.dataset.item,b.dataset.shortageStatus));
    document.getElementById('mgFinishShortage')?.addEventListener('click',()=>finishShortageList(list));
    document.getElementById('mgCloseShortage')?.addEventListener('click',async()=>{const {error}=await sb.from('shortage_lists').update({status:'closed',updated_at:new Date().toISOString()}).eq('id',list.id).eq('business_id',profile.business_id);if(error)alert(error.message);else renderShortages();});
    document.getElementById('mgResetShortage')?.addEventListener('click',()=>resetShortageList(list));
    document.getElementById('mgDeleteShortage')?.addEventListener('click',()=>deleteShortageList(list));
  }

  async function resetShortageList(list){
    if(!isManagement())return;
    if(!confirm('לאפס את הרשימה? כל הסימונים יימחקו, הפריטים יחזרו ל״ממתין״ והיא תישלח מחדש לעובד.'))return;
    const {data,error}=await sb.rpc('reset_shortage_list',{p_list_id:list.id});
    if(error){alert('לא ניתן לאפס את הרשימה: '+error.message);return;}
    try{await sb.functions.invoke('task-push',{body:{action:'shortage',shortage_list_id:list.id}});}catch(_e){}
    alert(`הרשימה אופסה. ${Number(data?.items_count||0)} פריטים חזרו למצב ממתין.`);
    renderShortageDetail(list.id);
  }
  async function deleteShortageList(list){
    if(!isManagement())return;
    if(!confirm('למחוק את הרשימה לצמיתות? הפעולה תמחק גם את כל הפריטים שלה ולא ניתן לבטל אותה.'))return;
    const {error}=await sb.rpc('delete_shortage_list',{p_list_id:list.id});
    if(error){alert('לא ניתן למחוק את הרשימה: '+error.message);return;}
    renderShortages();
  }

  async function setShortageItemStatus(list,itemId,status){
    if(list.status==='sent')await sb.from('shortage_lists').update({status:'working',started_at:new Date().toISOString(),updated_at:new Date().toISOString()}).eq('id',list.id).eq('business_id',profile.business_id);
    const {error}=await sb.from('shortage_items').update({status,handled_by:session.user.id,handled_at:new Date().toISOString()}).eq('id',itemId).eq('business_id',profile.business_id);if(error)alert(error.message);else renderShortageDetail(list.id);
  }
  async function finishShortageList(list){
    if(!confirm('לסיים את הרשימה? כל מה שלא סומן כ״שמתי״ יעבור לרשימת הפריטים שצריך להזמין.'))return;
    const {data,error}=await sb.rpc('finalize_shortage_list',{p_list_id:list.id});if(error){alert(error.message);return;}sb.functions.invoke('task-push',{body:{action:'shortage',shortage_list_id:list.id}}).catch(()=>{});alert(`הרשימה מוכנה. ${Number(data?.missing_count||0)} פריטים הועברו ל״צריך להזמין״.`);renderShortages();
  }

  const DEV_FEATURE_LABELS={inventory:'מלאי וספירות',calculator:'מחשבון',history:'היסטוריה',suppliers:'ספקים',tasks:'משימות',signage:'שילוט',shortages:'חוסרים',catalog:'קטלוג לקוחות',users:'משתמשים',permissions:'הרשאות',updates:'עדכוני מערכת'};

  async function renderDeveloperConsole(){
    if(!isPlatformAdminFlag)return renderDashboard();
    root.classList.remove('hidden');
    root.innerHTML=`${shellHeader('Developer Console','🧩')}<section class="mg-dev-hero"><div><span>PLATFORM CONTROL</span><h3>ניהול הסופרים בפלטפורמה</h3><p>כל סופר הוא סביבת עבודה נפרדת עם נתונים, משתמשים, ספקים, קטלוג והרשאות משלו.</p></div><button id="mgDevNewStore" class="mg-primary">＋ סופר חדש</button></section><div id="mgDevStoreForm"></div><div id="mgDevStores"><div class="mg-loading">טוען סופרים…</div></div></main></div>`;
    bindBack();mountAppNav('developer');document.getElementById('mgDevNewStore').onclick=()=>renderDeveloperStoreForm();await loadDeveloperStores();
  }

  function renderDeveloperStoreForm(store=null){
    const box=document.getElementById('mgDevStoreForm');if(!box)return;
    box.innerHTML=`<div class="mg-form-card mg-dev-form"><div class="mg-detail-head"><div><h3>${store?'עריכת סופר':'יצירת סופר חדש'}</h3><p>${store?'שינויים במיתוג ובסטטוס':'המערכת תיצור סביבת עבודה נפרדת וקוד כניסה'}</p></div><button id="mgDevCloseForm" class="mg-mini-btn">×</button></div><div class="mg-two"><div class="mg-field"><label>שם הסופר</label><input id="mgDevName" value="${esc(store?.name||'')}" placeholder="לדוגמה: מרקט העיר"></div><div class="mg-field"><label>קוד סופר</label><input id="mgDevCode" value="${esc(store?.store_code||'')}" ${store?'':'placeholder="CITYMARKET"'}></div></div><div class="mg-two"><div class="mg-field"><label>לוגו URL</label><input id="mgDevLogo" value="${esc(store?.logo_url||'')}" placeholder="https://..."></div><div class="mg-field"><label>צבע מותג</label><input id="mgDevColor" type="color" value="${esc(store?.accent_color||'#16a34a')}"></div></div>${store?`<div class="mg-field"><label>סטטוס</label><select id="mgDevStatus"><option value="active" ${store.status==='active'?'selected':''}>פעיל</option><option value="paused" ${store.status==='paused'?'selected':''}>מושהה</option><option value="disabled" ${store.status==='disabled'?'selected':''}>מושבת</option></select></div>`:''}<button id="mgDevSaveStore" class="mg-primary">${store?'שמור שינויים':'צור סופר'}</button><div id="mgDevFormMsg" class="mg-progress-text"></div></div>`;
    document.getElementById('mgDevCloseForm').onclick=()=>box.innerHTML='';document.getElementById('mgDevSaveStore').onclick=()=>saveDeveloperStore(store);
  }

  async function saveDeveloperStore(store){
    const msg=document.getElementById('mgDevFormMsg'),btn=document.getElementById('mgDevSaveStore');btn.disabled=true;msg.textContent='שומר…';
    const common={p_name:document.getElementById('mgDevName').value.trim(),p_store_code:document.getElementById('mgDevCode').value.trim().toUpperCase(),p_logo_url:document.getElementById('mgDevLogo').value.trim(),p_accent_color:document.getElementById('mgDevColor').value};
    const r=store?await sb.rpc('developer_update_business',{p_business_id:store.business_id,...common,p_status:document.getElementById('mgDevStatus').value}):await sb.rpc('developer_create_business',common);
    if(r.error){msg.textContent='שגיאה: '+r.error.message;btn.disabled=false;return;}msg.textContent=store?'נשמר ✓':'הסופר נוצר ✓';setTimeout(()=>{document.getElementById('mgDevStoreForm').innerHTML='';loadDeveloperStores();},450);
  }

  async function loadDeveloperStores(){
    const box=document.getElementById('mgDevStores');if(!box)return;const {data,error}=await sb.rpc('developer_list_businesses');if(error){box.innerHTML=`<div class="mg-error show">${esc(error.message)}</div>`;return;}const stores=data||[];
    box.innerHTML=`<div class="mg-dev-summary"><b>${stores.length}</b><span>סופרים בפלטפורמה</span><i>${stores.filter(x=>x.status==='active').length} פעילים</i></div><div class="mg-dev-store-grid">${stores.map((s,i)=>`<article class="mg-dev-store-card" style="--store:${esc(s.accent_color||'#16a34a')};--i:${i}"><div class="mg-dev-store-top"><span>${s.logo_url?`<img src="${esc(s.logo_url)}" alt="">`:'🏪'}</span><div><b>${esc(s.name)}</b><small>${esc(s.store_code)}</small></div><em class="${esc(s.status)}">${s.status==='active'?'פעיל':s.status==='paused'?'מושהה':'מושבת'}</em></div><div class="mg-dev-store-kpi"><span><b>${Number(s.member_count||0)}</b><small>משתמשים</small></span><span><b>${esc(new Intl.DateTimeFormat('he-IL',{dateStyle:'short'}).format(new Date(s.created_at)))}</b><small>נוצר</small></span></div><div class="mg-dev-store-actions"><button data-dev-enter="${esc(s.business_id)}" data-dev-code="${esc(s.store_code)}">כניסה לסופר</button><button data-dev-features="${esc(s.business_id)}" data-dev-name="${esc(s.name)}">מודולים</button><button data-dev-edit="${esc(s.business_id)}">עריכה</button></div><div data-dev-feature-box="${esc(s.business_id)}"></div></article>`).join('')}</div>`;
    box.querySelectorAll('[data-dev-enter]').forEach(b=>b.onclick=async()=>{const r=await sb.rpc('select_business',{p_business_id:b.dataset.devEnter});if(r.error)return alert(r.error.message);try{localStorage.setItem(STORE_CODE_KEY,b.dataset.devCode||'');}catch(_e){}await afterLogin(true);});
    box.querySelectorAll('[data-dev-edit]').forEach(b=>{const st=stores.find(x=>x.business_id===b.dataset.devEdit);b.onclick=()=>renderDeveloperStoreForm(st);});box.querySelectorAll('[data-dev-features]').forEach(b=>b.onclick=()=>renderDeveloperFeatures(b.dataset.devFeatures,b.dataset.devName));
  }

  async function renderDeveloperFeatures(storeId,storeName){
    const host=document.querySelector(`[data-dev-feature-box="${storeId}"]`);if(!host)return;const {data,error}=await sb.rpc('developer_get_features',{p_business_id:storeId});if(error){host.innerHTML=`<div class="mg-error show">${esc(error.message)}</div>`;return;}const map=new Map((data||[]).map(x=>[x.feature_key,!!x.enabled]));
    host.innerHTML=`<div class="mg-dev-features"><b>מודולים — ${esc(storeName)}</b>${Object.keys(DEV_FEATURE_LABELS).map(k=>`<label><span>${esc(DEV_FEATURE_LABELS[k])}</span><input type="checkbox" data-dev-feature="${k}" ${map.get(k)!==false?'checked':''}></label>`).join('')}</div>`;host.querySelectorAll('[data-dev-feature]').forEach(c=>c.onchange=async()=>{const r=await sb.rpc('developer_set_feature',{p_business_id:storeId,p_feature_key:c.dataset.devFeature,p_enabled:c.checked});if(r.error){c.checked=!c.checked;alert(r.error.message);}});
  }

  async function renderUpdates(){
    if(!isSuperAdmin())return renderDashboard();
    const {data:releases}=await sb.from('app_releases').select('version,notes,created_at').eq('business_id',profile.business_id).order('created_at',{ascending:false}).limit(20);
    root.classList.remove('hidden');
    root.innerHTML=`${shellHeader('עדכוני מערכת','⬆️')}<div class="mg-form-card"><h3>העלאת עדכון חדש</h3><p>מכאן והלאה, כשאשלח לך קובץ <b>.basta-update.json</b>, מעלים אותו כאן. המערכת מפיצה אותו דרך Supabase וכל המכשירים יקבלו אותו אוטומטית.</p><label class="mg-upload"><input id="mgUpdateFile" type="file" accept=".json,.basta-update.json,application/json"><span>בחר קובץ עדכון</span><small id="mgUpdateFilename">לא נבחר קובץ</small></label><button id="mgPublishUpdate" class="mg-primary" disabled>פרסם עדכון</button><div id="mgUpdateProgress" class="mg-progress-text"></div><div id="mgUpdateMsg" class="mg-error"></div></div><div class="mg-form-card"><h3>עדכונים שפורסמו</h3><div class="mg-release-list">${(releases||[]).length?(releases||[]).map(r=>`<div class="mg-release"><b>גרסה ${esc(r.version)}</b><span>${esc(formatDateTime(r.created_at))}</span><small>${esc(r.notes||'')}</small></div>`).join(''):'<div class="mg-empty">עדיין לא פורסמו עדכונים מתוך המערכת.</div>'}</div></div></main></div>`;
    bindBack();
    let selected=null;
    const fileInput=document.getElementById('mgUpdateFile'), publish=document.getElementById('mgPublishUpdate');
    fileInput.onchange=async()=>{
      selected=null; publish.disabled=true; const f=fileInput.files?.[0];
      document.getElementById('mgUpdateFilename').textContent=f?.name||'לא נבחר קובץ';
      if(!f)return;
      try{ const parsed=JSON.parse(await f.text()); validateUpdatePackage(parsed); selected=parsed; publish.disabled=false; document.getElementById('mgUpdateMsg').classList.remove('show'); }
      catch(err){ const msg=document.getElementById('mgUpdateMsg'); msg.textContent='קובץ העדכון אינו תקין: '+err.message; msg.classList.add('show'); }
    };
    publish.onclick=()=>selected&&publishUpdate(selected,publish);
  }

  function validateUpdatePackage(pkg){
    if(pkg?.format!=='basta-update-v1')throw new Error('פורמט לא מוכר');
    if(!/^[0-9A-Za-z._-]{1,40}$/.test(String(pkg.version||'')))throw new Error('מספר גרסה לא תקין');
    if(!Array.isArray(pkg.files)||!pkg.files.length)throw new Error('אין קבצים בעדכון');
    if(pkg.files.length>150)throw new Error('יותר מדי קבצים');
    for(const f of pkg.files){
      if(!/^\/[A-Za-z0-9._\/-]+$/.test(String(f.path||''))||String(f.path).includes('..'))throw new Error('נתיב קובץ לא תקין');
      if(!['text','base64'].includes(f.encoding))throw new Error('קידוד לא נתמך');
      if(typeof f.content!=='string')throw new Error('תוכן חסר');
      if(f.path==='/sw.js')throw new Error('sw.js הוא קובץ מערכת קבוע ואינו נכלל בעדכונים רגילים');
    }
  }

  function decodeFile(f){
    if(f.encoding==='text')return new Blob([f.content],{type:f.content_type||'application/octet-stream'});
    const bin=atob(f.content), bytes=new Uint8Array(bin.length); for(let i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i);
    return new Blob([bytes],{type:f.content_type||'application/octet-stream'});
  }

  async function publishUpdate(pkg,btn){
    const msg=document.getElementById('mgUpdateMsg'), prog=document.getElementById('mgUpdateProgress'); msg.classList.remove('show'); btn.disabled=true;
    try{
      for(let i=0;i<pkg.files.length;i++){
        const f=pkg.files[i], path=`releases/${pkg.version}/${String(f.path).replace(/^\/+/, '')}`;
        prog.textContent=`מעלה ${i+1} מתוך ${pkg.files.length}: ${f.path}`;
        const {error}=await sb.storage.from(UPDATE_BUCKET).upload(path,decodeFile(f),{upsert:true,contentType:f.content_type||undefined,cacheControl:'0'});
        if(error)throw error;
      }
      const publicBase=`${SUPABASE_URL}/storage/v1/object/public/${UPDATE_BUCKET}/releases/${encodeURIComponent(pkg.version)}`;
      const manifest={format:'basta-release-manifest-v1',version:pkg.version,notes:String(pkg.notes||''),published_at:new Date().toISOString(),files:pkg.files.map(f=>({path:f.path,url:publicBase+'/'+String(f.path).replace(/^\/+/, '').split('/').map(encodeURIComponent).join('/'),content_type:f.content_type||'application/octet-stream'}))};
      prog.textContent='מפרסם את הגרסה…';
      const {error:manifestError}=await sb.storage.from(UPDATE_BUCKET).upload('latest.json',new Blob([JSON.stringify(manifest)],{type:'application/json'}),{upsert:true,contentType:'application/json',cacheControl:'0'});
      if(manifestError)throw manifestError;
      try{ await sb.from('app_releases').insert({business_id:profile.business_id,version:pkg.version,notes:String(pkg.notes||''),uploaded_by:session.user.id}); }catch(_e){}
      prog.textContent='העדכון פורסם. מתקין במכשיר הזה…';
      const reg=await navigator.serviceWorker?.ready;
      reg?.active?.postMessage({type:'CHECK_BASTA_UPDATE'});
      setTimeout(()=>{prog.textContent='העדכון פורסם לכל המכשירים. רענן את האפליקציה בעוד רגע כדי לעבור לגרסה החדשה.';btn.disabled=false;},1400);
    }catch(err){ msg.textContent='לא הצלחתי לפרסם את העדכון: '+(err.message||err); msg.classList.add('show'); prog.textContent=''; btn.disabled=false; }
  }

  // ---------------------------------------------------------------------------
  // V2.5.1 – Customer order catalog administration
  // ---------------------------------------------------------------------------
  let orderCatalogAdminOffset=0;
  let orderCatalogAdminQuery='';
  let orderCatalogAdminDepartment='';
  let orderCatalogDepartments=[];
  let promoSelectedProducts=[];
  const ORDER_CATALOG_PAGE_SIZE=80;

  const yesValue=v=>['כן','true','1','yes'].includes(String(v??'').trim().toLowerCase());
  const splitPipe=v=>String(v||'').split('|').map(x=>x.trim()).filter(Boolean);
  const cleanPublicPhone=v=>String(v||'').replace(/[^0-9+]/g,'');

  function parseCatalogCsv(text){
    const rows=[];let row=[],cell='',quoted=false;
    const input=String(text||'').replace(/^\uFEFF/,'');
    for(let i=0;i<input.length;i++){
      const c=input[i];
      if(quoted){
        if(c==='"'&&input[i+1]==='"'){cell+='"';i++;}
        else if(c==='"')quoted=false;
        else cell+=c;
      }else{
        if(c==='"')quoted=true;
        else if(c===','){row.push(cell);cell='';}
        else if(c==='\n'){row.push(cell.replace(/\r$/,''));rows.push(row);row=[];cell='';}
        else cell+=c;
      }
    }
    if(cell.length||row.length){row.push(cell.replace(/\r$/,''));rows.push(row);}
    if(!rows.length)return [];
    const headers=rows.shift().map(x=>String(x||'').trim());
    return rows.filter(r=>r.some(x=>String(x||'').trim())).map(r=>Object.fromEntries(headers.map((h,i)=>[h,r[i]??''])));
  }

  async function loadOrderCatalogDepartments(){
    const {data,error}=await sb.rpc('get_my_customer_catalog_departments');
    if(error)throw error;
    orderCatalogDepartments=data||[];
    return orderCatalogDepartments;
  }

  function catalogDepartmentOptions(selected=''){
    return orderCatalogDepartments.map(d=>`<option value="${esc(d.id)}" ${String(d.id)===String(selected)?'selected':''}>${esc(d.icon||'🛒')} ${esc(d.name)}</option>`).join('');
  }

  async function renderOrderCatalogAdmin(){
    if(!isManagement())return alert('המסך זמין למנהלים בלבד.');
    root.classList.remove('hidden');root.dataset.activeModule='catalog';
    root.innerHTML=`${shellHeader('קטלוג הזמנות ללקוחות','🛒')}
      <section class="mg-customer-catalog-hero">
        <div><span>אתר הזמנות ללקוחות</span><h3>הוויטרינה הדיגיטלית של אחים דוד.</h3><p>מוצרים, מבצעים והזמנות במקום אחד — עריכה כאן מתעדכנת מיד באתר הלקוחות.</p></div>
        <div class="mg-catalog-hero-badge">ללא מחירים</div>
      </section>
      <div id="mgCustomerCatalogStats" class="mg-catalog-stats"><div class="mg-loading">טוען קטלוג…</div></div>
      <div class="mg-form-card">
        <div class="mg-detail-head"><div><h3>הגדרות אתר הלקוחות</h3><p>את מספר הוואטסאפ אפשר לשנות בלי לעדכן את האתר.</p></div><button id="mgOpenPublicCatalog" class="mg-mini-btn" hidden>פתח אתר לקוחות ↗</button></div>
        <div class="mg-two"><div class="mg-field"><label>WhatsApp להזמנות</label><input id="mgCatalogWhatsapp" inputmode="tel" placeholder="0501234567"></div><div class="mg-field"><label>כתובת האתר הציבורי</label><input id="mgCatalogPublicUrl" type="url" placeholder="https://..."></div></div>
        <div class="mg-field"><label>כותרת ללקוח</label><input id="mgCatalogPageTitle" value="הזמנה מאחים דוד יקנעם"></div>
        <div class="mg-field"><label>טקסט פתיחה</label><input id="mgCatalogIntro"></div>
        <label class="mg-check"><input id="mgCatalogFreeText" type="checkbox" checked> לאפשר ללקוח להוסיף מוצר שלא מצא</label>
        <button id="mgSaveCatalogSettings" class="mg-secondary">שמור הגדרות</button><div id="mgCatalogSettingsMsg" class="mg-progress-text"></div>
      </div>
      <div class="mg-form-card mg-promo-builder-card">
        <div class="mg-detail-head"><div><span class="mg-card-kicker">PROMO STUDIO</span><h3>🔥 סטודיו למבצעים</h3><p>מבצע קבוע או מוגבל בזמן, על מוצר אחד או על כמה מוצרים יחד. הוא יופיע בדף הראשי, במחלקות וליד המוצרים.</p></div><span class="mg-promo-builder-pill">חדש</span></div>
        <div class="mg-promo-builder-grid"><div><div class="mg-field"><label>חיפוש והוספת מוצרים</label><div class="mg-promo-product-search"><input id="mgPromoProductSearch" type="search" placeholder="חפשו מוצר והוסיפו למבצע…"><div id="mgPromoProductResults" class="mg-promo-search-results"></div></div><div id="mgPromoSelectedProducts" class="mg-promo-selected-products"><span>עדיין לא נוספו מוצרים</span></div></div><div class="mg-two"><div class="mg-field"><label>כותרת</label><input id="mgPromoTitle" value="מבצע"></div><div class="mg-field"><label>הטבה / טקסט מרכזי</label><input id="mgPromoText" placeholder="2 ב־20 ₪ / השני ב־50% / קונים יחד וחוסכים"></div></div><div class="mg-two"><div class="mg-field"><label>תג קצר על המוצר</label><input id="mgPromoBadge" value="מבצע" maxlength="28"></div><div class="mg-field"><label>סגנון</label><select id="mgPromoTheme"><option value="lime">ליים</option><option value="sunset">כתום</option><option value="berry">ורוד</option><option value="ocean">תכלת</option><option value="forest">ירוק כהה</option></select></div></div></div><div class="mg-promo-schedule"><label class="mg-promo-permanent"><input id="mgPromoPermanent" type="checkbox"><span><b>מבצע קבוע</b><small>נשאר באתר עד שמכבים או מוחקים אותו</small></span></label><div class="mg-two"><div class="mg-field"><label>מתחיל</label><input id="mgPromoStarts" type="datetime-local"></div><div class="mg-field" id="mgPromoExpiresWrap"><label>בתוקף עד</label><input id="mgPromoExpires" type="datetime-local"></div></div><div class="mg-promo-placement"><span>יוצג אוטומטית:</span><b>דף הבית</b><b>ליד המוצר</b><b>בכל מחלקה רלוונטית</b></div></div></div>
        <button id="mgAddCatalogPromotion" class="mg-primary mg-promo-save">פרסם מבצע</button><div id="mgPromoMsg" class="mg-progress-text"></div>
        <div class="mg-promo-list-head"><b>מבצעים קיימים</b><small>קבועים, פעילים ומתוזמנים</small></div><div id="mgCatalogPromotionsList" class="mg-promo-admin-list"><div class="mg-loading">טוען מבצעים…</div></div>
      </div>
      <div class="mg-form-card mg-catalog-manual-card">
        <div class="mg-detail-head"><div><h3>🧭 מצב קטלוג ידני</h3><p>מכאן עובדים לאט ומדויק: מוסיפים מחלקה אחת בכל פעם, ורק מוצרים שאנחנו רוצים שהלקוח יראה.</p></div><span class="mg-catalog-manual-status">אוטומציה כבויה</span></div>
        <div class="mg-catalog-principles"><span>✓ הכי נמכרים ראשונים בכל מחלקה</span><span>✓ וריאציות רק כשיש ללקוח בחירה אמיתית</span><span>✓ פירות וירקות בשמות הבסטה בלבד</span></div>
      </div>
      <div class="mg-form-card mg-customer-orders-admin">
        <div class="mg-detail-head"><div><h3>👤 הזמנות אחרונות מלקוחות</h3><p>שם, טלפון, שעת איסוף והזמנה נשמרים כאן גם לאחר פתיחת WhatsApp.</p></div></div>
        <div id="mgRecentCustomerOrders" class="mg-customer-orders-list"><div class="mg-loading">טוען הזמנות…</div></div>
      </div>
      <div class="mg-form-card">
        <div class="mg-detail-head"><div><h3>מוצרים באתר</h3><p>עריכת שם, מחלקה, תמונה, פופולריות ווריאציות.</p></div><button id="mgCatalogAddProduct" class="mg-secondary">+ מוצר חדש</button></div>
        <div class="mg-order-toolbar mg-catalog-toolbar"><div class="mg-search-wrap">🔎<input id="mgCatalogAdminSearch" type="search" placeholder="חיפוש מוצר…"></div><select id="mgCatalogAdminDept" class="mg-catalog-filter"><option value="">כל המחלקות</option></select></div>
        <div id="mgCustomerCatalogProducts" class="mg-customer-catalog-list"><div class="mg-loading">טוען מוצרים…</div></div>
        <button id="mgCatalogLoadMore" class="mg-secondary mg-catalog-load-more" hidden>טען עוד</button>
      </div></main></div>`;
    bindBack();mountAppNav('catalog');
    try{
      await loadOrderCatalogDepartments();
      const deptSelect=document.getElementById('mgCatalogAdminDept');
      deptSelect.insertAdjacentHTML('beforeend',orderCatalogDepartments.map(d=>`<option value="${esc(d.id)}">${esc(d.icon||'🛒')} ${esc(d.name)}</option>`).join(''));
      await Promise.all([loadOrderCatalogSettings(),refreshOrderCatalogStats(),loadCatalogPromotions(),loadRecentCustomerOrders()]);
      orderCatalogAdminOffset=0;orderCatalogAdminQuery='';orderCatalogAdminDepartment='';
      await loadOrderCatalogAdminProducts(true);
    }catch(err){document.getElementById('mgCustomerCatalogProducts').innerHTML=`<div class="mg-error show">${esc(err.message||String(err))}<br><small>אם זו הפעם הראשונה, יש להריץ קודם את קובץ ה-SQL של V2.5.0.</small></div>`;}

    document.getElementById('mgSaveCatalogSettings').onclick=saveOrderCatalogSettings;
    document.getElementById('mgCatalogAddProduct').onclick=()=>openOrderCatalogProductEditor(null);
    setupCatalogPromotionAdmin();
    let searchTimer=null;
    document.getElementById('mgCatalogAdminSearch').oninput=e=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>{orderCatalogAdminQuery=String(e.target.value||'').trim();orderCatalogAdminOffset=0;loadOrderCatalogAdminProducts(true);},250);};
    document.getElementById('mgCatalogAdminDept').onchange=e=>{orderCatalogAdminDepartment=e.target.value||'';orderCatalogAdminOffset=0;loadOrderCatalogAdminProducts(true);};
    document.getElementById('mgCatalogLoadMore').onclick=()=>loadOrderCatalogAdminProducts(false);
  }

  async function loadRecentCustomerOrders(){
    const box=document.getElementById('mgRecentCustomerOrders');if(!box)return;
    try{
      const {data,error}=await sb.from('customer_orders').select('id,customer_name,customer_phone,pickup_time,item_count,total_units,created_at,status,message_text').eq('business_id',profile.business_id).order('created_at',{ascending:false}).limit(20);
      if(error)throw error;
      const rows=data||[];
      box.innerHTML=rows.length?rows.map(o=>`<article class="mg-customer-order-row"><div class="mg-customer-order-person"><b>${esc(o.customer_name||'לקוח')}</b><a href="tel:${esc(o.customer_phone||'')}">${esc(o.customer_phone||'')}</a></div><div class="mg-customer-order-meta"><span>🕒 ${esc(o.pickup_time||'לא צוינה שעה')}</span><span>🛒 ${Number(o.item_count||0)} מוצרים · ${Number(o.total_units||0)} יח׳</span><span>${esc(formatDateTime(o.created_at))}</span></div><details><summary>הצג את ההודעה</summary><pre>${esc(o.message_text||'')}</pre></details></article>`).join(''):'<div class="mg-empty">עדיין לא נשמרו הזמנות לקוחות.</div>';
    }catch(err){
      box.innerHTML=`<div class="mg-empty">היסטוריית הזמנות תופיע כאן אחרי הרצת SQL של V2.9.0.<br><small>${esc(err.message||'')}</small></div>`;
    }
  }

  async function loadOrderCatalogSettings(){
    const {data,error}=await sb.from('customer_catalog_settings').select('*').eq('business_id',profile.business_id).maybeSingle();
    if(error)throw error;const x=data||{};
    document.getElementById('mgCatalogWhatsapp').value=x.whatsapp_phone||'';
    document.getElementById('mgCatalogPublicUrl').value=x.public_url||'';
    document.getElementById('mgCatalogPageTitle').value=x.page_title||'הזמנה מאחים דוד יקנעם';
    document.getElementById('mgCatalogIntro').value=x.intro_text||'';
    document.getElementById('mgCatalogFreeText').checked=x.allow_free_text!==false;
    const open=document.getElementById('mgOpenPublicCatalog');open.hidden=!x.public_url;open.onclick=()=>x.public_url&&window.open(x.public_url,'_blank','noopener');
  }

  async function saveOrderCatalogSettings(){
    const msg=document.getElementById('mgCatalogSettingsMsg');msg.textContent='שומר…';
    // public_slug is NOT NULL. PostgreSQL validates NOT NULL before resolving an UPSERT conflict,
    // so it must be present even when this business already has a settings row.
    const current=await sb.from('customer_catalog_settings').select('public_slug').eq('business_id',profile.business_id).maybeSingle();
    if(current.error){msg.textContent='שגיאה: '+current.error.message;return;}
    const publicSlug=String(current.data?.public_slug||'ahim-david-yokneam').trim()||'ahim-david-yokneam';
    const row={business_id:profile.business_id,public_slug:publicSlug,whatsapp_phone:cleanPublicPhone(document.getElementById('mgCatalogWhatsapp').value),public_url:document.getElementById('mgCatalogPublicUrl').value.trim(),page_title:document.getElementById('mgCatalogPageTitle').value.trim()||'הזמנה מאחים דוד יקנעם',intro_text:document.getElementById('mgCatalogIntro').value.trim(),allow_free_text:document.getElementById('mgCatalogFreeText').checked,updated_by:session.user.id,updated_at:new Date().toISOString()};
    const {error}=await sb.from('customer_catalog_settings').upsert(row,{onConflict:'business_id'});msg.textContent=error?'שגיאה: '+error.message:'נשמר ✓';if(!error)loadOrderCatalogSettings();
  }

  async function refreshOrderCatalogStats(){
    const now=new Date().toISOString();
    const [p,v,a,pr,orders,customers]=await Promise.all([
      sb.from('customer_catalog_products').select('id',{count:'exact',head:true}).eq('business_id',profile.business_id).eq('active',true),
      sb.from('customer_catalog_variants').select('id',{count:'exact',head:true}).eq('business_id',profile.business_id).eq('active',true),
      sb.from('customer_catalog_products').select('id',{count:'exact',head:true}).eq('business_id',profile.business_id).eq('is_popular',true).eq('active',true),
      sb.from('customer_catalog_promotions').select('id',{count:'exact',head:true}).eq('business_id',profile.business_id).eq('active',true).or(`is_permanent.eq.true,expires_at.gt.${now}`),
      sb.from('customer_orders').select('id',{count:'exact',head:true}).eq('business_id',profile.business_id),
      sb.from('customer_orders').select('customer_phone').eq('business_id',profile.business_id).limit(1000)
    ]);
    const uniqueCustomers=new Set((customers.data||[]).map(x=>String(x.customer_phone||'').replace(/\D/g,'')).filter(Boolean)).size;
    document.getElementById('mgCustomerCatalogStats').innerHTML=`<div><b>${Number(p.count||0).toLocaleString('he-IL')}</b><span>מוצרים באתר</span></div><div><b>${Number(v.count||0).toLocaleString('he-IL')}</b><span>אפשרויות / וריאציות</span></div><div><b>${Number(a.count||0).toLocaleString('he-IL')}</b><span>מובילים במחלקות</span></div><div><b>${Number(orders.count||0).toLocaleString('he-IL')}</b><span>הזמנות שנשמרו</span></div><div><b>${Number(uniqueCustomers).toLocaleString('he-IL')}</b><span>לקוחות מזוהים</span></div><div><b>${Number(pr.count||0).toLocaleString('he-IL')}</b><span>מבצעים בתוקף</span></div>`;
  }

  async function loadOrderCatalogAdminProducts(reset=false){
    const target=document.getElementById('mgCustomerCatalogProducts');if(!target)return;
    if(reset){target.innerHTML='<div class="mg-loading">טוען מוצרים…</div>';orderCatalogAdminOffset=0;}
    let q=sb.from('customer_catalog_products').select('id,import_key,display_name,brand,quantity_text,image_url,image_source,is_popular,popularity_score,market_score,manual_order,active,is_basta_item,produce_unit_mode,subcategory,department_id,browse_mode,enrichment_status,enrichment_source,enrichment_confidence').eq('business_id',profile.business_id).order('is_popular',{ascending:false}).order('popularity_score',{ascending:false}).order('manual_order',{ascending:true}).range(orderCatalogAdminOffset,orderCatalogAdminOffset+ORDER_CATALOG_PAGE_SIZE-1);
    if(orderCatalogAdminDepartment)q=q.eq('department_id',orderCatalogAdminDepartment);
    if(orderCatalogAdminQuery)q=q.or(`display_name.ilike.%${orderCatalogAdminQuery.replace(/[,%]/g,' ')}%,brand.ilike.%${orderCatalogAdminQuery.replace(/[,%]/g,' ')}%`);
    const {data,error}=await q;if(error){target.innerHTML=`<div class="mg-error show">${esc(error.message)}</div>`;return;}
    const products=data||[],ids=products.map(x=>x.id);let variants=[];
    if(ids.length){const vr=await sb.from('customer_catalog_variants').select('id,product_id,label,primary_barcode,active').in('product_id',ids);if(!vr.error)variants=vr.data||[];}
    const by=new Map();variants.forEach(v=>{if(!by.has(v.product_id))by.set(v.product_id,[]);by.get(v.product_id).push(v);});
    const html=products.map(p=>{const d=orderCatalogDepartments.find(x=>x.id===p.department_id),vs=by.get(p.id)||[];return `<article class="mg-customer-product-row ${p.active?'':'inactive'}"><div class="mg-customer-product-thumb">${p.image_url?`<img src="${esc(p.image_url)}" alt="">`:`<span>${esc(d?.icon||'🛒')}</span>`}</div><div class="mg-customer-product-main"><div class="mg-customer-product-title"><b>${esc(p.display_name)}</b>${p.brand?`<small>${esc(p.brand)}</small>`:''}${p.quantity_text?`<small class="mg-product-quantity">${esc(p.quantity_text)}</small>`:''}</div><div class="mg-customer-product-meta"><span>${esc(d?.icon||'')} ${esc(d?.name||'ללא מחלקה')}</span><span>${vs.length>1?`${vs.length} אפשרויות לבחירה`:'ללא בחירה נוספת'}</span>${p.subcategory?`<span>${esc(p.subcategory)}</span>`:''}<span>${p.browse_mode==='search_only'?'🔎 בחיפוש בלבד':p.browse_mode==='hidden'?'🙈 מוסתר':'🛒 בגלישה'}</span>${p.is_popular?'<strong>⭐ מוביל במחלקה</strong>':''}${p.is_basta_item?`<strong>🥬 בסטה · ${p.produce_unit_mode==='kg'?'ק״ג בלבד':p.produce_unit_mode==='unit'?'יח׳ בלבד':'ק״ג + יח׳'}</strong>`:''}</div></div><div class="mg-customer-product-actions"><button data-edit-customer-product="${esc(p.id)}" class="mg-secondary">עריכה</button><button data-toggle-customer-product="${esc(p.id)}" data-active="${p.active?'1':'0'}" class="mg-mini-btn">${p.active?'הסתר':'הצג'}</button></div></article>`;}).join('');
    if(reset)target.innerHTML=html||'<div class="mg-empty">לא נמצאו מוצרים.</div>';else target.insertAdjacentHTML('beforeend',html);
    target.querySelectorAll('[data-edit-customer-product]').forEach(b=>b.onclick=()=>openOrderCatalogProductEditor(b.dataset.editCustomerProduct));
    target.querySelectorAll('[data-toggle-customer-product]').forEach(b=>b.onclick=()=>toggleOrderCatalogProduct(b.dataset.toggleCustomerProduct,b.dataset.active==='1'));
    orderCatalogAdminOffset+=products.length;
    const more=document.getElementById('mgCatalogLoadMore');more.hidden=products.length<ORDER_CATALOG_PAGE_SIZE;
  }

  async function toggleOrderCatalogProduct(id,isActive){
    const {error}=await sb.from('customer_catalog_products').update({active:!isActive,updated_at:new Date().toISOString()}).eq('business_id',profile.business_id).eq('id',id);if(error)return alert(error.message);orderCatalogAdminOffset=0;await loadOrderCatalogAdminProducts(true);refreshOrderCatalogStats();
  }

  async function openOrderCatalogProductEditor(productId){
    document.getElementById('mgCatalogProductModal')?.remove();
    let product=null,variants=[];
    if(productId){
      const pr=await sb.from('customer_catalog_products').select('*').eq('business_id',profile.business_id).eq('id',productId).single();if(pr.error)return alert(pr.error.message);product=pr.data;
      const vr=await sb.from('customer_catalog_variants').select('*').eq('business_id',profile.business_id).eq('product_id',productId).order('display_order').order('label');if(vr.error)return alert(vr.error.message);variants=vr.data||[];
    }
    const deptId=product?.department_id||orderCatalogDepartments[0]?.id||'';
    document.body.insertAdjacentHTML('beforeend',`<div id="mgCatalogProductModal" class="mg-catalog-modal-overlay"><button class="mg-catalog-modal-scrim" data-close-catalog-modal></button><section class="mg-catalog-modal"><div class="mg-detail-head"><div><h3>${product?'עריכת מוצר':'מוצר חדש'}</h3><p>${product?'כל השינויים מופיעים מיד באתר הלקוחות.':'ייווצר כרטיס מוצר עם וריאציה אחת.'}</p></div><button data-close-catalog-modal class="mg-more-close">×</button></div><div class="mg-field"><label>שם ללקוח</label><input id="mgEditCatalogName" value="${esc(product?.display_name||'')}"></div><div class="mg-two"><div class="mg-field"><label>מותג</label><input id="mgEditCatalogBrand" value="${esc(product?.brand||'')}"></div><div class="mg-field"><label>תכולה</label><input id="mgEditCatalogQuantity" value="${esc(product?.quantity_text||'')}" placeholder="לדוגמה: 1 ליטר / 500 גרם"></div></div><div class="mg-two"><div class="mg-field"><label>מחלקה</label><select id="mgEditCatalogDept">${catalogDepartmentOptions(deptId)}</select></div><div class="mg-field"><label>הצגה ללקוח</label><select id="mgEditCatalogBrowseMode"><option value="browse" ${!product?.browse_mode||product?.browse_mode==='browse'?'selected':''}>בגלישה ובחיפוש</option><option value="search_only" ${product?.browse_mode==='search_only'?'selected':''}>בחיפוש בלבד</option><option value="hidden" ${product?.browse_mode==='hidden'?'selected':''}>מוסתר</option></select></div></div><div class="mg-two"><div class="mg-field"><label>תת־מחלקה</label><input id="mgEditCatalogSubcategory" value="${esc(product?.subcategory||'')}" placeholder="לדוגמה: גבינות"></div><div class="mg-field" ${product?.is_basta_item?'':'hidden'}><label>פירות/ירקות — אפשרות כמות</label><select id="mgEditProduceUnitMode"><option value="both" ${!product?.produce_unit_mode||product?.produce_unit_mode==='both'?'selected':''}>ק״ג + יח׳ (ברירת מחדל)</option><option value="kg" ${product?.produce_unit_mode==='kg'?'selected':''}>ק״ג בלבד</option><option value="unit" ${product?.produce_unit_mode==='unit'?'selected':''}>יח׳ בלבד</option></select></div></div><div class="mg-field"><label>קישור לתמונה</label><input id="mgEditCatalogImage" value="${esc(product?.image_url||'')}" placeholder="https://..."></div><div class="mg-two"><div class="mg-field"><label>דירוג בתוך המחלקה</label><input id="mgEditCatalogPopularity" type="number" step="1" value="${Number(product?.popularity_score||0)}"></div><div class="mg-field"><label>סדר ידני</label><input id="mgEditCatalogOrder" type="number" step="1" value="${Number(product?.manual_order||100000)}"></div></div><div class="mg-inline-buttons"><label class="mg-check"><input id="mgEditCatalogPopular" type="checkbox" ${product?.is_popular?'checked':''}> מוביל במחלקה ⭐</label><label class="mg-check"><input id="mgEditCatalogActive" type="checkbox" ${product?.active!==false?'checked':''}> מוצג באתר</label></div><div class="mg-catalog-variant-editor"><div class="mg-detail-head"><div><h3>וריאציות</h3><p>מוסיפים אפשרויות רק כשבאמת יש ללקוח בחירה: אחוז שומן, גודל, סוג או אריזה.</p></div><button id="mgAddCatalogVariant" class="mg-mini-btn">+ וריאציה</button></div><div id="mgCatalogVariantRows">${variants.length?variants.map(catalogVariantEditorRow).join(''):catalogVariantEditorRow(null)}</div></div><button id="mgSaveCatalogProduct" class="mg-primary">שמור מוצר</button><div id="mgCatalogProductMsg" class="mg-progress-text"></div></section></div>`);
    const modal=document.getElementById('mgCatalogProductModal');modal.querySelectorAll('[data-close-catalog-modal]').forEach(b=>b.onclick=()=>modal.remove());document.getElementById('mgAddCatalogVariant').onclick=()=>document.getElementById('mgCatalogVariantRows').insertAdjacentHTML('beforeend',catalogVariantEditorRow(null));document.getElementById('mgSaveCatalogProduct').onclick=()=>saveOrderCatalogProduct(product);
  }

  function catalogVariantEditorRow(v){
    return `<div class="mg-catalog-variant-row" data-variant-id="${esc(v?.id||'')}"><input data-v-label placeholder="שם וריאציה" value="${esc(v?.label||'רגיל')}"><input data-v-size placeholder="גודל" value="${esc(v?.size||'')}"><input data-v-barcode inputmode="numeric" placeholder="ברקוד" value="${esc(v?.primary_barcode||'')}"><label><input data-v-active type="checkbox" ${v?.active!==false?'checked':''}> פעיל</label><button type="button" data-remove-v class="mg-mini-btn danger">×</button></div>`;
  }

  async function saveOrderCatalogProduct(existing){
    const msg=document.getElementById('mgCatalogProductMsg');msg.textContent='שומר…';
    const name=document.getElementById('mgEditCatalogName').value.trim();if(!name){msg.textContent='חסר שם מוצר.';return;}
    const importKey=existing?.import_key||`manual:${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
    const row={business_id:profile.business_id,import_key:importKey,department_id:document.getElementById('mgEditCatalogDept').value,display_name:name,brand:document.getElementById('mgEditCatalogBrand').value.trim(),quantity_text:document.getElementById('mgEditCatalogQuantity')?.value.trim()||'',browse_mode:document.getElementById('mgEditCatalogBrowseMode')?.value||'browse',subcategory:document.getElementById('mgEditCatalogSubcategory')?.value.trim()||'',produce_unit_mode:document.getElementById('mgEditProduceUnitMode')?.value||existing?.produce_unit_mode||'both',image_url:document.getElementById('mgEditCatalogImage').value.trim(),is_popular:document.getElementById('mgEditCatalogPopular').checked,popularity_score:Number(document.getElementById('mgEditCatalogPopularity').value)||0,manual_order:Number(document.getElementById('mgEditCatalogOrder').value)||100000,active:document.getElementById('mgEditCatalogActive').checked,enrichment_status:existing?.enrichment_status||'manual',updated_at:new Date().toISOString()};
    let productId=existing?.id;
    if(productId){const r=await sb.from('customer_catalog_products').update(row).eq('business_id',profile.business_id).eq('id',productId);if(r.error){msg.textContent=r.error.message;return;}}
    else {const r=await sb.from('customer_catalog_products').insert(row).select('id').single();if(r.error){msg.textContent=r.error.message;return;}productId=r.data.id;}
    const vrows=[...document.querySelectorAll('#mgCatalogVariantRows .mg-catalog-variant-row')];
    for(let i=0;i<vrows.length;i++){
      const el=vrows[i],id=el.dataset.variantId||'',label=el.querySelector('[data-v-label]').value.trim()||'רגיל',barcode=el.querySelector('[data-v-barcode]').value.trim();
      if(el.dataset.removed==='1'){if(id)await sb.from('customer_catalog_variants').delete().eq('business_id',profile.business_id).eq('id',id);continue;}
      const vr={business_id:profile.business_id,product_id:productId,variant_key:id?undefined:`${importKey}|manual-${Date.now()}-${i}-${Math.random().toString(36).slice(2,6)}`,label,size:el.querySelector('[data-v-size]').value.trim(),primary_barcode:barcode,display_order:i+1,active:el.querySelector('[data-v-active]').checked,updated_at:new Date().toISOString()};
      if(id){delete vr.variant_key;const rr=await sb.from('customer_catalog_variants').update(vr).eq('business_id',profile.business_id).eq('id',id);if(rr.error){msg.textContent=rr.error.message;return;}}
      else {const rr=await sb.from('customer_catalog_variants').insert(vr);if(rr.error){msg.textContent=rr.error.message;return;}}
    }
    msg.textContent='נשמר ✓';setTimeout(()=>document.getElementById('mgCatalogProductModal')?.remove(),400);orderCatalogAdminOffset=0;await loadOrderCatalogAdminProducts(true);refreshOrderCatalogStats();
  }

  document.addEventListener('click',e=>{const b=e.target.closest?.('[data-remove-v]');if(!b)return;const row=b.closest('.mg-catalog-variant-row');if(row.dataset.variantId){row.dataset.removed='1';row.hidden=true;}else row.remove();});

  async function importCustomerCatalogCsv(file){
    const btn=document.getElementById('mgCatalogImportBtn'),prog=document.getElementById('mgCatalogImportProgress');btn.disabled=true;prog.textContent='קורא קובץ…';
    try{
      const rows=parseCatalogCsv(await file.text());
      if(!rows.length||!rows[0].import_key||!rows[0].display_name||!rows[0].variant_key)throw new Error('הקובץ אינו בפורמט קטלוג V2.5.0');
      await loadOrderCatalogDepartments();const deptMap=new Map(orderCatalogDepartments.map(d=>[d.slug,d.id]));
      const missing=[...new Set(rows.map(r=>r.department_slug).filter(x=>x&&!deptMap.has(x)))];
      if(missing.length)throw new Error('מחלקות חסרות ב-Supabase: '+missing.join(', '));
      const products=new Map();
      rows.forEach(r=>{if(!products.has(r.import_key))products.set(r.import_key,{business_id:profile.business_id,import_key:r.import_key,department_id:deptMap.get(r.department_slug),display_name:r.display_name,brand:r.brand||'',image_url:r.image_url||'',is_popular:yesValue(r.is_popular),popularity_score:Number(r.popularity_score)||0,manual_order:Number(r.manual_order)||100000,active:yesValue(r.active),is_basta_item:false,updated_at:new Date().toISOString()});});
      const prodRows=[...products.values()],productIds=new Map(),batch=250;
      for(let i=0;i<prodRows.length;i+=batch){prog.textContent=`מוצרים: ${Math.min(i+batch,prodRows.length).toLocaleString('he-IL')} / ${prodRows.length.toLocaleString('he-IL')}`;const r=await sb.from('customer_catalog_products').upsert(prodRows.slice(i,i+batch),{onConflict:'business_id,import_key'}).select('id,import_key');if(r.error)throw r.error;(r.data||[]).forEach(x=>productIds.set(x.import_key,x.id));}
      // V2.5.1: a CSV may contain the same logical variation more than once (for
      // example the same size with multiple POS / manufacturer barcodes). PostgreSQL
      // cannot UPSERT the same conflict key twice in one statement, so consolidate
      // duplicate variant_key rows before sending them to Supabase.
      const variantMap=new Map();
      const mergeUnique=(a,b)=>[...new Set([...(a||[]),...(b||[])].map(x=>String(x||'').trim()).filter(Boolean))];
      rows.forEach((r,i)=>{
        const productId=productIds.get(r.import_key);if(!productId)return;
        const key=String(r.variant_key||'').trim();if(!key)return;
        const incoming={business_id:profile.business_id,product_id:productId,variant_key:key,label:r.variant_label||'רגיל',size:r.variant_size||'',primary_barcode:String(r.primary_barcode||'').trim(),alternate_barcodes:splitPipe(r.alternate_barcodes),pos_codes:splitPipe(r.pos_codes),original_names:splitPipe(r.original_names),display_order:i+1,active:yesValue(r.active),updated_at:new Date().toISOString()};
        const existing=variantMap.get(key);
        if(!existing){variantMap.set(key,incoming);return;}
        if(incoming.primary_barcode&&incoming.primary_barcode!==existing.primary_barcode)existing.alternate_barcodes=mergeUnique(existing.alternate_barcodes,[incoming.primary_barcode]);
        existing.alternate_barcodes=mergeUnique(existing.alternate_barcodes,incoming.alternate_barcodes);
        existing.pos_codes=mergeUnique(existing.pos_codes,incoming.pos_codes);
        existing.original_names=mergeUnique(existing.original_names,incoming.original_names);
        if(!existing.size&&incoming.size)existing.size=incoming.size;
        if(String(incoming.label||'').length>String(existing.label||'').length)existing.label=incoming.label;
        existing.active=existing.active||incoming.active;
      });
      const vars=[...variantMap.values()];
      for(let i=0;i<vars.length;i+=batch){prog.textContent=`וריאציות: ${Math.min(i+batch,vars.length).toLocaleString('he-IL')} / ${vars.length.toLocaleString('he-IL')}`;const r=await sb.from('customer_catalog_variants').upsert(vars.slice(i,i+batch),{onConflict:'business_id,variant_key'});if(r.error)throw r.error;}
      const merged=await sb.rpc('merge_my_customer_catalog_duplicates');if(merged.error)throw merged.error;
      prog.textContent=`הייבוא הושלם ✓ ${prodRows.length.toLocaleString('he-IL')} כרטיסי מקור, ${vars.length.toLocaleString('he-IL')} וריאציות${Number(merged.data||0)?` · אוחדו ${Number(merged.data).toLocaleString('he-IL')} כפילויות`:''}.`;await refreshOrderCatalogStats();orderCatalogAdminOffset=0;await loadOrderCatalogAdminProducts(true);
    }catch(err){prog.textContent='שגיאה בייבוא: '+(err.message||err);}finally{btn.disabled=false;}
  }

  let catalogEnrichmentAuto=false;
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));

  function mgBarcodeDigits(v){return String(v||'').replace(/\D/g,'');}
  function mgIsValidGtin(value){
    const s=mgBarcodeDigits(value);if(![8,12,13,14].includes(s.length))return false;
    const a=[...s].map(Number),check=a.pop();let sum=0;
    for(let i=a.length-1,j=0;i>=0;i--,j++)sum+=a[i]*(j%2===0?3:1);
    return ((10-(sum%10))%10)===check;
  }
  function mgBestCatalogBarcode(variants){
    const seen=new Set(),all=[];
    for(const v of variants||[]){
      const values=[v.primary_barcode,...(Array.isArray(v.alternate_barcodes)?v.alternate_barcodes:[])];
      for(const raw of values){const code=mgBarcodeDigits(raw);if(!code||seen.has(code)||!mgIsValidGtin(code))continue;seen.add(code);all.push(code);}
    }
    // Prefer full EAN-13/GTIN-13, then EAN-8, UPC-A and GTIN-14.
    const rank=x=>x.length===13?0:x.length===8?1:x.length===12?2:3;
    all.sort((a,b)=>rank(a)-rank(b));return all[0]||'';
  }

  async function getCatalogEnrichmentBatch(limit=6){
    let q=sb.from('customer_catalog_products').select('id,import_key,display_name,brand,quantity_text,image_url,image_source,subcategory,browse_mode,enrichment_status,enrichment_source,enrichment_confidence,enrichment_meta,is_basta_item,is_popular,popularity_score,market_score,manual_order,department_id').eq('business_id',profile.business_id).eq('active',true).eq('is_basta_item',false).in('enrichment_status',['pending','failed']).order('is_popular',{ascending:false}).order('popularity_score',{ascending:false}).order('manual_order',{ascending:true}).limit(500);
    const pr=await q;if(pr.error)throw pr.error;
    const ps=(pr.data||[]).filter(p=>!String(p.import_key||'').startsWith('manual:')&&!String(p.import_key||'').startsWith('curated:'));if(!ps.length)return [];
    const ids=ps.map(p=>p.id),vr=await sb.from('customer_catalog_variants').select('product_id,primary_barcode,alternate_barcodes,display_order,active').in('product_id',ids).eq('active',true).order('display_order',{ascending:true});if(vr.error)throw vr.error;
    const by=new Map();for(const v of vr.data||[]){if(!by.has(v.product_id))by.set(v.product_id,[]);by.get(v.product_id).push(v);}
    // V2.8.12: products without a valid GTIN are no longer discarded. They are sent
    // to the enrichment function in conservative name-match mode.
    const items=[];
    for(const p of ps){
      const barcode=mgBestCatalogBarcode(by.get(p.id)||[]);
      items.push({...p,barcode,lookup_mode:barcode?'barcode':'name'});
      if(items.length>=limit)break;
    }
    return items;
  }

  async function applyCatalogEnrichmentResults(items,results){
    let changed=0,images=0,reviews=0,details=0,noExternal=0;
    for(const r of results||[]){
      const source=items.find(x=>String(x.id)===String(r.product_id));if(!source)continue;
      const realSources=Array.isArray(r.sources)?r.sources.filter(Boolean):[];
      if(!r.found||!realSources.length){
        const status=!r.found&&r.status==='not_found'?'not_found':'review';
        const src=!realSources.length?'no_external_match':String(r.status||'not_found');
        const row={enrichment_status:status,enrichment_source:src,enrichment_confidence:0,enrichment_verified_at:new Date().toISOString(),enrichment_meta:{...(source.enrichment_meta||{}),...(r.meta||{}),conservative_v2_8_12:true,no_external_match:!realSources.length,lookup_mode:String(r.lookup_mode||source.lookup_mode||'unknown'),requested_lookup_mode:String(source.lookup_mode||'unknown'),barcode_used:source.barcode||'',matched_barcode:String(r.matched_barcode||'')},updated_at:new Date().toISOString()};
        const up=await sb.from('customer_catalog_products').update(row).eq('business_id',profile.business_id).eq('id',source.id);if(up.error)throw up.error;
        if(!realSources.length){noExternal++;reviews++;}continue;
      }
      // Conservative enrichment: preserve curated customer-facing name, department,
      // browse/popularity order and variants. Fill only missing metadata and image.
      const row={
        enrichment_status:r.status==='review'?'review':'enriched',
        enrichment_source:realSources.join(','),
        enrichment_confidence:Number(r.confidence)||0,
        enrichment_verified_at:new Date().toISOString(),
        enrichment_meta:{...(source.enrichment_meta||{}),...(r.meta||{}),conservative_v2_8_12:true,lookup_mode:String(r.lookup_mode||source.lookup_mode||'barcode'),requested_lookup_mode:String(source.lookup_mode||'unknown'),barcode_used:source.barcode||'',matched_barcode:String(r.matched_barcode||source.barcode||'')},
        updated_at:new Date().toISOString()
      };
      const safeConfidence=Number(r.confidence)||0,isNameMatch=(source.lookup_mode==='name'||String(r.lookup_mode||'').includes('name'));
      if(!String(source.brand||'').trim()&&String(r.brand||'').trim()&&(!isNameMatch||safeConfidence>=.72)){row.brand=String(r.brand).trim();details++;}
      if(!String(source.quantity_text||'').trim()&&String(r.quantity_text||'').trim()&&(!isNameMatch||safeConfidence>=.72)){row.quantity_text=String(r.quantity_text).trim();details++;}
      if(!String(source.subcategory||'').trim()&&String(r.subcategory||'').trim()&&(!isNameMatch||safeConfidence>=.78)){row.subcategory=String(r.subcategory).trim();details++;}
      if(!String(source.image_url||'').trim()&&String(r.image_url||'').trim()&&(!isNameMatch||safeConfidence>=.78)){row.image_url=String(r.image_url);row.image_source=String(r.image_source||'openfacts');images++;}
      const up=await sb.from('customer_catalog_products').update(row).eq('business_id',profile.business_id).eq('id',source.id);if(up.error)throw up.error;
      changed++;if(r.status==='review')reviews++;
    }
    return {changed,images,reviews,details,noExternal,merged:0};
  }

  async function runCatalogEnrichmentBatch(auto=false){
    const prog=document.getElementById('mgCatalogEnrichProgress'),batchBtn=document.getElementById('mgCatalogEnrichBatch'),autoBtn=document.getElementById('mgCatalogEnrichAuto');if(!prog)return {done:true};batchBtn.disabled=true;autoBtn.disabled=true;prog.textContent='מאתר מוצרים לעיבוד…';
    try{const items=await getCatalogEnrichmentBatch(1);if(!items.length){prog.textContent='אין עוד מוצרים שממתינים להעשרה ✓';await refreshOrderCatalogStats();return {done:true};}
      const nameCount=items.filter(x=>x.lookup_mode==='name').length;prog.textContent=`מעשיר ${items.length} מוצרים בקצב בטוח · ${items.length-nameCount} לפי ברקוד · ${nameCount} לפי שם…`;
      const inv=await sb.functions.invoke('catalog-enrich',{body:{items:items.map(x=>({product_id:x.id,barcode:x.barcode,current_name:x.display_name,current_brand:x.brand,current_quantity:x.quantity_text,lookup_mode:x.lookup_mode}))}});if(inv.error)throw inv.error;const results=inv.data?.results||[];const out=await applyCatalogEnrichmentResults(items,results);prog.textContent=`נמצאו ${out.changed} התאמות חיצוניות · ${out.images} תמונות נוספו${out.details?` · ${out.details} פרטים חסרים הושלמו`:''}${out.noExternal?` · ${out.noExternal} ללא התאמה חיצונית`:''}${out.reviews?` · ${out.reviews} לבדיקה`:''}`;await refreshOrderCatalogStats();orderCatalogAdminOffset=0;await loadOrderCatalogAdminProducts(true);return {done:false,count:items.length};
    }catch(err){prog.textContent='שגיאה בהעשרה: '+(err.message||err);return {done:true,error:err};}finally{batchBtn.disabled=false;if(!catalogEnrichmentAuto)autoBtn.disabled=false;}
  }

  async function startCatalogEnrichmentAuto(){
    if(catalogEnrichmentAuto)return;catalogEnrichmentAuto=true;const autoBtn=document.getElementById('mgCatalogEnrichAuto'),stopBtn=document.getElementById('mgCatalogEnrichStop'),prog=document.getElementById('mgCatalogEnrichProgress');autoBtn.disabled=true;stopBtn.hidden=false;
    let total=0;while(catalogEnrichmentAuto){const r=await runCatalogEnrichmentBatch(true);if(r.done||r.error)break;total+=Number(r.count||0);if(prog)prog.textContent+=` · סה״כ בסבב ${total}`;for(let i=15;i>0&&catalogEnrichmentAuto;i--){if(prog)prog.dataset.wait=`${i}`;await sleep(1000);}}
    catalogEnrichmentAuto=false;autoBtn.disabled=false;stopBtn.hidden=true;if(prog&&total)prog.textContent+=` · העיבוד נעצר אחרי ${total} מוצרים.`;
  }
  function stopCatalogEnrichmentAuto(){catalogEnrichmentAuto=false;const b=document.getElementById('mgCatalogEnrichStop');if(b)b.hidden=true;const p=document.getElementById('mgCatalogEnrichProgress');if(p)p.textContent='עוצר אחרי האצווה הנוכחית…';}

  let catalogCommercialImageAuto=false;
  function catalogImagePriority(a,b){return Number(b.is_popular||0)-Number(a.is_popular||0)||Number(b.popularity_score||0)-Number(a.popularity_score||0)||Number(a.manual_order||100000)-Number(b.manual_order||100000);}
  async function getCatalogCommercialImageBatch(limit=4){
    const fields='id,import_key,display_name,brand,quantity_text,image_url,image_source,is_popular,popularity_score,manual_order,active,is_basta_item,subcategory,department_id';
    const weakSources=['openfoodfacts','openbeautyfacts','openproductsfacts','openfacts'];
    const [wr,br]=await Promise.all([
      sb.from('customer_catalog_products').select(fields).eq('business_id',profile.business_id).eq('active',true).eq('is_basta_item',false).in('image_source',weakSources).order('is_popular',{ascending:false}).order('popularity_score',{ascending:false}).order('manual_order',{ascending:true}).limit(80),
      sb.from('customer_catalog_products').select(fields).eq('business_id',profile.business_id).eq('active',true).eq('is_basta_item',false).eq('image_source','').eq('image_url','').order('is_popular',{ascending:false}).order('popularity_score',{ascending:false}).order('manual_order',{ascending:true}).limit(80)
    ]);if(wr.error)throw wr.error;if(br.error)throw br.error;
    const uniq=new Map();[...(wr.data||[]),...(br.data||[])].forEach(x=>uniq.set(String(x.id),x));const ps=[...uniq.values()].sort(catalogImagePriority).slice(0,limit);if(!ps.length)return [];
    const ids=ps.map(x=>x.id),vr=await sb.from('customer_catalog_variants').select('product_id,primary_barcode,display_order,active').in('product_id',ids).eq('active',true).neq('primary_barcode','').order('display_order',{ascending:true});if(vr.error)throw vr.error;const first=new Map();(vr.data||[]).forEach(v=>{if(!first.has(v.product_id)&&v.primary_barcode)first.set(v.product_id,v.primary_barcode);});
    return ps.map(x=>({...x,barcode:first.get(x.id)||''})).filter(x=>x.barcode);
  }
  async function applyCatalogCommercialImageResults(items,results){
    await loadOrderCatalogDepartments();const deptMap=new Map(orderCatalogDepartments.map(d=>[d.slug,d.id]));let images=0,noImage=0,metadata=0,rateLimited=false,noKey=false;
    for(const r of results||[]){const source=items.find(x=>String(x.id)===String(r.product_id));if(!source)continue;if(r.status==='rate_limited'){rateLimited=true;continue;}if(r.status==='no_key'){noKey=true;continue;}if(r.status==='error')continue;
      const row={updated_at:new Date().toISOString()};if(r.clean_name&&String(r.clean_name).trim()!==String(source.display_name||'').trim()){row.display_name=String(r.clean_name).trim();metadata++;}if(r.brand&&String(r.brand).trim())row.brand=String(r.brand).trim();if(r.quantity_text&&String(r.quantity_text).trim())row.quantity_text=String(r.quantity_text).trim();if(r.subcategory&&String(r.subcategory).trim())row.subcategory=String(r.subcategory).trim();if(r.department_slug&&deptMap.has(r.department_slug))row.department_id=deptMap.get(r.department_slug);
      if(r.image_url){row.image_url=String(r.image_url);row.image_source='cheapersal';images++;}else if(r.status==='no_image'||r.status==='not_found'){row.image_url='';row.image_source='commercial_not_found';noImage++;}
      const up=await sb.from('customer_catalog_products').update(row).eq('business_id',profile.business_id).eq('id',source.id);if(up.error)throw up.error;
    }
    return {images,noImage,metadata,rateLimited,noKey};
  }
  async function runCatalogCommercialImageBatch(auto=false){
    const prog=document.getElementById('mgCatalogImagesProgress'),batchBtn=document.getElementById('mgCatalogImagesBatch'),autoBtn=document.getElementById('mgCatalogImagesAuto');if(!prog)return {done:true};batchBtn.disabled=true;autoBtn.disabled=true;prog.textContent='מחפש מוצרים לשדרוג תמונה…';
    try{const items=await getCatalogCommercialImageBatch(4);if(!items.length){prog.textContent='אין עוד תמונות קהילה/חסרות שממתינות לבדיקה ✓';return {done:true};}prog.textContent=`בודק ${items.length} מוצרים מול מקור התמונות המסחרי…`;const inv=await sb.functions.invoke('catalog-enrich',{body:{mode:'commercial_image',items:items.map(x=>({product_id:x.id,barcode:x.barcode,current_name:x.display_name,current_brand:x.brand,current_quantity:x.quantity_text,lookup_mode:x.lookup_mode}))}});if(inv.error)throw inv.error;const out=await applyCatalogCommercialImageResults(items,inv.data?.results||[]);if(out.noKey){prog.textContent='לא נמצא CHEAPERSAL_API_KEY ב-Supabase Secrets.';return {done:true,error:new Error('missing api key')};}if(out.rateLimited){prog.textContent=`עודכנו ${out.images} תמונות. ה-API הגיע כרגע למגבלת הקצב/המכסה — אפשר להמשיך מאוחר יותר.`;return {done:true,rateLimited:true};}prog.textContent=`שודרגו ${out.images} תמונות מסחריות${out.noImage?` · ${out.noImage} ללא תמונה מסחרית`:''}${out.metadata?` · ${out.metadata} שמות שופרו`:''}`;await refreshOrderCatalogStats();orderCatalogAdminOffset=0;await loadOrderCatalogAdminProducts(true);return {done:false,count:items.length};
    }catch(err){prog.textContent='שגיאה בשדרוג התמונות: '+(err.message||err);return {done:true,error:err};}finally{batchBtn.disabled=false;if(!catalogCommercialImageAuto)autoBtn.disabled=false;}
  }
  async function startCatalogCommercialImageAuto(){
    if(catalogCommercialImageAuto)return;catalogCommercialImageAuto=true;const autoBtn=document.getElementById('mgCatalogImagesAuto'),stopBtn=document.getElementById('mgCatalogImagesStop'),prog=document.getElementById('mgCatalogImagesProgress');autoBtn.disabled=true;stopBtn.hidden=false;let total=0;
    while(catalogCommercialImageAuto){const r=await runCatalogCommercialImageBatch(true);if(r.done||r.error||r.rateLimited)break;total+=Number(r.count||0);for(let i=32;i>0&&catalogCommercialImageAuto;i--){if(prog)prog.textContent=`${prog.textContent.split(' · המתנה')[0]} · המתנה ${i} שנ׳ כדי לכבד את מגבלת ה-API`;await sleep(1000);}}
    catalogCommercialImageAuto=false;autoBtn.disabled=false;stopBtn.hidden=true;if(prog&&total)prog.textContent=prog.textContent.replace(/ · המתנה .*$/,'')+` · נבדקו ${total} מוצרים בסבב`;
  }
  function stopCatalogCommercialImageAuto(){catalogCommercialImageAuto=false;const b=document.getElementById('mgCatalogImagesStop');if(b)b.hidden=true;const p=document.getElementById('mgCatalogImagesProgress');if(p)p.textContent='עוצר אחרי האצווה הנוכחית…';}

  async function syncBastaIntoCustomerCatalog(){
    const btn=document.getElementById('mgSyncBastaCatalog'),prog=document.getElementById('mgCatalogImportProgress');btn.disabled=true;prog.textContent='מסנכרן פירות וירקות…';
    try{
      const names=(await loadInventoryProduceCatalog()).map(x=>String(x||'').trim()).filter(Boolean);await loadOrderCatalogDepartments();
      const d=orderCatalogDepartments.find(x=>x.slug==='produce');if(!d)throw new Error('מחלקת פירות וירקות לא קיימת');
      if(!names.length)throw new Error('לא נמצאו פירות וירקות בקונפיגורציית הבסטה');const productRows=names.map((name,i)=>({business_id:profile.business_id,import_key:'basta:'+name.toLocaleLowerCase('he'),department_id:d.id,display_name:name,brand:'',image_url:'',is_popular:i<20,popularity_score:Math.max(35,70-i*.2),manual_order:i+1,active:true,is_basta_item:true,updated_at:new Date().toISOString()}));
      const r=await sb.from('customer_catalog_products').upsert(productRows,{onConflict:'business_id,import_key'}).select('id,import_key');if(r.error)throw r.error;const ids=new Map((r.data||[]).map(x=>[x.import_key,x.id]));
      const productIdList=[...ids.values()];if(productIdList.length)await sb.from('customer_catalog_variants').update({active:false,updated_at:new Date().toISOString()}).in('product_id',productIdList).like('variant_key','%|half');
      const vars=[];for(const name of names){const ik='basta:'+name.toLocaleLowerCase('he'),pid=ids.get(ik);if(!pid)continue;[['kg','ק״ג'],['unit','יח׳']].forEach(([k,label],j)=>vars.push({business_id:profile.business_id,product_id:pid,variant_key:`${ik}|${k}`,label,size:'',primary_barcode:'',alternate_barcodes:[],pos_codes:[],original_names:[name],display_order:j+1,active:true,updated_at:new Date().toISOString()}));}
      const vr=await sb.from('customer_catalog_variants').upsert(vars,{onConflict:'business_id,variant_key'});if(vr.error)throw vr.error;prog.textContent=`סונכרנו ${names.length} פירות וירקות ✓`;await refreshOrderCatalogStats();orderCatalogAdminOffset=0;await loadOrderCatalogAdminProducts(true);
    }catch(err){prog.textContent='לא הצלחתי לסנכרן: '+(err.message||err);}finally{btn.disabled=false;}
  }


  function mgLocalDateTimeValue(date){
    const d=date instanceof Date?date:new Date(date||Date.now());const pad=n=>String(n).padStart(2,'0');
    return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }
  function setupCatalogPromotionAdmin(){
    promoSelectedProducts=[];renderPromoSelectedProducts();
    const starts=document.getElementById('mgPromoStarts'),expires=document.getElementById('mgPromoExpires');
    if(starts&&!starts.value)starts.value=mgLocalDateTimeValue(new Date());if(expires&&!expires.value){const d=new Date();d.setDate(d.getDate()+7);d.setHours(23,59,0,0);expires.value=mgLocalDateTimeValue(d);}
    const permanent=document.getElementById('mgPromoPermanent');if(permanent)permanent.onchange=()=>{document.getElementById('mgPromoExpiresWrap').classList.toggle('disabled',permanent.checked);document.getElementById('mgPromoExpires').disabled=permanent.checked;};
    const input=document.getElementById('mgPromoProductSearch');let t=null;if(input)input.oninput=()=>{clearTimeout(t);t=setTimeout(()=>searchCatalogPromotionProducts(input.value),180);};
    const add=document.getElementById('mgAddCatalogPromotion');if(add)add.onclick=saveCatalogPromotion;
  }
  function renderPromoSelectedProducts(){
    const box=document.getElementById('mgPromoSelectedProducts');if(!box)return;
    box.innerHTML=promoSelectedProducts.length?promoSelectedProducts.map((p,i)=>`<button type="button" data-remove-promo-product="${esc(p.id)}"><span>${i+1}</span><b>${esc(p.display_name)}</b>${p.brand?`<small>${esc(p.brand)}</small>`:''}<i>×</i></button>`).join(''):'<span>עדיין לא נוספו מוצרים</span>';
    box.querySelectorAll('[data-remove-promo-product]').forEach(b=>b.onclick=()=>{promoSelectedProducts=promoSelectedProducts.filter(x=>x.id!==b.dataset.removePromoProduct);renderPromoSelectedProducts();});
  }
  async function searchCatalogPromotionProducts(term){
    const box=document.getElementById('mgPromoProductResults');if(!box)return;const q=String(term||'').trim();if(q.length<2){box.innerHTML='';return;}box.innerHTML='<div class="mg-loading">מחפש…</div>';const safe=q.replace(/[,%]/g,' ');
    const r=await sb.from('customer_catalog_products').select('id,display_name,brand,quantity_text').eq('business_id',profile.business_id).eq('active',true).or(`display_name.ilike.%${safe}%,brand.ilike.%${safe}%`).order('popularity_score',{ascending:false}).limit(10);
    if(r.error){box.innerHTML=`<div class="mg-error show">${esc(r.error.message)}</div>`;return;}const selected=new Set(promoSelectedProducts.map(x=>x.id));box.innerHTML=(r.data||[]).filter(p=>!selected.has(p.id)).map(p=>`<button type="button" class="mg-promo-search-row" data-promo-pick="${esc(p.id)}" data-name="${esc(p.display_name)}" data-brand="${esc(p.brand||'')}" data-quantity="${esc(p.quantity_text||'')}"><b>${esc(p.display_name)}</b><small>${esc([p.brand,p.quantity_text].filter(Boolean).join(' · '))}</small><i>＋</i></button>`).join('')||'<div class="mg-empty">לא נמצא מוצר נוסף.</div>';
    box.querySelectorAll('[data-promo-pick]').forEach(b=>b.onclick=()=>{promoSelectedProducts.push({id:b.dataset.promoPick,display_name:b.dataset.name,brand:b.dataset.brand||'',quantity_text:b.dataset.quantity||''});renderPromoSelectedProducts();document.getElementById('mgPromoProductSearch').value='';box.innerHTML='';});
  }
  async function saveCatalogPromotion(){
    const msg=document.getElementById('mgPromoMsg'),btn=document.getElementById('mgAddCatalogPromotion');msg.textContent='מפרסם מבצע…';btn.disabled=true;
    try{
      if(!promoSelectedProducts.length)throw new Error('צריך להוסיף לפחות מוצר אחד למבצע.');
      const permanent=document.getElementById('mgPromoPermanent').checked,starts=document.getElementById('mgPromoStarts').value,expires=document.getElementById('mgPromoExpires').value,startDate=new Date(starts||Date.now());let expireIso=null;
      if(!permanent){if(!expires)throw new Error('במבצע זמני צריך לבחור תאריך סיום.');const exp=new Date(expires);if(!(exp>startDate))throw new Error('תאריך הסיום חייב להיות אחרי מועד ההתחלה.');expireIso=exp.toISOString();}
      const row={business_id:profile.business_id,product_id:promoSelectedProducts[0].id,title:document.getElementById('mgPromoTitle').value.trim()||'מבצע',promo_text:document.getElementById('mgPromoText').value.trim(),badge_text:document.getElementById('mgPromoBadge').value.trim()||'מבצע',theme:document.getElementById('mgPromoTheme').value||'lime',is_permanent:permanent,starts_at:startDate.toISOString(),expires_at:expireIso,show_on_home:true,show_on_department:true,show_on_product:true,active:true,created_by:session.user.id,updated_at:new Date().toISOString()};
      const r=await sb.from('customer_catalog_promotions').insert(row).select('id').single();if(r.error)throw r.error;
      const links=promoSelectedProducts.map((p,i)=>({promotion_id:r.data.id,product_id:p.id,business_id:profile.business_id,display_order:i+1}));const lr=await sb.from('customer_catalog_promotion_products').insert(links);if(lr.error){await sb.from('customer_catalog_promotions').delete().eq('id',r.data.id);throw lr.error;}
      msg.textContent=permanent?'המבצע הקבוע פורסם ✓':'המבצע פורסם ✓ והוא ייעלם אוטומטית בזמן שהוגדר.';promoSelectedProducts=[];renderPromoSelectedProducts();document.getElementById('mgPromoProductSearch').value='';document.getElementById('mgPromoText').value='';document.getElementById('mgPromoTitle').value='מבצע';document.getElementById('mgPromoBadge').value='מבצע';await Promise.all([loadCatalogPromotions(),refreshOrderCatalogStats()]);
    }catch(err){msg.textContent='שגיאה: '+(err.message||err);}finally{btn.disabled=false;}
  }
  async function loadCatalogPromotions(){
    const box=document.getElementById('mgCatalogPromotionsList');if(!box)return;
    const r=await sb.from('customer_catalog_promotions').select('id,product_id,title,promo_text,badge_text,theme,is_permanent,starts_at,expires_at,active,display_order').eq('business_id',profile.business_id).order('created_at',{ascending:false}).limit(60);
    if(r.error){box.innerHTML=`<div class="mg-error show">${esc(r.error.message)}<br><small>יש להריץ את SQL של V2.10.0.</small></div>`;return;}
    const promos=r.data||[],promoIds=promos.map(x=>x.id);let links=[],products=[];
    if(promoIds.length){const lr=await sb.from('customer_catalog_promotion_products').select('promotion_id,product_id,display_order').in('promotion_id',promoIds);if(!lr.error)links=lr.data||[];const ids=[...new Set(links.map(x=>x.product_id).concat(promos.map(x=>x.product_id).filter(Boolean)))];if(ids.length){const pr=await sb.from('customer_catalog_products').select('id,display_name,brand').in('id',ids);if(!pr.error)products=pr.data||[];}}
    const pm=new Map(products.map(x=>[x.id,x])),now=Date.now();
    box.innerHTML=promos.length?promos.map(x=>{let ps=links.filter(l=>l.promotion_id===x.id).sort((a,b)=>a.display_order-b.display_order).map(l=>pm.get(l.product_id)).filter(Boolean);if(!ps.length&&x.product_id&&pm.get(x.product_id))ps=[pm.get(x.product_id)];const start=new Date(x.starts_at).getTime(),end=x.expires_at?new Date(x.expires_at).getTime():Infinity,state=!x.active?'כבוי':start>now?'מתוזמן':(!x.is_permanent&&end<=now)?'פג תוקף':'פעיל עכשיו';const time=x.is_permanent?'קבוע':x.expires_at?`עד ${formatDateTime(x.expires_at)}`:'ללא תאריך סיום';return `<article class="mg-promo-admin-row theme-${esc(x.theme||'lime')} ${state==='פג תוקף'?'expired':''}"><div class="mg-promo-admin-top"><span>${esc(x.badge_text||'מבצע')}</span><div><b>${esc(x.title||'מבצע')}</b><small>${esc(x.promo_text||'ללא טקסט נוסף')} · ${esc(state)} · ${esc(time)}</small></div></div><div class="mg-promo-admin-products">${ps.map(p=>`<i>${esc(p.display_name)}</i>`).join('')||'<i>ללא מוצר</i>'}</div><button class="mg-mini-btn danger" data-delete-catalog-promo="${esc(x.id)}">מחק מבצע</button></article>`;}).join(''):'<div class="mg-empty">אין מבצעים מוגדרים כרגע.</div>';
    box.querySelectorAll('[data-delete-catalog-promo]').forEach(b=>b.onclick=async()=>{if(!confirm('למחוק את המבצע?'))return;const rr=await sb.from('customer_catalog_promotions').delete().eq('business_id',profile.business_id).eq('id',b.dataset.deleteCatalogPromo);if(rr.error)return alert(rr.error.message);await Promise.all([loadCatalogPromotions(),refreshOrderCatalogStats()]);});
  }

  function openInventory(){
    if(!requireModule('inventory'))return;
    removeAppNav();
    root.classList.add('hidden'); applyRoleToInventory();
    let strip=document.querySelector('.inventory-management-strip');
    if(!strip){ strip=document.createElement('div'); strip.className='inventory-management-strip'; strip.innerHTML='<button id="mgBackDashboard">← ניהול הסופר</button><span data-sync-status></span>'; document.querySelector('.brand')?.appendChild(strip); }
    document.getElementById('mgBackDashboard').onclick=renderDashboard; setSync(syncStatus);
  }

  async function logout(){ removeAppNav(); cloudReady=false; clearInterval(supplierReminderTimer);supplierReminderTimer=null; try{if(notificationChannel)await sb.removeChannel(notificationChannel);}catch(_e){} notificationChannel=null; await sb.auth.signOut(); session=null;profile=null;business=null;cloudConfig=null;cloudConfigSignature='';modulePermissions=new Map();businessFeatures=new Map();isPlatformAdminFlag=false;editingDraftOrderId=null;editingSourceOrderId=null;shortageComposer=[];signageSettings=new Map();signageProduceCatalog=[];renderLogin(); }

  async function init(){
    if('serviceWorker' in navigator){ try{ await navigator.serviceWorker.register('/sw.js',{scope:'/'}); }catch(_e){} }
    if(!window.supabase?.createClient)return renderLogin('לא הצלחתי לטעון את רכיב ההתחברות. בדוק חיבור לאינטרנט.');
    sb=window.supabase.createClient(SUPABASE_URL,SUPABASE_KEY,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
    const {data}=await sb.auth.getSession(); session=data.session;
    if(session)await afterLogin(); else renderLogin();
    sb.auth.onAuthStateChange((event,newSession)=>{ session=newSession; if(event==='SIGNED_OUT')renderLogin(); });
    navigator.serviceWorker?.addEventListener('message',e=>{
      if(e.data?.type==='BASTA_UPDATE_READY' && root && !root.classList.contains('hidden')){
        const bar=document.createElement('button');bar.className='mg-update-ready';bar.textContent=`גרסה ${e.data.version} מוכנה — לחץ לרענון`;bar.onclick=()=>location.reload();document.body.appendChild(bar);
      }
    });
  }

  init().catch(e=>renderLogin(e?.message||'שגיאה בטעינת המערכת.'));
})();
