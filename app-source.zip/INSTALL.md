# התקנה ראשונה

## Android — בלי Android Studio
1. העלה את תוכן הפרויקט ל-GitHub.
2. פתח Actions → Build Android APK → Run workflow.
3. הורד את artifact `supermarket-management-debug-apk`.
4. חלץ `app-debug.apk` ושלח לעובדים.
5. במכשיר Android אשר התקנה ממקור חיצוני והתקן.

## iPhone — Xcode בלבד
1. ב-GitHub פתח Actions → Build iOS Xcode Project → Run workflow.
2. הורד את `supermarket-management-ios-xcode-project`.
3. חלץ ופתח `ios/App/App.xcodeproj` ב-Xcode.
4. Xcode → Settings → Accounts → הוסף Apple ID.
5. Project App → Signing & Capabilities → Team → בחר Personal Team.
6. חבר את האייפון ובחר אותו כ-Run Destination.
7. לחץ Run ▶.
8. אם האייפון מבקש אמון במפתח: Settings → General → VPN & Device Management → Trust.
9. כשחתימת ה-Personal Team פגה, פתח שוב Xcode ולחץ Run מחדש.

אין צורך ב-Node, Android Studio או Terminal במחשב שלך במסלול הזה.
