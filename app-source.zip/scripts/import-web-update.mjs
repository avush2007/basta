import fs from 'node:fs';
import path from 'node:path';
const source=process.argv[2];
if(!source)throw new Error('Usage: node scripts/import-web-update.mjs <update.basta-update.json>');
const pkg=JSON.parse(fs.readFileSync(source,'utf8'));
if(pkg.format!=='basta-update-v1'||!Array.isArray(pkg.files))throw new Error('Invalid basta-update-v1 package');
for(const f of pkg.files){
  if(f.path==='/sw.js')continue;
  const rel=f.path.replace(/^\/+/, '');
  const dest=path.join('www',rel);
  fs.mkdirSync(path.dirname(dest),{recursive:true});
  fs.writeFileSync(dest,f.encoding==='base64'?Buffer.from(f.content,'base64'):f.content);
}
console.log(`Imported ${pkg.files.length} files from version ${pkg.version}`);
